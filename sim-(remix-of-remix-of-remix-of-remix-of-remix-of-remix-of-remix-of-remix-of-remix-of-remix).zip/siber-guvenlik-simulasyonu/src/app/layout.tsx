import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import Head from "next/head";
import "./globals.css";
import { ClientBody } from "./ClientBody";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Siber Güvenlik Simülasyonu",
  description: "Yeni başlayanlar için siber güvenliğin temel prensiplerini öğreten interaktif bir simülasyon.",
};

export default function RootLayout() {
  return (
    <html lang="tr" className={`${geistSans.variable} ${geistMono.variable} dark`}>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="Yeni başlayanlar için siber güvenliğin temel prensiplerini öğreten interaktif bir simülasyon." />
        <meta property="og:title" content="Siber Güvenlik Simülasyonu" />
        <meta property="og:description" content="Yeni başlayanlar için siber güvenliğin temel prensiplerini öğreten interaktif bir simülasyon." />
        <meta property="og:type" content="website" />
        <meta property="og:locale" content="tr_TR" />
        <meta property="og:image" content="/media/device-security.png" />
        <meta property="og:url" content="https://senin-site-adresin.com" />
        <meta name="robots" content="index, follow" />
        <meta name="keywords" content="siber güvenlik, simülasyon, eğitim, başlangıç, bilgi güvenliği" />
      </Head>
      <body className="antialiased bg-black text-white" suppressHydrationWarning>
        <ClientBody />
      </body>
    </html>
  );
}
