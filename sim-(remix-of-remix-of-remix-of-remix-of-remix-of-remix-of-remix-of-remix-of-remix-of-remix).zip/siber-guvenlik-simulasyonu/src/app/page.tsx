"use client";

import { useGameStore } from "@/store/gameStore";
import { WelcomeScreen } from "@/components/game/WelcomeScreen";
import { ScenarioScreen } from "@/components/game/ScenarioScreen";
import { ResultScreen } from "@/components/game/ResultScreen";
import { useEffect, useState } from "react";

export default function Home() {
  return null;
}
