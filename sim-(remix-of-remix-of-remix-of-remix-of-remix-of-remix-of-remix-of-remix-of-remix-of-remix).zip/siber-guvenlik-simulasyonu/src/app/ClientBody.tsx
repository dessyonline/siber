"use client";

import { useEffect, useState } from "react";
import { useGameStore } from "@/store/gameStore";
import { WelcomeScreen } from "@/components/game/WelcomeScreen";
import { ScenarioScreen } from "@/components/game/ScenarioScreen";
import { ResultScreen } from "@/components/game/ResultScreen";

export function ClientBody() {
  const { isStarted, isCompleted } = useGameStore();

  // Hidrasyon hatalarını önlemek için client tarafında render olduğundan emin olalım
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  // Kod koruma scriptleri
  useEffect(() => {
    // Sağ tıkı devre dışı bırak
    const onContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };
    document.addEventListener("contextmenu", onContextMenu);

    // Kısayolları engelle
    const onKeyDown = (e: KeyboardEvent) => {
      // F12 (devtools), Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U, Ctrl+C
      if (
        e.key === "F12" ||
        (e.ctrlKey && e.shiftKey && (e.key === "I" || e.key === "J")) ||
        (e.ctrlKey && (e.key === "U" || e.key === "u" || e.key === "c" || e.key === "C"))
      ) {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    document.addEventListener("keydown", onKeyDown);

    // Seçimi/kopyalamayı önle
    const onCopy = (e: ClipboardEvent) => {
      e.preventDefault();
    };
    document.addEventListener("copy", onCopy);
    document.addEventListener("cut", onCopy);
    document.addEventListener("selectstart", onCopy);

    return () => {
      document.removeEventListener("contextmenu", onContextMenu);
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("copy", onCopy);
      document.removeEventListener("cut", onCopy);
      document.removeEventListener("selectstart", onCopy);
    };
  }, []);

  if (!isMounted) {
    return null; // Hidrasyon tamamlanana kadar bir şey gösterme
  }

  // Kullanıcı giriş ekranını atlayıp doğrudan WelcomeScreen'e yönlendiriyoruz
  if (!isStarted) {
    return <WelcomeScreen />;
  }

  if (isCompleted) {
    return <ResultScreen />;
  }

  return <ScenarioScreen />;
}
