"use client";

import { useState } from "react";
import { useGameStore } from "@/store/gameStore";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CyberContainer, CyberGlitchText } from "@/components/ui/cyber-effects";
import { Certificate } from "./Certificate";
import { ImprovedCertificate } from "./ImprovedCertificate";
import type { ScenarioType } from "@/store/gameStore";
import { LevelProgress } from "./LevelProgress";
import { Leaderboard } from "./Leaderboard";
import { Achievements } from "./Achievements";

// Kategori adlarını Türkçeye çeviren yardımcı fonksiyon
const categoryNames: Record<ScenarioType, string> = {
  phishing: "Oltalama",
  password: "Şifre Güvenliği",
  software: "Yazılım Güvenliği",
  social: "Sosyal Mühendislik",
  network: "Ağ Güvenliği",
  terminal: "Terminal Güvenliği",
  desktop: "Masaüstü Güvenliği",
  mobile: "Mobil Güvenlik",
  physical: "Fiziksel Güvenlik",
  ai: "Yapay Zeka Güvenliği",
  blockchain: "Blockchain Güvenliği",
  iot: "IoT Güvenliği"
};

export function ResultScreen() {
  const {
    username,
    score,
    scenarios,
    getScorePercentage,
    getRiskPercentage,
    resetGame,
    showCertificate,
    setShowCertificate,
    useImprovedCertificate,
    setUseImprovedCertificate,
    getDetailedScoreAnalysis,
    getCategoryPerformance
  } = useGameStore();

  const [showShareOptions, setShowShareOptions] = useState(false);
  const [progressHistory, setProgressHistory] = useState<{date: string, score: number, detailedScore: number}[]>(() => {
    // Tarayıcı localStorage'dan ilerleme geçmişini getir
    const savedHistory = typeof window !== 'undefined' ? localStorage.getItem(`${username}-progress-history`) : null;
    return savedHistory ? JSON.parse(savedHistory) : [];
  });
  const [showProgressChart, setShowProgressChart] = useState(false);
  const [showCategoryChart, setShowCategoryChart] = useState(false);
  const [showDetailedScore, setShowDetailedScore] = useState(false);

  // Skoru hesapla
  const scorePercentage = getScorePercentage();
  const riskPercentage = getRiskPercentage();
  const totalPossibleScore = scenarios.length;

  // Detaylı puan analizi
  const detailedScore = getDetailedScoreAnalysis();
  const categoryPerformance = getCategoryPerformance();

  // En iyi ve en zayıf kategorileri bul
  const sortedCategories = [...categoryPerformance].sort((a, b) => b.percentage - a.percentage);
  const bestCategory = sortedCategories.length > 0 ? sortedCategories[0] : null;
  const worstCategory = sortedCategories.length > 0 ? sortedCategories[sortedCategories.length - 1] : null;

  // Mevcut ilerleme kaydını sakla
  useState(() => {
    if (username && score > 0) {
      // Yeni puan sistemi ile detaylı puan bilgisini kullan
      const newEntry = {
        date: new Date().toLocaleDateString('tr-TR'),
        score: scorePercentage,
        detailedScore: detailedScore.finalScore
      };
      const updatedHistory = [...progressHistory, newEntry];

      // En fazla son 10 ilerlemeyi sakla
      const limitedHistory = updatedHistory.slice(-10);
      setProgressHistory(limitedHistory);

      if (typeof window !== 'undefined') {
        localStorage.setItem(`${username}-progress-history`, JSON.stringify(limitedHistory));
      }
    }
  });

  // Risk ve skor durumuna göre genel bir başarı durumu belirle
  const getStatusInfo = () => {
    // Detaylı puan analizine göre hesaplama yap
    const finalScore = detailedScore.finalScore;

    if (finalScore >= 85 && riskPercentage < 25) {
      return {
        title: "Tebrikler! Siber Güvenlik Uzmanı",
        description: "Olağanüstü performans gösterdiniz. Siber güvenlik prensiplerini çok iyi anladığınız belli oluyor.",
        color: "text-green-500",
        badge: "bg-green-900/50 text-green-500",
        icon: "🏆"
      };
    }

    if (finalScore >= 70 && riskPercentage < 40) {
      return {
        title: "İyi İş! Güvenlik Bilinci Yüksek",
        description: "Temel siber güvenlik prensiplerini anladığınız görülüyor, ancak hala geliştirilebilecek alanlar var.",
        color: "text-blue-500",
        badge: "bg-blue-900/50 text-blue-500",
        icon: "🔰"
      };
    }

    if (finalScore >= 50 && riskPercentage < 60) {
      return {
        title: "Gelişim Gerekli",
        description: "Siber güvenlik konusunda bazı temel bilgilere sahipsiniz, ancak daha fazla eğitim ve pratik yapmanız önemli.",
        color: "text-yellow-500",
        badge: "bg-yellow-900/50 text-yellow-500",
        icon: "📖"
      };
    }

    return {
      title: "Risk Altında",
      description: "Siber güvenlik konusunda ciddi eksiklikleriniz var. Temel güvenlik prensiplerine daha fazla çalışmanız gerekiyor.",
      color: "text-red-500",
      badge: "bg-red-900/50 text-red-500",
      icon: "⚠️"
    };
  };

  const status = getStatusInfo();

  // Senaryo türlerine göre öğrenilen temel prensipleri göster
  const lessonsByType = {
    phishing: [
      "E-postaların gönderen adresini ve domain adını her zaman kontrol edin",
      "Aciliyet bildiren ve hızlı aksiyon istenen şüpheli e-postalara karşı dikkatli olun",
      "Şüpheli e-postaları IT departmanınıza bildirin"
    ],
    password: [
      "Güçlü parolalar en az 12 karakter olmalı ve karışık karakterler içermeli",
      "Farklı hesaplar için aynı şifreyi kullanmayın",
      "Çok faktörlü kimlik doğrulama (MFA) kullanın"
    ],
    software: [
      "Önemli güvenlik güncellemelerini ertelemeyin",
      "Bilinmeyen kaynaklardan yazılım ve uygulama yüklemeyin",
      "Bilinmeyen USB cihazlarını sistemlere bağlamayın"
    ],
    social: [
      "Doğrulanmamış kişilere asla sistem erişimi vermeyin",
      "Şüpheli talepleri farklı bir kanal üzerinden doğrulayın",
      "Kimlik doğrulama olmadan hassas bilgileri paylaşmayın"
    ],
    terminal: [
      "Terminal komutlarını kullanırken süper kullanıcı yetkilerini dikkatli kullanın",
      "Sistem loglarını düzenli olarak kontrol edin",
      "Şüpheli etkinlikleri izlemek için terminal araçlarını kullanın"
    ],
    desktop: [
      "Bilinmeyen kaynaklardan gelen uygulamaları çalıştırmayın",
      "Masaüstü bildirimlerine dikkat edin ve güvenlik uyarılarını ciddiye alın",
      "Dosya paylaşırken güvenlik ayarlarını kontrol edin"
    ],
    network: [
      "Ağ trafiğini düzenli olarak izleyin ve anormal aktiviteleri tespit edin",
      "Güvenlik duvarı ve VPN kullanarak ağ güvenliğini artırın",
      "Ağ cihazlarının varsayılan şifrelerini değiştirin"
    ]
  };

  // Sosyal medyada paylaşım URL'lerini oluştur
  const getShareUrls = () => {
    const shareText = `Siber Güvenlik Simülasyonu'nda %${scorePercentage.toFixed(0)} başarı elde ettim! Siz de kendi siber güvenlik becerilerinizi test edin.`;
    const shareUrl = typeof window !== 'undefined' ? window.location.href : '';

    return {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}&title=${encodeURIComponent(shareText)}`,
      whatsapp: `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`
    };
  };

  // Paylaşım butonlarını render et
  const renderShareButtons = () => {
    const shareUrls = getShareUrls();

    return (
      <div className="mt-4 space-y-3">
        <h3 className="text-center text-primary font-medium">Sonucu Paylaş</h3>
        <div className="flex justify-center space-x-4">
          <a
            href={shareUrls.twitter}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-full bg-blue-500 hover:bg-blue-600 text-white flex items-center space-x-2"
          >
            <span>Twitter</span>
          </a>
          <a
            href={shareUrls.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-full bg-blue-700 hover:bg-blue-800 text-white flex items-center space-x-2"
          >
            <span>LinkedIn</span>
          </a>
          <a
            href={shareUrls.whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-full bg-green-500 hover:bg-green-600 text-white flex items-center space-x-2"
          >
            <span>WhatsApp</span>
          </a>
        </div>
      </div>
    );
  };

  // İlerleme geçmişini göster
  const renderProgressHistory = () => {
    if (progressHistory.length <= 1) {
      return (
        <div className="text-center text-gray-400 text-sm p-4">
          Henüz yeterli ilerleme kaydı yok. Daha fazla simülasyon tamamladıkça ilerlemeniz burada görüntülenecek.
        </div>
      );
    }

    return (
      <div className="space-y-3 p-4">
        <h3 className="text-primary font-medium text-center">İlerleme Geçmişi</h3>
        <div className="h-40 relative border border-gray-700 rounded-md p-2">
          <div className="w-full h-full flex items-end">
            {progressHistory.map((entry, index) => (
              <div key={`progress-${index}`} className="flex-1 flex flex-col items-center">
                <div
                  className="w-full mx-1"
                  style={{
                    height: `${entry.detailedScore || entry.score}%`,
                    maxHeight: '100%',
                    background: 'linear-gradient(to top, #334155, #0ea5e9)'
                  }}
                ></div>
                <div className="text-xs mt-1 rotate-45 origin-left text-gray-500">{entry.date}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="text-xs text-center text-gray-400">
          Son {progressHistory.length} simülasyon sonucu
        </div>
      </div>
    );
  };

  // Kategori performansını göster
  const renderCategoryPerformance = () => {
    if (categoryPerformance.length === 0) {
      return (
        <div className="text-center text-gray-400 text-sm p-4">
          Henüz hiçbir kategori tamamlanmadı. Farklı kategorilerde senaryoları tamamlayarak detaylı analiz alabilirsiniz.
        </div>
      );
    }

    return (
      <div className="space-y-6 p-4">
        <h3 className="text-primary font-medium text-center">Kategori Bazlı Performans</h3>

        {/* Yeni Gelişmiş Yetenek Skorları Tablosu */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left py-2 px-2 text-sm font-medium text-gray-400">Kategori</th>
                <th className="text-left py-2 px-2 text-sm font-medium text-gray-400">Doğru/Toplam</th>
                <th className="text-right py-2 px-2 text-sm font-medium text-gray-400">Başarı</th>
                <th className="text-right py-2 px-2 text-sm font-medium text-gray-400">Yetenek Seviyesi</th>
              </tr>
            </thead>
            <tbody>
              {categoryPerformance.map((cat) => (
                <tr key={cat.category} className="border-b border-gray-800 hover:bg-gray-900/30">
                  <td className="py-3 px-2 font-medium">{categoryNames[cat.category as ScenarioType]}</td>
                  <td className="py-3 px-2">{cat.correct}/{cat.total}</td>
                  <td className="py-3 px-2 text-right">
                    <span className={
                      cat.percentage >= 90 ? "text-green-400" :
                      cat.percentage >= 70 ? "text-green-500" :
                      cat.percentage >= 50 ? "text-yellow-500" :
                      "text-red-500"
                    }>
                      %{Math.round(cat.percentage)}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-right">
                    <Badge className={
                      cat.percentage >= 90 ? "bg-green-900/50 text-green-400" :
                      cat.percentage >= 70 ? "bg-blue-900/50 text-blue-400" :
                      cat.percentage >= 50 ? "bg-yellow-900/50 text-yellow-400" :
                      cat.percentage >= 30 ? "bg-orange-900/50 text-orange-400" :
                      "bg-red-900/50 text-red-400"
                    }>
                      {cat.skillLevel}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Grafik Sütunlar */}
        <div className="pt-6">
          <h4 className="text-center text-sm font-medium text-gray-400 mb-4">Yetenek Görselleştirmesi</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {categoryPerformance.map((cat) => (
              <div key={`bar-${cat.category}`} className="flex flex-col items-center">
                <div className="w-full flex flex-col items-center">
                  <div
                    className="w-8 rounded-t-md"
                    style={{
                      height: `${cat.skillRating}px`,
                      background: cat.percentage >= 90 ? 'linear-gradient(to top, #065f46, #10b981)' :
                                cat.percentage >= 70 ? 'linear-gradient(to top, #1e40af, #3b82f6)' :
                                cat.percentage >= 50 ? 'linear-gradient(to top, #854d0e, #eab308)' :
                                cat.percentage >= 30 ? 'linear-gradient(to top, #9a3412, #f97316)' :
                                'linear-gradient(to top, #7f1d1d, #ef4444)'
                    }}
                  ></div>
                  <div className="mt-2 text-center text-xs text-gray-400 truncate max-w-[80px]">
                    {categoryNames[cat.category as ScenarioType]}
                  </div>
                </div>
                <div className="mt-1 text-center text-xs font-medium" style={{
                  color: cat.percentage >= 90 ? '#10b981' :
                         cat.percentage >= 70 ? '#3b82f6' :
                         cat.percentage >= 50 ? '#eab308' :
                         cat.percentage >= 30 ? '#f97316' :
                         '#ef4444'
                }}>
                  %{Math.round(cat.percentage)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Eski kod */}
        <div className="space-y-4">
          {categoryPerformance.map((cat) => (
            <div key={cat.category} className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="font-medium">{categoryNames[cat.category as ScenarioType]}</span>
                <span className={cat.percentage >= 70 ? "text-green-500" : cat.percentage >= 50 ? "text-yellow-500" : "text-red-500"}>
                  {cat.correct}/{cat.total} ({Math.round(cat.percentage)}%)
                </span>
              </div>
              <Progress
                value={cat.percentage}
                className="h-2 bg-gray-800"
                indicatorClassName={
                  cat.percentage >= 70 ? "bg-green-500" : cat.percentage >= 50 ? "bg-yellow-500" : "bg-red-500"
                }
              />
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Detaylı puan analizini göster
  const renderDetailedScore = () => {
    return (
      <div className="space-y-3 p-4">
        <h3 className="text-primary font-medium text-center">Detaylı Puan Analizi</h3>

        <div className="grid gap-3 text-sm">
          <div className="flex justify-between items-center">
            <span>Temel Başarı Puanı:</span>
            <span className="font-bold text-base">{Math.round(detailedScore.basePercentage)}%</span>
          </div>

          <div className="space-y-2 border-l-2 border-blue-500/30 pl-3 ml-2">
            <div className="flex justify-between">
              <span>Hızlı Cevap Bonusu:</span>
              <span className="text-blue-400">+{detailedScore.bonusPoints.timeBonus} puan</span>
            </div>
            <div className="flex justify-between">
              <span>Zorluk Seviyesi Bonusu:</span>
              <span className="text-purple-400">+{detailedScore.bonusPoints.difficultyBonus} puan</span>
            </div>
            <div className="flex justify-between">
              <span>Tutarlılık Bonusu:</span>
              <span className="text-green-400">+{detailedScore.bonusPoints.consistencyBonus} puan</span>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-2 mt-2">
            <div className="flex justify-between font-bold">
              <span>Toplam Bonus:</span>
              <span className="text-primary">+{detailedScore.totalBonusPoints} puan</span>
            </div>
          </div>

          <div className="bg-gray-800/50 p-3 rounded-md mt-3 flex justify-between items-center">
            <span className="font-semibold">GENEL BAŞARI PUANI:</span>
            <span className="text-lg font-bold text-primary">{Math.round(detailedScore.finalScore)}%</span>
          </div>
        </div>

        <div className="text-xs text-center text-gray-400 mt-3">
          Başarı puanı, temel doğru cevapların yanı sıra hızınız, zorlu görevlerdeki başarınız ve tutarlı performansınız göz önünde bulundurularak hesaplanır.
        </div>
      </div>
    );
  };

  if (showCertificate) {
    return useImprovedCertificate ? <ImprovedCertificate /> : <Certificate />;
  }

  return (
    <div className="flex flex-col min-h-screen bg-black text-white p-4">
      <div className="max-w-3xl mx-auto w-full">
        <CyberContainer className="mb-6">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold tracking-tighter mb-2">
              <CyberGlitchText intensity="medium">SİMÜLASYON TAMAMLANDI</CyberGlitchText>
            </CardTitle>
            <CardDescription className="text-lg">
              {username}, siber güvenlik simülasyonunu tamamladınız!
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Başarı durumu */}
            <div className="text-center mb-6">
              <Badge className={status.badge}>{status.icon} {status.title}</Badge>
              <p className="mt-2">{status.description}</p>
            </div>

            {/* Seviye İlerleme ve XP */}
            <LevelProgress />

            {/* Detaylı Puan Analizi Butonu */}
            <Button
              variant="outline"
              onClick={() => setShowDetailedScore(!showDetailedScore)}
              className="w-full mb-4"
            >
              {showDetailedScore ? 'Detaylı Puan Analizini Gizle' : 'Detaylı Puan Analizini Göster'}
            </Button>

            {showDetailedScore && (
              <Card className="bg-black/50 border-primary/30">
                <CardContent className="p-0">
                  {renderDetailedScore()}
                </CardContent>
              </Card>
            )}

            {/* Skor bilgileri */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-black/50 border-primary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-primary">Performans Özeti</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Doğru Kararlar:</span>
                      <span className="text-green-500">{score} / {totalPossibleScore}</span>
                    </div>
                    <Progress value={scorePercentage} className="h-2 bg-green-950" indicatorClassName="bg-green-500" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Risk Seviyesi:</span>
                      <span className={riskPercentage > 50 ? "text-red-500" : "text-yellow-500"}>
                        %{riskPercentage.toFixed(0)}
                      </span>
                    </div>
                    <Progress value={riskPercentage} className="h-2 bg-red-950" indicatorClassName="bg-red-500" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Ödül Puanı:</span>
                      <span className="text-blue-500">
                        +{detailedScore.totalBonusPoints} puan
                      </span>
                    </div>
                    <Progress
                      value={Math.min(detailedScore.totalBonusPoints, 25) * 4}
                      className="h-2 bg-blue-950"
                      indicatorClassName="bg-blue-500"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/50 border-primary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-primary">Elde Edilen Rozetler</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    {detailedScore.finalScore >= 30 && (
                      <Badge className="bg-blue-900/30 text-blue-400 p-2 flex items-center justify-center">
                        Başlangıç Seviyesi 🔰
                      </Badge>
                    )}
                    {detailedScore.finalScore >= 50 && (
                      <Badge className="bg-green-900/30 text-green-400 p-2 flex items-center justify-center">
                        Tehdit Avcısı 🔍
                      </Badge>
                    )}
                    {detailedScore.finalScore >= 70 && (
                      <Badge className="bg-yellow-900/30 text-yellow-400 p-2 flex items-center justify-center">
                        Güvenlik Analisti 🛡️
                      </Badge>
                    )}
                    {detailedScore.finalScore >= 90 && (
                      <Badge className="bg-purple-900/30 text-purple-400 p-2 flex items-center justify-center">
                        Siber Savunma Uzmanı 🔒
                      </Badge>
                    )}
                    {riskPercentage < 20 && (
                      <Badge className="bg-cyan-900/30 text-cyan-400 p-2 flex items-center justify-center">
                        Düşük Risk 🌟
                      </Badge>
                    )}
                    {(score === totalPossibleScore) && (
                      <Badge className="bg-purple-900/30 text-purple-400 p-2 flex items-center justify-center">
                        Mükemmel Skor 🏆
                      </Badge>
                    )}
                    {detailedScore.bonusPoints.timeBonus >= 10 && (
                      <Badge className="bg-blue-900/30 text-blue-400 p-2 flex items-center justify-center">
                        Hızlı Tepki ⚡
                      </Badge>
                    )}
                    {detailedScore.bonusPoints.consistencyBonus >= 5 && (
                      <Badge className="bg-green-900/30 text-green-400 p-2 flex items-center justify-center">
                        Tutarlı Performans 📊
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Başarılar Paneli */}
            <Achievements />

            {/* Liderlik Tablosu */}
            <Leaderboard />

            {/* Kategori Performansı Butonu */}
            <Button
              variant="outline"
              onClick={() => setShowCategoryChart(!showCategoryChart)}
              className="w-full mt-4 mb-2"
            >
              {showCategoryChart ? 'Kategori Performansını Gizle' : 'Kategori Performansını Göster'}
            </Button>

            {showCategoryChart && (
              <Card className="bg-black/50 border-primary/30">
                <CardContent className="p-0">
                  {renderCategoryPerformance()}
                </CardContent>
              </Card>
            )}

            {/* İlerleme Geçmişi */}
            <div className="pt-4">
              <Button
                variant="outline"
                onClick={() => setShowProgressChart(!showProgressChart)}
                className="w-full mb-2"
              >
                {showProgressChart ? 'İlerleme Geçmişini Gizle' : 'İlerleme Geçmişini Göster'}
              </Button>

              {showProgressChart && (
                <Card className="bg-black/50 border-primary/30">
                  <CardContent className="p-0">
                    {renderProgressHistory()}
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Öğrenilen dersler */}
            <Card className="bg-black/50 border-primary/30 mt-6">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-primary">Öğrenilen Temel Prensipler</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h4 className="font-semibold text-red-500 mb-2">Oltalama (Phishing) Koruması</h4>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                      {lessonsByType.phishing.map((lesson) => (
                        <li key={lesson}>{lesson}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-blue-500 mb-2">Şifre Güvenliği</h4>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                      {lessonsByType.password.map((lesson) => (
                        <li key={lesson}>{lesson}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-green-500 mb-2">Yazılım Güvenliği</h4>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                      {lessonsByType.software.map((lesson) => (
                        <li key={lesson}>{lesson}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-yellow-500 mb-2">Sosyal Mühendislik</h4>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                      {lessonsByType.social.map((lesson) => (
                        <li key={lesson}>{lesson}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-purple-500 mb-2">Terminal Güvenliği</h4>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                      {lessonsByType.terminal.map((lesson) => (
                        <li key={lesson}>{lesson}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-cyan-500 mb-2">Masaüstü Güvenliği</h4>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                      {lessonsByType.desktop.map((lesson) => (
                        <li key={lesson}>{lesson}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-pink-500 mb-2">Ağ Güvenliği</h4>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                      {lessonsByType.network.map((lesson) => (
                        <li key={lesson}>{lesson}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Yeni: En İyi ve En Zayıf kategorileri göster */}
                  {bestCategory && worstCategory && bestCategory.category !== worstCategory.category && (
                    <div className="md:col-span-2 border border-gray-700 rounded-md p-3 bg-black/30 mt-2">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-semibold text-green-500 mb-2">En İyi Performans Gösterdiğiniz Alan</h4>
                          <p className="text-sm">
                            <span className="font-medium">{categoryNames[bestCategory.category as ScenarioType]}</span> - %{Math.round(bestCategory.percentage)} başarı
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold text-red-500 mb-2">Geliştirilmesi Gereken Alan</h4>
                          <p className="text-sm">
                            <span className="font-medium">{categoryNames[worstCategory.category as ScenarioType]}</span> - %{Math.round(worstCategory.percentage)} başarı
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </CardContent>
        </CyberContainer>

        <div className="text-center space-y-4">
          {/* Sosyal Paylaşım Butonu */}
          <Button
            variant="outline"
            className="w-full max-w-md mb-2 border-blue-500/50 text-blue-400 hover:bg-blue-900/20"
            onClick={() => setShowShareOptions(!showShareOptions)}
          >
            <span className="mr-2">🔗</span>
            {showShareOptions ? 'Paylaşım Seçeneklerini Gizle' : 'Sonuçları Sosyal Medyada Paylaş'}
          </Button>

          {showShareOptions && renderShareButtons()}

          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              onClick={() => {
                setUseImprovedCertificate(true);
                setShowCertificate(true);
              }}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              Instagram Paylaşımlı Sertifika
            </Button>

            <Button
              onClick={() => {
                setUseImprovedCertificate(false);
                setShowCertificate(true);
              }}
              size="lg"
              className="bg-primary hover:bg-primary/80"
            >
              Standart Sertifika
            </Button>
          </div>

          <Button
            onClick={resetGame}
            variant="outline"
            size="lg"
            className="w-full max-w-md mt-4"
          >
            Simülasyonu Tekrar Başlat
          </Button>

          <p className="mt-4 text-muted-foreground">
            Tebrikler! Simülasyonu tamamladınız. Öğrendiğiniz bilgileri gerçek hayatta uygulayarak siber tehditlere karşı daha hazırlıklı olabilirsiniz.
          </p>
        </div>
      </div>
    </div>
  );
}
