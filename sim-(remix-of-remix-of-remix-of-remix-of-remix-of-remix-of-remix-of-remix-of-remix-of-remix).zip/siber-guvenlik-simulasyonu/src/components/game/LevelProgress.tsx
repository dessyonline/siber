"use client";

import { useState, useEffect } from "react";
import { useGameStore } from "@/store/gameStore";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";

// Seviye başına verilen rozet simgeleri
const LEVEL_BADGES: Record<number, { icon: string; name: string; color: string }> = {
  1: { icon: '🔰', name: 'Çaylak', color: 'from-green-500 to-green-700' },
  3: { icon: '🛡️', name: 'Savunmacı', color: 'from-blue-500 to-blue-700' },
  5: { icon: '🔍', name: 'Analist', color: 'from-cyan-500 to-cyan-700' },
  7: { icon: '🔒', name: 'Güvenlik Uzmanı', color: 'from-purple-500 to-purple-700' },
  10: { icon: '🏆', name: 'Siber Kahraman', color: 'from-yellow-500 to-yellow-700' },
  15: { icon: '💎', name: 'Efsane Savunucusu', color: 'from-red-500 to-red-700' },
};

export function LevelProgress() {
  const { level, xp, xpForNextLevel, getLevel } = useGameStore();
  const [showTooltip, setShowTooltip] = useState(false);
  const [animateXP, setAnimateXP] = useState(false);
  const [previousXP, setPreviousXP] = useState(xp);
  const [previousLevel, setPreviousLevel] = useState(level);

  // Mevcut seviye ve ilerleme durumu
  const { progress } = getLevel();

  // XP değişikliklerini izle ve animasyon tetikle
  useEffect(() => {
    if (xp !== previousXP) {
      setAnimateXP(true);
      const timer = setTimeout(() => {
        setAnimateXP(false);
      }, 2000);
      setPreviousXP(xp);
      return () => clearTimeout(timer);
    }
  }, [xp, previousXP]);

  // Seviye değişimini izle
  useEffect(() => {
    if (level !== previousLevel) {
      // Seviye atlama animasyonu tetiklenebilir
      setPreviousLevel(level);
    }
  }, [level, previousLevel]);

  // Kullanıcının mevcut seviye rozeti
  const getCurrentBadge = () => {
    // Seviye rozetlerini azalan sırada kontrol et
    const levels = Object.keys(LEVEL_BADGES)
      .map(Number)
      .sort((a, b) => b - a);

    // Kullanıcının seviyesi için geçerli en yüksek rozeti bul
    for (const badgeLevel of levels) {
      if (level >= badgeLevel) {
        return LEVEL_BADGES[badgeLevel];
      }
    }

    // Varsayılan (1. seviye rozeti)
    return LEVEL_BADGES[1];
  };

  const currentBadge = getCurrentBadge();

  // Bir sonraki rozete kaç seviye kaldığını hesapla
  const getNextBadgeInfo = () => {
    const levels = Object.keys(LEVEL_BADGES)
      .map(Number)
      .sort((a, b) => a - b);

    for (const badgeLevel of levels) {
      if (level < badgeLevel) {
        return {
          level: badgeLevel,
          icon: LEVEL_BADGES[badgeLevel].icon,
          name: LEVEL_BADGES[badgeLevel].name,
          levelsRemaining: badgeLevel - level
        };
      }
    }

    // En yüksek seviyedeyse
    return null;
  };

  const nextBadgeInfo = getNextBadgeInfo();

  return (
    <Card className="bg-black/30 border border-primary/20 p-4 mb-4 relative overflow-hidden">
      {/* Arka plan efekti */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

      <div className="relative z-10">
        <div className="flex justify-between items-center mb-2">
          <div
            className="flex items-center gap-3"
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
          >
            <div className={`text-2xl h-12 w-12 flex items-center justify-center rounded-full bg-gradient-to-br ${currentBadge.color} shadow-lg`}>
              {currentBadge.icon}
            </div>
            <div>
              <h3 className="font-semibold text-white text-lg group flex items-center">
                Seviye {level}
                {level > previousLevel && (
                  <motion.span
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="ml-2 text-yellow-400"
                  >
                    ⬆️
                  </motion.span>
                )}
              </h3>
              <p className="text-sm text-gray-400">{currentBadge.name}</p>
            </div>
          </div>

          <div className="text-right">
            <Badge className="bg-primary/20 text-primary mb-1">
              {xp} / {xpForNextLevel} XP
            </Badge>

            <AnimatePresence>
              {animateXP && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="text-xs text-green-400"
                >
                  +{xp - previousXP} XP kazandınız!
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="relative">
          <Progress
            value={progress}
            className="h-3 bg-gray-800 rounded-full overflow-hidden"
            indicatorClassName={`bg-gradient-to-r ${currentBadge.color}`}
          />

          {/* XP artış animasyonları */}
          <AnimatePresence>
            {animateXP && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="absolute -right-1 -top-1 text-lg"
              >
                ✨
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Sonraki rozet bilgisi */}
        {nextBadgeInfo && (
          <div className="mt-3 text-xs text-gray-400 flex justify-between items-center">
            <span>Mevcut: {currentBadge.name}</span>
            <div className="flex items-center">
              <span>Sonraki: </span>
              <span className="flex items-center ml-1 text-primary/80">
                {nextBadgeInfo.icon} {nextBadgeInfo.name}
                <span className="ml-2 bg-primary/10 px-1.5 py-0.5 rounded text-primary">
                  {nextBadgeInfo.levelsRemaining} seviye kaldı
                </span>
              </span>
            </div>
          </div>
        )}
      </div>

      {showTooltip && (
        <div className="absolute top-full mt-2 left-0 right-0 z-50 bg-black border border-primary/30 p-3 rounded-md shadow-lg text-sm">
          <h4 className="font-semibold text-primary mb-2">Seviye Sistemi</h4>
          <p className="mb-2">Seviyeniz, oyundaki ilerleyişinizi ve deneyiminizi gösterir. Aşağıdaki yollarla XP kazanabilirsiniz:</p>
          <ul className="space-y-1 list-disc pl-5">
            <li>Doğru yanıtlar: <span className="text-green-400">+10 XP</span></li>
            <li>Hızlı cevaplar: <span className="text-blue-400">+5 XP bonus</span></li>
            <li>Zorlu senaryolar: <span className="text-purple-400">+5 XP bonus</span></li>
            <li>Başarılar: <span className="text-yellow-400">+50 XP</span></li>
          </ul>

          <div className="mt-3 pt-3 border-t border-gray-700">
            <h5 className="font-medium text-primary/80 mb-1">Rozet Seviyeleri</h5>
            <div className="grid grid-cols-3 gap-2">
              {Object.entries(LEVEL_BADGES).map(([badgeLevel, badge]) => (
                <div key={badgeLevel} className={`p-1.5 rounded ${level >= Number(badgeLevel) ? 'bg-primary/10' : 'bg-gray-800/50'} flex items-center`}>
                  <span className="mr-2">{badge.icon}</span>
                  <div>
                    <div className={`text-xs ${level >= Number(badgeLevel) ? 'text-primary' : 'text-gray-400'}`}>
                      {badge.name}
                    </div>
                    <div className="text-xs text-gray-500">Seviye {badgeLevel}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <p className="mt-3 text-gray-400 text-xs">Her seviye atladığınızda gerekli XP miktarı artar.</p>
        </div>
      )}
    </Card>
  );
}
