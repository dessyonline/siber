"use client";

import React, { useState } from "react";
import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CyberGlitchText } from "@/components/ui/cyber-effects";

// İçerik türleri
export type MediaType = "image" | "video" | "animation" | "infographic" | "text";

export interface MediaContent {
  id: string;
  title: string;
  description: string;
  type: MediaType;
  source: string;
  creditText?: string;
  creditUrl?: string;
  tags?: string[];
}

interface MultimediaViewerProps {
  content: MediaContent | null;
  onClose?: () => void;
  className?: string;
}

export function MultimediaViewer({ content, onClose, className = "" }: MultimediaViewerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  if (!content) {
    return null;
  }

  const handleMediaLoaded = () => {
    setIsLoaded(true);
  };

  return (
    <Card className={`border-primary/30 bg-black text-white overflow-hidden ${className}`}>
      <CardHeader className="p-4 border-b border-primary/20">
        <div className="flex justify-between items-center">
          <CardTitle className="text-primary text-xl">
            <CyberGlitchText intensity="low">{content.title}</CyberGlitchText>
          </CardTitle>
          {onClose && (
            <Button variant="ghost" size="sm" onClick={onClose} className="h-8 w-8 p-0">
              ✕
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="relative">
          {/* Medya içerik bölümü */}
          {content.type !== "text" && (
            <div className="relative bg-gray-900 w-full">
              {!isLoaded && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-800">
                  <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-primary rounded-full"></div>
                </div>
              )}

              {content.type === "image" && content.source && (
                <div className="relative bg-gray-900" style={{ height: '500px' }}>
                  <Image
                    src={content.source}
                    alt={content.title}
                    fill
                    className="object-contain"
                    style={{ opacity: isLoaded ? 1 : 0 }}
                    onLoad={handleMediaLoaded}
                    priority
                  />
                </div>
              )}

              {content.type === "video" && content.source && (
                <div className="bg-gray-900" style={{ height: '500px' }}>
                  <video
                    src={content.source}
                    controls
                    className="w-full h-full"
                    onLoadedData={handleMediaLoaded}
                    autoPlay={isPlaying}
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                  />
                </div>
              )}

              {content.type === "animation" && content.source && (
                <div className="relative bg-gray-900" style={{ height: '500px' }}>
                  <Image
                    src={content.source}
                    alt={content.title}
                    fill
                    className="object-contain"
                    style={{ opacity: isLoaded ? 1 : 0 }}
                    onLoad={handleMediaLoaded}
                    priority
                  />
                </div>
              )}

              {content.type === "infographic" && content.source && (
                <div className="relative bg-gray-900" style={{ height: '600px' }}>
                  <Image
                    src={content.source}
                    alt={content.title}
                    fill
                    className="object-contain"
                    style={{ opacity: isLoaded ? 1 : 0 }}
                    onLoad={handleMediaLoaded}
                    priority
                  />
                </div>
              )}
            </div>
          )}

          {/* Açıklama bölümü */}
          <div className={`p-5 ${content.type !== "text" ? "bg-gray-900/70" : "bg-gray-900"}`}>
            {/* Text içeriği için özel stil */}
            {content.type === "text" ? (
              <div className="py-4">
                <p className="text-white/90 text-base whitespace-pre-line leading-relaxed">{content.description}</p>
              </div>
            ) : (
              <p className="text-white/90 text-base">{content.description}</p>
            )}

            {content.tags && content.tags.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {content.tags.map((tag) => (
                  <Badge key={tag} variant="outline" className="bg-primary/10">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}

            {content.creditText && (
              <div className="mt-3 text-sm text-gray-400">
                Kaynak: {content.creditUrl ? (
                  <a
                    href={content.creditUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    {content.creditText}
                  </a>
                ) : (
                  content.creditText
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
