"use client";

import type React from "react";
import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CyberGlitchText } from "@/components/ui/cyber-effects";
import { Badge } from "@/components/ui/badge";

// Desteklenen terminal komut işlevleri
type CommandFunction = (args: string[]) => string;

interface CommandRegistry {
  [key: string]: {
    function: CommandFunction,
    help: string
  };
}

export function VirtualTerminal() {
  const [commandHistory, setCommandHistory] = useState<string[]>([
    "Siber Güvenlik Eğitim Terminali v1.0",
    "Kullanılabilir komutlar için 'help' yazın.",
    "--------------------------------------",
  ]);
  const [currentCommand, setCurrentCommand] = useState<string>("");
  const [currentPath, setCurrentPath] = useState<string>("/home/user");
  const outputRef = useRef<HTMLDivElement>(null);

  // Terminal scroll otomatik kaydırma
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [commandHistory]);

  // Sanal dosya sistemi
  const fileSystem = {
    "/home/user": {
      "secret.txt": "Bu dosya çok gizli bilgiler içeriyor!",
      "passwords.txt": "admin:admin123\nroot:password123\nuser:12345\n",
      "important_files": {
        "company_data.txt": "Şirket verileri: Ciro: 1.000.000 TL",
        "backup": {
          "system.bak": "Sistem yedek dosyası"
        }
      }
    },
    "/var/log": {
      "auth.log": "Başarısız giriş denemeleri:\n192.168.1.100 - 3 deneme\n192.168.1.120 - 15 deneme [Şüpheli]",
      "system.log": "Sistem günlükleri burada bulunur."
    },
    "/etc": {
      "passwd": "root:x:0:0:root:/root:/bin/bash\nuser:x:1000:1000:User:/home/user:/bin/bash",
      "shadow": "Bu dosyaya erişim engellendi: İzin hatası"
    }
  };

  // Path'in varlığını kontrol eden yardımcı fonksiyon
  const pathExists = (path: string): boolean => {
    const parts = path.split('/').filter(p => p);
    let current: any = fileSystem;

    if (path === '/') return true;

    for (const part of parts) {
      if (!current[part]) return false;
      current = current[part];
    }

    return true;
  };

  // Path'teki içeriği döndüren yardımcı fonksiyon
  const getPathContent = (path: string): any => {
    if (path === '/') return fileSystem;

    const parts = path.split('/').filter(p => p);
    let current: any = fileSystem;

    for (const part of parts) {
      if (!current[part]) return null;
      current = current[part];
    }

    return current;
  };

  // Komut işleme fonksiyonları
  const commands: CommandRegistry = {
    help: {
      function: () => {
        return `Kullanılabilir komutlar:
  help - Bu yardım mesajını gösterir
  ls - Mevcut dizindeki dosyaları listeler
  cd <dizin> - Belirtilen dizine geçer
  pwd - Mevcut çalışma dizinini gösterir
  cat <dosya> - Dosya içeriğini görüntüler
  clear - Terminal ekranını temizler
  whoami - Mevcut kullanıcı adını gösterir
  find <arama> - Mevcut dizinde dosya arar
  grep <kelime> <dosya> - Dosyada kelime arar
  chmod <izinler> <dosya> - Dosya izinlerini değiştirir (simüle edilmiş)`;
      },
      help: "Kullanılabilir komutları listeler"
    },
    ls: {
      function: (args) => {
        const path = args.length > 0 ? args[0] : currentPath;
        const content = getPathContent(path);

        if (!content) return `ls: erişim hatası: '${path}': Böyle bir dosya veya dizin yok`;

        let output = "";
        for (const item in content) {
          if (typeof content[item] === 'object') {
            output += `<span class="text-blue-400">${item}/</span>  `;
          } else {
            output += `${item}  `;
          }
        }

        return output || "Dizin boş";
      },
      help: "Mevcut dizindeki dosyaları listeler"
    },
    cd: {
      function: (args) => {
        if (args.length === 0) {
          setCurrentPath("/home/user");
          return "";
        }

        let newPath = args[0];

        // Göreli yolları işle
        if (!newPath.startsWith("/")) {
          if (newPath === "..") {
            const parts = currentPath.split("/").filter(p => p);
            if (parts.length === 0) return "";

            parts.pop();
            newPath = "/" + parts.join("/");
            if (newPath === "") newPath = "/";
          } else {
            newPath = currentPath === "/" ? `/${newPath}` : `${currentPath}/${newPath}`;
          }
        }

        const content = getPathContent(newPath);
        if (content && typeof content === 'object') {
          setCurrentPath(newPath);
          return "";
        } else {
          return `cd: ${args[0]}: Böyle bir dizin yok`;
        }
      },
      help: "Belirtilen dizine geçer"
    },
    pwd: {
      function: () => {
        return currentPath;
      },
      help: "Mevcut çalışma dizinini gösterir"
    },
    cat: {
      function: (args) => {
        if (args.length === 0) return "cat: dosya belirtilmedi";

        const fileName = args[0];
        const content = getPathContent(currentPath);

        if (!content) return `cat: erişim hatası: Geçersiz dizin`;

        if (content[fileName] && typeof content[fileName] === 'string') {
          return content[fileName];
        } else {
          return `cat: ${fileName}: Böyle bir dosya yok veya bir dizin`;
        }
      },
      help: "Dosya içeriğini görüntüler"
    },
    clear: {
      function: () => {
        setCommandHistory([
          "Siber Güvenlik Eğitim Terminali v1.0",
          "Kullanılabilir komutlar için 'help' yazın.",
          "--------------------------------------",
        ]);
        return "";
      },
      help: "Terminal ekranını temizler"
    },
    whoami: {
      function: () => {
        return "security_student";
      },
      help: "Mevcut kullanıcı adını gösterir"
    },
    find: {
      function: (args) => {
        if (args.length === 0) return "find: arama terimi belirtilmedi";

        const searchTerm = args[0];
        const results: string[] = [];

        // Basit bir arama simülasyonu
        const searchInPath = (path: string, content: any) => {
          for (const item in content) {
            if (item.includes(searchTerm)) {
              results.push(`${path}/${item}`);
            }

            if (typeof content[item] === 'object') {
              searchInPath(`${path}/${item}`, content[item]);
            }
          }
        };

        searchInPath(currentPath, getPathContent(currentPath));

        return results.length ? results.join('\n') : `'${searchTerm}' ile eşleşen sonuç bulunamadı`;
      },
      help: "Mevcut dizinde dosya arar"
    },
    grep: {
      function: (args) => {
        if (args.length < 2) return "grep: kullanım: grep <arama terimi> <dosya>";

        const searchTerm = args[0];
        const fileName = args[1];
        const content = getPathContent(currentPath);

        if (!content) return `grep: erişim hatası: Geçersiz dizin`;

        if (content[fileName] && typeof content[fileName] === 'string') {
          const lines = content[fileName].split('\n');
          const matches = lines.filter(line => line.includes(searchTerm));

          return matches.length
            ? matches.map(line => line.replace(searchTerm, `<span class="text-red-400">${searchTerm}</span>`)).join('\n')
            : `'${searchTerm}' ile eşleşen satır bulunamadı`;
        } else {
          return `grep: ${fileName}: Böyle bir dosya yok veya bir dizin`;
        }
      },
      help: "Dosyada kelime arar"
    },
    chmod: {
      function: (args) => {
        if (args.length < 2) return "chmod: eksik işlem işleneni";

        const permissions = args[0];
        const fileName = args[1];
        const content = getPathContent(currentPath);

        if (!content) return `chmod: erişim hatası: '${fileName}': Böyle bir dosya veya dizin yok`;

        if (!content[fileName]) {
          return `chmod: '${fileName}' dosyası veya dizini bulunamadı`;
        }

        // Sadece simülasyon, gerçekten izinleri değiştirmiyoruz
        return `'${fileName}' dosyasının izinleri '${permissions}' olarak değiştirildi (simüle edildi)`;
      },
      help: "Dosya izinlerini değiştirir (simüle edilmiş)"
    }
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentCommand.trim()) return;

    const commandParts = currentCommand.trim().split(/\s+/);
    const cmd = commandParts[0].toLowerCase();
    const args = commandParts.slice(1);

    // Komut geçmişine ekle
    setCommandHistory(prev => [...prev, `${currentPath}$ ${currentCommand}`]);

    // Komutu çalıştır
    if (commands[cmd]) {
      try {
        const result = commands[cmd].function(args);
        if (result) {
          setCommandHistory(prev => [...prev, result]);
        }
      } catch (error) {
        setCommandHistory(prev => [...prev, `Hata: ${error}`]);
      }
    } else {
      setCommandHistory(prev => [...prev, `${cmd}: komut bulunamadı`]);
    }

    // Input'u temizle
    setCurrentCommand("");
  };

  return (
    <Card className="border-primary/30 bg-black text-white">
      <CardHeader className="p-4 border-b border-primary/20">
        <div className="flex justify-between items-center">
          <CardTitle className="text-primary text-xl">
            <CyberGlitchText intensity="low">Terminal Simülasyonu</CyberGlitchText>
          </CardTitle>
          <Badge variant="outline" className="border-primary/50">bash-5.1$</Badge>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div
          ref={outputRef}
          className="h-96 bg-gray-900/60 p-3 font-mono text-sm overflow-y-auto"
          dangerouslySetInnerHTML={{ __html: commandHistory.join("<br />") }}
        />
        <form onSubmit={handleCommandSubmit} className="p-2 border-t border-primary/30 bg-black/80 flex">
          <div className="text-primary/90 mr-2 font-mono">{currentPath}$</div>
          <Input
            type="text"
            value={currentCommand}
            onChange={(e) => setCurrentCommand(e.target.value)}
            className="bg-transparent border-none focus:ring-0 text-white flex-1 font-mono"
            placeholder="komut yazın..."
            autoComplete="off"
          />
          <Button type="submit" variant="ghost" size="sm" className="ml-2">
            Çalıştır
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
