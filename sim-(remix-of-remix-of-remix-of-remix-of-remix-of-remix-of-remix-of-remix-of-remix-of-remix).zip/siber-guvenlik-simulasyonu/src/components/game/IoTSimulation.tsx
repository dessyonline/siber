"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

interface IoTDeviceProps {
  name: string;
  type: string;
  securityStatus: "secure" | "vulnerable" | "compromised";
  firmwareUpdated: boolean;
  defaultPassword: boolean;
  encryption: boolean;
}

interface IoTSimulationProps {
  type?: "smart-home" | "industrial" | "medical";
  onAction: (action: string) => void;
}

export function IoTSimulation({ type = "smart-home", onAction }: IoTSimulationProps) {
  const [devices, setDevices] = useState<IoTDeviceProps[]>([]);
  const [activeDevice, setActiveDevice] = useState<IoTDeviceProps | null>(null);
  const [networkStatus, setNetworkStatus] = useState<"secure" | "at-risk" | "compromised">("at-risk");
  const [attackProgress, setAttackProgress] = useState(0);
  const [showAttackAlert, setShowAttackAlert] = useState(false);

  // IoT cihaz verilerini yükle
  useEffect(() => {
    const smartHomeDevices: IoTDeviceProps[] = [
      {
        name: "Akıllı Termostat",
        type: "climate",
        securityStatus: "vulnerable",
        firmwareUpdated: false,
        defaultPassword: true,
        encryption: false
      },
      {
        name: "Güvenlik Kamerası",
        type: "security",
        securityStatus: "vulnerable",
        firmwareUpdated: true,
        defaultPassword: true,
        encryption: true
      },
      {
        name: "Akıllı Hoparlör",
        type: "entertainment",
        securityStatus: "secure",
        firmwareUpdated: true,
        defaultPassword: false,
        encryption: true
      },
      {
        name: "Akıllı Kilit",
        type: "security",
        securityStatus: "vulnerable",
        firmwareUpdated: false,
        defaultPassword: false,
        encryption: true
      }
    ];

    const industrialDevices: IoTDeviceProps[] = [
      {
        name: "Üretim Sensörü",
        type: "sensor",
        securityStatus: "vulnerable",
        firmwareUpdated: false,
        defaultPassword: true,
        encryption: false
      },
      {
        name: "Kontrol Sistemi",
        type: "control",
        securityStatus: "compromised",
        firmwareUpdated: false,
        defaultPassword: true,
        encryption: false
      },
      {
        name: "Enerji Monitörü",
        type: "monitor",
        securityStatus: "secure",
        firmwareUpdated: true,
        defaultPassword: false,
        encryption: true
      }
    ];

    const medicalDevices: IoTDeviceProps[] = [
      {
        name: "Hasta Monitörü",
        type: "monitor",
        securityStatus: "secure",
        firmwareUpdated: true,
        defaultPassword: false,
        encryption: true
      },
      {
        name: "İlaç Dispenseri",
        type: "dispenser",
        securityStatus: "vulnerable",
        firmwareUpdated: false,
        defaultPassword: true,
        encryption: true
      },
      {
        name: "Uzaktan Tanı Cihazı",
        type: "diagnostic",
        securityStatus: "vulnerable",
        firmwareUpdated: true,
        defaultPassword: true,
        encryption: false
      }
    ];

    // Senaryo tipine göre cihazları ayarla
    switch (type) {
      case "industrial":
        setDevices(industrialDevices);
        break;
      case "medical":
        setDevices(medicalDevices);
        break;
      default:
        setDevices(smartHomeDevices);
        break;
    }
  }, [type]);

  // Saldırı simülasyonu - 5 saniye sonra uyarı göster
  useEffect(() => {
    const attackTimer = setTimeout(() => {
      setShowAttackAlert(true);

      // Saldırı ilerleme çubuğu animasyonu
      const interval = setInterval(() => {
        setAttackProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + 5;
        });
      }, 500);

      return () => clearInterval(interval);
    }, 5000);

    return () => clearTimeout(attackTimer);
  }, []);

  // Güvenlik durumunu simge olarak göster
  const getSecurityStatusIcon = (status: string) => {
    switch (status) {
      case "secure":
        return "🔒";
      case "vulnerable":
        return "⚠️";
      case "compromised":
        return "🔓";
      default:
        return "❓";
    }
  };

  // Cihaz seçimi işleyicisi
  const handleSelectDevice = (device: IoTDeviceProps) => {
    setActiveDevice(device);
  };

  // Cihaz güvenliğini artırma
  const handleSecureDevice = () => {
    if (!activeDevice) return;

    const updatedDevices = devices.map(device =>
      device.name === activeDevice.name
        ? {
            ...device,
            securityStatus: "secure" as const,
            firmwareUpdated: true,
            defaultPassword: false,
            encryption: true
          }
        : device
    );

    setDevices(updatedDevices);
    setActiveDevice({
      ...activeDevice,
      securityStatus: "secure",
      firmwareUpdated: true,
      defaultPassword: false,
      encryption: true
    });

    // Tüm cihazları kontrol et ve ağ durumunu güncelle
    const allSecure = updatedDevices.every(d => d.securityStatus === "secure");
    const anyCompromised = updatedDevices.some(d => d.securityStatus === "compromised");

    if (allSecure) {
      setNetworkStatus("secure");
      onAction("secure-all-devices");
    } else if (anyCompromised) {
      setNetworkStatus("compromised");
    } else {
      setNetworkStatus("at-risk");
    }
  };

  // Tüm IoT cihazlarını güncelleme
  const handleUpdateAllDevices = () => {
    const updatedDevices = devices.map(device => ({
      ...device,
      securityStatus: "secure" as const,
      firmwareUpdated: true,
      defaultPassword: false,
      encryption: true
    }));

    setDevices(updatedDevices);
    setActiveDevice(null);
    setNetworkStatus("secure");
    onAction("secure-all-devices");
  };

  // Güvenliği görmezden gelme
  const handleIgnoreSecurity = () => {
    // Simulate attack progression
    setAttackProgress(100);

    // Compromise some devices
    const updatedDevices = devices.map((device, index) =>
      index % 2 === 0
        ? { ...device, securityStatus: "compromised" as const }
        : device
    );

    setDevices(updatedDevices);
    setNetworkStatus("compromised");
    onAction("ignore-security");
  };

  return (
    <div className="p-4 border border-primary/20 rounded-md bg-black/80 space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium text-primary">IoT Güvenlik Simülasyonu</h3>
          <p className="text-sm text-gray-400">
            {type === "smart-home" && "Akıllı Ev Cihazları Ağı"}
            {type === "industrial" && "Endüstriyel IoT Sistemleri"}
            {type === "medical" && "Medikal IoT Cihazları"}
          </p>
        </div>

        <Badge className={`
          ${networkStatus === "secure" ? "bg-green-900/50 text-green-400" :
          networkStatus === "at-risk" ? "bg-yellow-900/50 text-yellow-400" :
          "bg-red-900/50 text-red-400 animate-pulse"}
        `}>
          {networkStatus === "secure" ? "Güvenli Ağ" :
           networkStatus === "at-risk" ? "Risk Altında" :
           "Güvenlik İhlali!"}
        </Badge>
      </div>

      {/* Saldırı Uyarısı */}
      {showAttackAlert && (
        <Card className="border-red-500/50 bg-red-950/20 animate-pulse">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className="text-xl mr-2">⚠️</span>
                <div>
                  <h4 className="font-medium text-red-400">IoT Ağı Saldırı Altında</h4>
                  <p className="text-xs text-gray-300">Ağınızdaki cihazlara sızma girişimi algılandı</p>
                </div>
              </div>
              <Progress value={attackProgress} className="w-24 h-2 bg-red-950" indicatorClassName="bg-red-500" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cihaz Listesi */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {devices.map((device) => (
          <Card
            key={device.name}
            className={`cursor-pointer transition-all duration-200 ${
              activeDevice?.name === device.name
                ? "border-primary"
                : "border-gray-800 hover:border-gray-700"
            } ${
              device.securityStatus === "compromised"
                ? "bg-red-950/20"
                : "bg-black/50"
            }`}
            onClick={() => handleSelectDevice(device)}
          >
            <CardContent className="p-3 flex items-center justify-between">
              <div className="flex items-center">
                <span className="text-2xl mr-3">
                  {device.type === "climate" && "🌡️"}
                  {device.type === "security" && "🔒"}
                  {device.type === "entertainment" && "🔊"}
                  {device.type === "sensor" && "📊"}
                  {device.type === "control" && "🎮"}
                  {device.type === "monitor" && "📺"}
                  {device.type === "dispenser" && "💊"}
                  {device.type === "diagnostic" && "🩺"}
                </span>
                <div>
                  <div className="font-medium">{device.name}</div>
                  <div className="text-xs text-gray-400">{device.type}</div>
                </div>
              </div>
              <span className="text-xl" title={device.securityStatus}>
                {getSecurityStatusIcon(device.securityStatus)}
              </span>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Seçili Cihaz Detayları */}
      {activeDevice && (
        <Card className="border-primary/30 bg-black/60">
          <CardHeader className="pb-2">
            <CardTitle className="text-md">{activeDevice.name} Güvenlik Detayları</CardTitle>
          </CardHeader>
          <CardContent className="p-4 space-y-3">
            <div className="grid grid-cols-3 gap-2 text-sm">
              <div className={`p-2 border rounded text-center ${activeDevice.firmwareUpdated ? "border-green-500 text-green-400" : "border-red-500 text-red-400"}`}>
                <div className="text-xs">Firmware</div>
                <div>{activeDevice.firmwareUpdated ? "Güncel ✓" : "Eski ✗"}</div>
              </div>
              <div className={`p-2 border rounded text-center ${!activeDevice.defaultPassword ? "border-green-500 text-green-400" : "border-red-500 text-red-400"}`}>
                <div className="text-xs">Şifre</div>
                <div>{!activeDevice.defaultPassword ? "Değiştirilmiş ✓" : "Varsayılan ✗"}</div>
              </div>
              <div className={`p-2 border rounded text-center ${activeDevice.encryption ? "border-green-500 text-green-400" : "border-red-500 text-red-400"}`}>
                <div className="text-xs">Şifreleme</div>
                <div>{activeDevice.encryption ? "Etkin ✓" : "Devre Dışı ✗"}</div>
              </div>
            </div>

            <Button
              className="w-full"
              disabled={activeDevice.securityStatus === "secure"}
              onClick={handleSecureDevice}
            >
              Cihaz Güvenliğini Artır
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Aksiyon Butonları */}
      <div className="grid grid-cols-2 gap-3 pt-2">
        <Button
          variant="outline"
          className="border-green-500/50 hover:border-green-500 hover:bg-green-950/30 text-green-400"
          onClick={handleUpdateAllDevices}
        >
          Tüm Cihazları Güncelle ve Güvenliğini Artır
        </Button>

        <Button
          variant="outline"
          className="border-red-500/50 hover:border-red-500 hover:bg-red-950/30 text-red-400"
          onClick={handleIgnoreSecurity}
        >
          Güvenlik Uyarılarını Görmezden Gel
        </Button>
      </div>
    </div>
  );
}
