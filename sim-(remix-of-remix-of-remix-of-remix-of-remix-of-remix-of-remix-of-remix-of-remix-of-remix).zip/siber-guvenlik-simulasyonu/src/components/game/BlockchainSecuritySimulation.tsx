"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CyberContainer } from "@/components/ui/cyber-effects";

interface Transaction {
  id: string;
  from: string;
  to: string;
  amount: number;
  timestamp: number;
  isValid: boolean;
  isSuspicious: boolean;
  signature: string;
}

interface Wallet {
  address: string;
  publicKey: string;
  privateKey: string;
  balance: number;
  securityLevel: "low" | "medium" | "high";
}

interface BlockchainSecuritySimulationProps {
  type?: "crypto-wallet" | "smart-contract" | "defi";
  onAction: (action: string) => void;
}

export function BlockchainSecuritySimulation({
  type = "crypto-wallet",
  onAction
}: BlockchainSecuritySimulationProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [pendingTransaction, setPendingTransaction] = useState<Transaction | null>(null);
  const [wallet, setWallet] = useState<Wallet>({
    address: "0x7F5aB7c3dE4BD7c8528E3D3aF564b1E2b001d8F9",
    publicKey: "0x04c8ff8a...(kısaltılmış)",
    privateKey: type === "crypto-wallet" ? "b784efd..." : "***********************",
    balance: 2.75,
    securityLevel: "low"
  });

  const [attackProgress, setAttackProgress] = useState(0);
  const [showAttackAlert, setShowAttackAlert] = useState(false);
  const [attackType, setAttackType] = useState<string>("");
  const [attackDescription, setAttackDescription] = useState<string>("");
  const [attackActive, setAttackActive] = useState(false);
  const [anomalyDetected, setAnomalyDetected] = useState(false);

  // Sahte işlemler oluştur
  useEffect(() => {
    const initialTransactions: Transaction[] = [
      {
        id: "tx_9d72b1",
        from: "0x1a2b3c...",
        to: wallet.address,
        amount: 0.5,
        timestamp: Date.now() - 86400000, // 1 gün önce
        isValid: true,
        isSuspicious: false,
        signature: "0x7a5bcd..."
      },
      {
        id: "tx_7e63a2",
        from: wallet.address,
        to: "0x4d5e6f...",
        amount: 0.25,
        timestamp: Date.now() - 43200000, // 12 saat önce
        isValid: true,
        isSuspicious: false,
        signature: "0x3f8e2d..."
      }
    ];

    setTransactions(initialTransactions);

    // Saldırı simülasyonu - 5 saniye sonra başlat
    const attackTimer = setTimeout(() => {
      startAttack();
    }, 5000);

    return () => clearTimeout(attackTimer);
  }, [wallet.address]);

  // Saldırı başlat
  const startAttack = () => {
    let attackDesc = "";
    let attackName = "";

    // Senaryo tipine göre saldırı tipi belirle
    if (type === "crypto-wallet") {
      // Cüzdan senaryosu - Oltalama saldırısı
      attackName = "Oltalama Saldırısı";
      attackDesc = "Sahte cüzdan giriş sayfasından özel anahtarınız çalınmaya çalışılıyor";

      // Sahte bir işlem oluştur
      const phishingTransaction: Transaction = {
        id: "tx_phishing",
        from: wallet.address,
        to: "0xFAKE123...",
        amount: wallet.balance,
        timestamp: Date.now(),
        isValid: false,
        isSuspicious: true,
        signature: "0xINVALID..."
      };

      setPendingTransaction(phishingTransaction);
    }
    else if (type === "smart-contract") {
      // Akıllı sözleşme senaryosu - Yeniden giriş saldırısı
      attackName = "Yeniden Giriş Saldırısı";
      attackDesc = "Akıllı sözleşmedeki bir açıktan faydalanılarak fonlar tekrar tekrar çekilmeye çalışılıyor";

      // Re-entrancy saldırısı simülasyonu
      const reentryTransaction: Transaction = {
        id: "tx_reentry",
        from: "0xATTACKER...",
        to: "0xCONTRACT...",
        amount: 0,
        timestamp: Date.now(),
        isValid: false,
        isSuspicious: true,
        signature: "0xMALICIOUS..."
      };

      setPendingTransaction(reentryTransaction);
    }
    else if (type === "defi") {
      // DeFi senaryosu - Fiyat manipülasyonu saldırısı
      attackName = "Flaş Kredi Saldırısı";
      attackDesc = "Flaş kredi kullanılarak likidite havuzu manipüle ediliyor ve fiyat oranları değiştiriliyor";

      // Flash loan saldırısı simülasyonu
      const flashLoanTransaction: Transaction = {
        id: "tx_flashloan",
        from: "0xATTACKER...",
        to: "0xPOOL...",
        amount: 1000,
        timestamp: Date.now(),
        isValid: false,
        isSuspicious: true,
        signature: "0xFLASHLOAN..."
      };

      setPendingTransaction(flashLoanTransaction);
    }

    setAttackType(attackName);
    setAttackDescription(attackDesc);
    setShowAttackAlert(true);
    setAttackActive(true);

    // İlerleme çubuğunu güncelle
    const interval = setInterval(() => {
      setAttackProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setAnomalyDetected(true);
          return 100;
        }
        return prev + 4;
      });
    }, 300);
  };

  // Sahte işlemi reddet
  const handleRejectTransaction = () => {
    if (!pendingTransaction) return;

    setTransactions(prev => [
      ...prev,
      {
        ...pendingTransaction,
        isValid: false
      }
    ]);

    setPendingTransaction(null);
    setShowAttackAlert(false);
    setAttackActive(false);
    setAnomalyDetected(false);
    setAttackProgress(0);

    // Wallet güvenlik seviyesini artır
    setWallet(prev => ({
      ...prev,
      securityLevel: "high"
    }));

    onAction("reject-transaction");
  };

  // İşlemi onayla (yanlış seçim)
  const handleApproveTransaction = () => {
    if (!pendingTransaction) return;

    // Cüzdandan para transfer edildi simülasyonu
    setWallet(prev => ({
      ...prev,
      balance: 0
    }));

    setTransactions(prev => [
      ...prev,
      pendingTransaction
    ]);

    setPendingTransaction(null);
    setShowAttackAlert(false);

    onAction("approve-transaction");
  };

  // Güvenlik önlemlerini yükselt
  const handleIncreaseSecurity = () => {
    setWallet(prev => ({
      ...prev,
      securityLevel: "high",
      privateKey: "***********************" // Özel anahtarı gizle
    }));

    setShowAttackAlert(false);
    setAttackActive(false);
    setAnomalyDetected(false);
    setAttackProgress(0);

    onAction("increase-security");
  };

  // Zaman formatlayıcı
  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  // Senaryoya göre arayüz içeriğini belirle
  const renderScenarioContent = () => {
    switch (type) {
      case "crypto-wallet":
        return (
          <div className="space-y-4">
            <Card className="bg-black/50 border-primary/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-md">Kripto Para Cüzdanı</CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Adres:</span>
                  <span className="font-mono text-xs">{wallet.address}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Bakiye:</span>
                  <span className="font-bold">{wallet.balance} ETH</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Özel Anahtar:</span>
                  <span className="font-mono text-xs">{wallet.privateKey}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Güvenlik Seviyesi:</span>
                  <Badge className={
                    wallet.securityLevel === "high" ? "bg-green-900/50 text-green-400" :
                    wallet.securityLevel === "medium" ? "bg-yellow-900/50 text-yellow-400" :
                    "bg-red-900/50 text-red-400"
                  }>
                    {wallet.securityLevel === "high" ? "Yüksek" :
                     wallet.securityLevel === "medium" ? "Orta" : "Düşük"}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {pendingTransaction && (
              <Card className="bg-red-950/20 border-red-500/30 animate-pulse">
                <CardHeader className="pb-2">
                  <CardTitle className="text-md text-red-400">Bekleyen İşlem</CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Alıcı:</span>
                    <span className="font-mono text-xs">{pendingTransaction.to}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Miktar:</span>
                    <span className="font-bold text-red-400">{pendingTransaction.amount} ETH</span>
                  </div>
                  <div className="text-xs text-red-400 mt-2 p-2 border border-red-500/20 rounded">
                    Dikkat! Tüm bakiyenizi bilinmeyen bir adrese gönderiyorsunuz.
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        );

      case "smart-contract":
        return (
          <div className="space-y-4">
            <Card className="bg-black/50 border-primary/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-md">Akıllı Sözleşme</CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-3">
                <div className="font-mono text-xs p-2 bg-gray-900/50 rounded overflow-auto max-h-40">
                  <pre className="text-green-400">
                    {`contract VulnerableContract {
  mapping(address => uint) public balances;

  function withdraw() public {
    uint balance = balances[msg.sender];

    // Güvenlik açığı: Bakiyeyi sıfırlamadan önce
    // transfer yapılıyor, bu yeniden giriş saldırısına
    // açık durumda

    (bool success, ) = msg.sender.call{value: balance}("");
    require(success);

    // Bu satır çok geç çalışıyor
    balances[msg.sender] = 0;
  }
}`}
                  </pre>
                </div>

                <div className="text-xs text-yellow-400 mt-2 p-2 border border-yellow-500/20 rounded">
                  Bu sözleşme, "Yeniden Giriş" saldırısına karşı savunmasızdır.
                  Bakiye güncellenmeden önce fon transferi yapılması güvenlik açığı oluşturur.
                </div>
              </CardContent>
            </Card>

            {pendingTransaction && (
              <Card className="bg-red-950/20 border-red-500/30 animate-pulse">
                <CardHeader className="pb-2">
                  <CardTitle className="text-md text-red-400">Şüpheli Aktivite</CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Saldırgan:</span>
                    <span className="font-mono text-xs">{pendingTransaction.from}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Metod:</span>
                    <span className="font-mono">withdraw()</span>
                  </div>
                  <div className="text-xs text-red-400 mt-2 p-2 border border-red-500/20 rounded">
                    Yeniden Giriş Saldırısı: Saldırgan bir callback fonksiyonu kullanarak,
                    bakiye sıfırlanmadan önce withdraw() fonksiyonunu tekrar çağırıyor.
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        );

      case "defi":
        return (
          <div className="space-y-4">
            <Card className="bg-black/50 border-primary/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-md">DeFi Likidite Havuzu</CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 border border-gray-700 rounded">
                    <div className="text-xs text-gray-400">ETH Rezervi</div>
                    <div className="font-bold">1,000 ETH</div>
                  </div>
                  <div className="p-2 border border-gray-700 rounded">
                    <div className="text-xs text-gray-400">TOKEN Rezervi</div>
                    <div className="font-bold">100,000 TKN</div>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Fiyat Oranı:</span>
                  <span className="font-bold">1 ETH = 100 TKN</span>
                </div>

                <div className="text-xs text-gray-400 mt-2 p-2 border border-gray-700 rounded">
                  Likidite havuzları x*y=k formülüne göre çalışır. Rezervlerin çarpımı sabit kalmalıdır.
                </div>
              </CardContent>
            </Card>

            {pendingTransaction && (
              <Card className="bg-red-950/20 border-red-500/30 animate-pulse">
                <CardHeader className="pb-2">
                  <CardTitle className="text-md text-red-400">Flaş Kredi İşlemi</CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Borç Alınan:</span>
                    <span className="font-bold text-red-400">{pendingTransaction.amount} ETH</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Hedef Havuz:</span>
                    <span className="font-mono text-xs">{pendingTransaction.to}</span>
                  </div>
                  <div className="text-xs text-red-400 mt-2 p-2 border border-red-500/20 rounded">
                    Büyük miktarda token alıp satarak fiyat manipülasyonu yapılmaya çalışılıyor.
                    Bu, oracle fiyatlarını etkileyip, teminat pozisyonlarının likiditasyonuna sebep olabilir.
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-4 border border-primary/20 rounded-md bg-black/80 space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium text-primary">Blockchain Güvenlik Simülasyonu</h3>
          <p className="text-sm text-gray-400">
            {type === "crypto-wallet" && "Kripto Para Cüzdanı Güvenliği"}
            {type === "smart-contract" && "Akıllı Sözleşme Güvenlik Açıkları"}
            {type === "defi" && "DeFi Protokol Güvenliği"}
          </p>
        </div>

        <Badge className={
          attackActive ? "bg-red-900/50 text-red-400 animate-pulse" : "bg-green-900/50 text-green-400"
        }>
          {attackActive ? "Saldırı Tespit Edildi" : "Güvenli"}
        </Badge>
      </div>

      {/* Saldırı Uyarısı */}
      {showAttackAlert && (
        <Card className="border-red-500/50 bg-red-950/20 animate-pulse">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className="text-xl mr-2">⚠️</span>
                <div>
                  <h4 className="font-medium text-red-400">{attackType}</h4>
                  <p className="text-xs text-gray-300">{attackDescription}</p>
                </div>
              </div>
              <Progress value={attackProgress} className="w-24 h-2 bg-red-950" indicatorClassName="bg-red-500" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Senaryo İçeriği */}
      {renderScenarioContent()}

      {/* İşlem Geçmişi */}
      <Card className="bg-black/50 border-primary/30">
        <CardHeader className="pb-2">
          <CardTitle className="text-md">İşlem Geçmişi</CardTitle>
        </CardHeader>
        <CardContent className="p-4 space-y-2 max-h-40 overflow-auto">
          {[...transactions].reverse().map((tx) => (
            <div
              key={tx.id}
              className={`p-2 border rounded text-xs ${
                tx.isSuspicious
                  ? "border-red-500/30 bg-red-950/10"
                  : "border-gray-700"
              }`}
            >
              <div className="flex justify-between">
                <span>ID: {tx.id}</span>
                <span>{formatTime(tx.timestamp)}</span>
              </div>
              <div className="mt-1 flex justify-between">
                <span className="font-mono">
                  {tx.from.slice(0, 8)}...➔{tx.to.slice(0, 8)}...
                </span>
                <span className={tx.from === wallet.address ? "text-red-400" : "text-green-400"}>
                  {tx.from === wallet.address ? "-" : "+"}{tx.amount} ETH
                </span>
              </div>
              {tx.isSuspicious && (
                <div className="mt-1 text-red-400">⚠️ Şüpheli İşlem</div>
              )}
            </div>
          ))}

          {transactions.length === 0 && (
            <div className="text-center text-gray-500 text-sm py-2">
              İşlem geçmişi boş
            </div>
          )}
        </CardContent>
      </Card>

      {/* Aksiyon Butonları */}
      <div className="grid grid-cols-1 gap-3 pt-2">
        {pendingTransaction && (
          <>
            <Button
              variant="outline"
              className="border-red-500/50 hover:border-red-500 hover:bg-red-950/30 text-red-400"
              onClick={handleApproveTransaction}
            >
              İşlemi Onayla (Tehlikeli)
            </Button>

            <Button
              className="bg-green-600 hover:bg-green-700 text-white"
              onClick={handleRejectTransaction}
            >
              İşlemi Reddet ve Rapor Et
            </Button>
          </>
        )}

        {(anomalyDetected && !pendingTransaction) && (
          <Button
            className="bg-blue-600 hover:bg-blue-700 text-white"
            onClick={handleIncreaseSecurity}
          >
            {type === "crypto-wallet" && "İki Faktörlü Kimlik Doğrulamayı Etkinleştir"}
            {type === "smart-contract" && "Güvenli Sözleşme Modelini Uygula"}
            {type === "defi" && "Fiyat Manipülasyonu Koruması Ekle"}
          </Button>
        )}

        {(!attackActive && !pendingTransaction) && (
          <Button
            className="bg-primary hover:bg-primary/80"
            onClick={() => startAttack()}
          >
            Saldırı Simülasyonu Başlat
          </Button>
        )}
      </div>
    </div>
  );
}
