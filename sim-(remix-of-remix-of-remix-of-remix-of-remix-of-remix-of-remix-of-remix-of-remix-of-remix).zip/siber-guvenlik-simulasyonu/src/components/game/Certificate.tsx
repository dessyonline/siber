"use client";

import React, { useRef } from "react";
import { Button } from "@/components/ui/button";
import { useGameStore } from "@/store/gameStore";
import { Card } from "@/components/ui/card";
import { CyberGlitchText } from "../ui/cyber-effects";
import html2canvas from "html2canvas";
import { Badge } from "@/components/ui/badge";
import type { ScenarioType } from "@/store/gameStore";
import { Progress } from "@/components/ui/progress";

// Kategori adlarını Türkçeye çeviren yardımcı fonksiyon (ResultScreen'den aynısı)
const categoryNames: Record<ScenarioType, string> = {
  phishing: "Oltalama",
  password: "Şifre Güvenliği",
  software: "Yazılım Güvenliği",
  social: "Sosyal Mühendislik",
  network: "Ağ Güvenliği",
  terminal: "Terminal Güvenliği",
  desktop: "Masaüstü Güvenliği",
  mobile: "Mobil Güvenlik",
  physical: "Fiziksel Güvenlik",
  ai: "Yapay Zeka Güvenliği",
  blockchain: "Blockchain Güvenliği",
  iot: "IoT Güvenliği"
};

export function Certificate() {
  const { username, score, getScorePercentage, getCategoryPerformance } = useGameStore();
  const certificateRef = useRef<HTMLDivElement>(null);
  const scorePercentage = getScorePercentage();
  const categoryPerformance = getCategoryPerformance();

  // Yeni: En iyi ve en zayıf kategorileri bul
  const sortedCategories = [...categoryPerformance].sort((a, b) => b.percentage - a.percentage);
  const bestCategory = sortedCategories.length > 0 ? sortedCategories[0] : null;
  const worstCategory = sortedCategories.length > 0 ? sortedCategories[sortedCategories.length - 1] : null;

  // Tarihi formatlama
  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString('tr-TR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  // Sertifika kategorisini belirleme
  const getCertificateLevel = () => {
    if (scorePercentage >= 90) return "Siber Güvenlik Uzmanı";
    if (scorePercentage >= 70) return "Siber Güvenlik Analisti";
    if (scorePercentage >= 50) return "Siber Güvenlik Farkındalık Uzmanı";
    return "Siber Güvenlik Temel Eğitim";
  };

  // Sertifikayı PNG olarak indirme
  const downloadCertificate = async () => {
    if (!certificateRef.current) return;

    try {
      const canvas = await html2canvas(certificateRef.current, {
        scale: 2,
        backgroundColor: null,
        logging: false
      });

      const image = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.href = image;
      link.download = `${username.replace(/\s+/g, '_')}_Siber_Guvenlik_Sertifikasi.png`;
      link.click();
    } catch (error) {
      console.error("Sertifika indirme hatası:", error);
    }
  };

  return (
    <div className="flex flex-col items-center">
      <div ref={certificateRef} className="relative w-full max-w-3xl p-2 my-6">
        <Card className="relative overflow-hidden border-2 border-primary/50 bg-black p-6">
          {/* Border effects */}
          <div className="absolute inset-0 border-4 border-transparent cyber-gradient opacity-20"></div>
          <div className="absolute inset-[6px] border border-primary/20"></div>

          {/* Background grid */}
          <div className="absolute inset-0 bg-grid-white/5"></div>

          {/* Certificate content */}
          <div className="relative z-10 text-center space-y-6 py-4">
            <div className="mb-2">
              <div className="cyber-gradient text-transparent bg-clip-text text-3xl font-bold tracking-wide mb-2">SERTİFİKA</div>
              <div className="text-sm text-muted-foreground">SİBER GÜVENLİK SİMÜLASYONU BAŞARI BELGESİ</div>
            </div>

            <div className="my-8">
              <div className="text-sm text-muted-foreground mb-1">Bu belge</div>
              <div className="text-2xl font-bold text-glow mb-1">{username}</div>
              <div className="text-sm text-muted-foreground mb-4">adlı katılımcının</div>

              <div className="text-lg mb-1">
                <CyberGlitchText intensity="low">
                  {getCertificateLevel()}
                </CyberGlitchText>
              </div>

              <div className="text-sm text-muted-foreground mt-4 mb-1">
                eğitimini başarıyla tamamladığını ve gerekli bilgi ve becerileri kazandığını onaylar.
              </div>

              <div className="text-sm mt-8">
                <span className="text-primary">Başarı Puanı:</span> %{scorePercentage.toFixed(0)}
              </div>
            </div>

            {/* YENİ: Kategori Bazlı Performans Göstergesi */}
            {categoryPerformance.length > 0 && (
              <div className="mt-6 border-t border-primary/20 pt-6">
                <h3 className="text-sm font-medium text-primary mb-4">KATEGORİ BAZLI PERFORMANS</h3>

                {/* Yetenek Grafik Gösterimi */}
                <div className="grid grid-cols-4 gap-3 mt-3 mb-5">
                  {sortedCategories.slice(0, 4).map((cat) => (
                    <div key={`cert-bar-${cat.category}`} className="flex flex-col items-center">
                      <div className="w-full flex flex-col items-center">
                        <div
                          className="w-4 rounded-t-md"
                          style={{
                            height: `${cat.skillRating * 0.4}px`,
                            background: cat.percentage >= 90 ? 'linear-gradient(to top, #065f46, #10b981)' :
                                      cat.percentage >= 70 ? 'linear-gradient(to top, #1e40af, #3b82f6)' :
                                      cat.percentage >= 50 ? 'linear-gradient(to top, #854d0e, #eab308)' :
                                      cat.percentage >= 30 ? 'linear-gradient(to top, #9a3412, #f97316)' :
                                      'linear-gradient(to top, #7f1d1d, #ef4444)'
                          }}
                        ></div>
                        <div className="mt-1 text-center text-[0.6rem] text-gray-400 truncate w-14">
                          {categoryNames[cat.category as ScenarioType]}
                        </div>
                      </div>
                      <div className="mt-1 text-[0.6rem] font-medium" style={{
                        color: cat.percentage >= 90 ? '#10b981' :
                               cat.percentage >= 70 ? '#3b82f6' :
                               cat.percentage >= 50 ? '#eab308' :
                               cat.percentage >= 30 ? '#f97316' :
                               '#ef4444'
                      }}>
                        %{Math.round(cat.percentage)}
                      </div>
                    </div>
                  ))}
                </div>

                {/* En iyi ve en zayıf kategori bilgisi */}
                {bestCategory && worstCategory && bestCategory.category !== worstCategory.category && (
                  <div className="flex justify-between text-xs text-gray-400 mb-2 mt-1">
                    <div className="text-left flex-1">
                      <span className="block text-green-500 mb-1">En İyi Performans</span>
                      <Badge className="bg-green-900/30 text-green-400 text-[0.65rem]">
                        {categoryNames[bestCategory.category as ScenarioType]}
                      </Badge>
                    </div>
                    <div className="w-px bg-gray-800 mx-2"></div>
                    <div className="text-right flex-1">
                      <span className="block text-red-500 mb-1">Geliştirilecek Alan</span>
                      <Badge className="bg-red-900/30 text-red-400 text-[0.65rem]">
                        {categoryNames[worstCategory.category as ScenarioType]}
                      </Badge>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-between items-center mt-10 pt-6 border-t border-primary/20">
              <div className="text-left">
                <div className="text-sm text-muted-foreground">Tarih</div>
                <div className="text-sm">{formattedDate}</div>
              </div>

              <div className="text-right">
                <div className="text-sm text-muted-foreground">Sertifika No</div>
                <div className="text-sm font-mono">SG-{String(Date.now()).slice(-8)}</div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <Button
        onClick={downloadCertificate}
        className="mt-4 bg-primary hover:bg-primary/80"
        size="lg"
      >
        Sertifikayı İndir
      </Button>

      <p className="text-sm text-muted-foreground mt-4 text-center max-w-md">
        Bu sertifika, siber güvenlik farkındalık eğitimini tamamladığınızı gösterir.
        Gerçek dünyada siber güvenlik bilincini artırmak için bu bilgileri çevrenizle paylaşabilirsiniz.
        <span className="block mt-2 text-primary font-medium">Geliştirici: Siber.php</span>
      </p>
    </div>
  );
}
