"use client";

import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Image from "next/image";

interface PhysicalSecuritySimulationProps {
  type?: 'default' | 'server-room';
  onAction?: (action: string) => void;
}

export function PhysicalSecuritySimulation({ type = 'default', onAction }: PhysicalSecuritySimulationProps) {
  const [stage, setStage] = useState<'initial' | 'id-check' | 'decision' | 'observation'>('initial');
  const [idChecked, setIdChecked] = useState(false);
  const [showBadgeZoom, setShowBadgeZoom] = useState(false);
  const [securityCalled, setSecurityCalled] = useState(false);
  const [observing, setObserving] = useState(false);

  // Çalışanın ID kartı hızlıca gösterildiğinde detaylar hakkında şüphe
  const handleIdCheck = () => {
    setShowBadgeZoom(true);
    setTimeout(() => {
      setShowBadgeZoom(false);
      setIdChecked(true);
      setStage('decision');
    }, 2500);
  };

  // Güvenlik veya tesis yönetimini arama
  const handleCallSecurity = () => {
    setSecurityCalled(true);
    if (onAction) {
      onAction('call-security');
    }
  };

  // Kapıyı açma
  const handleOpenDoor = () => {
    if (onAction) {
      onAction('open-door');
    }
  };

  // Erişimi reddetme
  const handleDenyAccess = () => {
    if (onAction) {
      onAction('deny-access');
    }
  };

  // Doğrudan yaklaşma (sunucu odası)
  const handleApproachDirectly = () => {
    if (onAction) {
      onAction('approach-directly');
    }
  };

  // Uzaklaşma (sunucu odası)
  const handleWalkAway = () => {
    if (onAction) {
      onAction('walk-away');
    }
  };

  // Gözlemleme modu (sunucu odası)
  const handleObserve = () => {
    setObserving(true);
    setStage('observation');
  };

  // Gözlemleme sırasında güvenliği arama
  const handleObserveAndCallSecurity = () => {
    setSecurityCalled(true);
    if (onAction) {
      onAction('call-security');
    }
  };

  // Kapı giriş kartı simülasyonu
  if (type === 'default') {
    return (
      <div className="bg-gray-100 rounded-lg overflow-hidden shadow-lg p-0 mx-auto max-w-3xl">
        {/* Ofis Ortamı Simülasyonu */}
        <div className="relative h-[400px] bg-gray-800">
          {/* Ofis Arkaplanı */}
          <div className="absolute inset-0 bg-gradient-to-b from-gray-700 to-gray-900"></div>

          {/* Kapı ve Koridor */}
          <div className="absolute inset-x-0 top-10 bottom-0 flex justify-center">
            <div className="relative w-40 h-full">
              {/* Koridor */}
              <div className="absolute top-0 bottom-0 w-full bg-gray-600"></div>

              {/* Kapı (Kapalı) */}
              <div className="absolute top-20 h-48 w-full bg-gradient-to-b from-blue-900 to-blue-950 rounded-t-lg">
                <div className="absolute right-2 top-24 h-4 w-4 bg-red-500 rounded-full"></div>
                <div className="absolute left-2 top-1/2 h-2 w-6 bg-gray-400 rounded-full"></div>
              </div>

              {/* Kart Okuyucu */}
              <div className="absolute right-[-20px] top-40 h-12 w-8 bg-black rounded-md">
                <div className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full"></div>
                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-4 bg-gray-400"></div>
              </div>
            </div>
          </div>

          {/* Maintenance Personeli */}
          {stage === 'initial' && (
            <div className="absolute bottom-10 left-20 flex flex-col items-center">
              <div className="relative h-28 w-20 bg-blue-500 rounded-t-full">
                {/* Kafa */}
                <div className="absolute top-[-15px] left-1/2 transform -translate-x-1/2 h-16 w-16 bg-amber-200 rounded-full">
                  <div className="absolute bottom-6 left-3 h-2 w-2 bg-black rounded-full"></div>
                  <div className="absolute bottom-6 right-3 h-2 w-2 bg-black rounded-full"></div>
                  <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-6 bg-black rounded-full"></div>
                </div>

                {/* Kimlik Kartı */}
                <div
                  className="absolute right-[-10px] top-6 h-8 w-6 bg-white border-2 border-red-500 rounded cursor-pointer animate-pulse"
                  onClick={() => setStage('id-check')}
                ></div>
              </div>
              <div className="mt-2 bg-black/50 text-white p-1 rounded text-xs text-center">
                "Merhaba, bakım ekibindenim. Kimliğimi göstereyim."
              </div>
            </div>
          )}

          {/* ID İnceleme */}
          {stage === 'id-check' && (
            <div className="absolute bottom-10 left-20 flex flex-col items-center">
              <div className="relative h-28 w-20 bg-blue-500 rounded-t-full">
                {/* Kafa */}
                <div className="absolute top-[-15px] left-1/2 transform -translate-x-1/2 h-16 w-16 bg-amber-200 rounded-full">
                  <div className="absolute bottom-6 left-3 h-2 w-2 bg-black rounded-full"></div>
                  <div className="absolute bottom-6 right-3 h-2 w-2 bg-black rounded-full"></div>
                  <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-6 bg-black rounded-full"></div>
                </div>

                {/* Kimlik Kartı - Gösterme */}
                <div
                  className="absolute right-[-15px] top-6 h-16 w-12 bg-white border-2 border-gray-300 rounded cursor-pointer"
                  onClick={handleIdCheck}
                >
                  <div className="absolute top-1 left-1 right-1 h-3 bg-blue-400 flex items-center justify-center">
                    <span className="text-[6px] text-white">BAKIMCI</span>
                  </div>
                  <div className="absolute top-5 left-1/2 transform -translate-x-1/2 h-6 w-6 bg-gray-200 rounded-full"></div>
                  <div className="absolute bottom-1 left-1 right-1 h-2 bg-gray-300"></div>
                </div>
              </div>
              <div className="mt-2 bg-black/50 text-white p-1 rounded text-xs text-center">
                "Bilgisayar odasına girmem gerekiyor ama kartımı unuttum. Yardım edebilir misiniz?"
              </div>
            </div>
          )}

          {/* ID Büyütülmüş Görünüm */}
          {showBadgeZoom && (
            <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-20">
              <div className="relative h-64 w-44 bg-white border-4 border-gray-300 rounded-lg overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-12 bg-blue-500 flex items-center justify-center">
                  <span className="text-sm text-white font-bold">ŞİRKET A.Ş.</span>
                  <span className="absolute top-8 left-0 right-0 text-center text-[10px] text-white">BAKIMCI</span>
                </div>
                <div className="absolute top-16 left-1/2 transform -translate-x-1/2 h-24 w-24 bg-gray-200 rounded-full flex items-center justify-center text-3xl">👨‍🔧</div>
                <div className="absolute bottom-16 left-0 right-0 text-center text-sm font-semibold">Ahmet Yılmaz</div>
                <div className="absolute bottom-10 left-0 right-0 text-center text-xs text-gray-500">ID: 12345</div>

                {/* Şüpheli Detaylar - Dikkatli bakanlar için ipuçları */}
                <div className="absolute bottom-4 left-0 right-0 text-center text-[8px] text-red-500">Son Geçerlilik: 01/01/2023</div>
                <div className="absolute bottom-2 left-0 right-0 text-center text-[8px] text-gray-400">GENEL ERİŞİM - VERİ MERKEZİ DIŞINDA</div>
              </div>
              <div className="absolute bottom-10 left-0 right-0 text-center">
                <div className="inline-block bg-black/50 text-white p-2 rounded text-sm animate-pulse">
                  ID kartını inceliyorsunuz...
                </div>
              </div>
            </div>
          )}

          {/* Karar Aşaması */}
          {stage === 'decision' && (
            <div className="absolute bottom-10 left-20 flex flex-col items-center">
              <div className="relative h-28 w-20 bg-blue-500 rounded-t-full">
                {/* Kafa */}
                <div className="absolute top-[-15px] left-1/2 transform -translate-x-1/2 h-16 w-16 bg-amber-200 rounded-full">
                  <div className="absolute bottom-6 left-3 h-2 w-2 bg-black rounded-full"></div>
                  <div className="absolute bottom-6 right-3 h-2 w-2 bg-black rounded-full"></div>
                  {securityCalled ? (
                    <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-6 bg-red-500 rounded-full"></div>
                  ) : (
                    <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-6 bg-black rounded-full"></div>
                  )}
                </div>

                {/* Bekleme Duruşu */}
                <div className="absolute right-[-10px] top-6 h-8 w-2 bg-blue-600"></div>
              </div>
              <div className="mt-2 bg-black/50 text-white p-1 rounded text-xs text-center">
                {securityCalled
                  ? "Güvenlik görevlisi az sonra burada olacak..."
                  : "Sorun değil, bekleyebilirim. Ne yapacaksınız?"}
              </div>
            </div>
          )}

          {/* Kullanıcı */}
          <div className="absolute bottom-10 right-20 flex flex-col items-center">
            <div className="relative h-28 w-20 bg-green-500 rounded-t-full">
              {/* Kafa */}
              <div className="absolute top-[-15px] left-1/2 transform -translate-x-1/2 h-16 w-16 bg-amber-200 rounded-full">
                <div className="absolute bottom-6 left-3 h-2 w-2 bg-black rounded-full"></div>
                <div className="absolute bottom-6 right-3 h-2 w-2 bg-black rounded-full"></div>
                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-6 bg-black rounded-full"></div>
              </div>
            </div>
          </div>
        </div>

        {/* İnteraktif Öğeler */}
        <div className="bg-white p-4">
          {stage === 'initial' && (
            <div>
              <h3 className="text-lg font-semibold mb-2 text-gray-800">Fiziksel Güvenlik Senaryosu</h3>
              <p className="text-sm mb-4 text-gray-600">
                Bakım ekibinden olduğunu söyleyen biri size yaklaştı. Kimliğini göstermek istiyor.
              </p>
              <Button
                className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                onClick={() => setStage('id-check')}
              >
                Kimliği İncele
              </Button>
            </div>
          )}

          {stage === 'id-check' && (
            <div>
              <h3 className="text-lg font-semibold mb-2 text-gray-800">Kimlik Kontrolü</h3>
              <p className="text-sm mb-4 text-gray-600">
                Kişi kimliğini gösteriyor ve bilgisayar odasına girmek için yardım istiyor. Kimliğini hızlıca gösteriyor.
              </p>
              <Button
                className="w-full bg-blue-500 hover:bg-blue-600 text-white mb-2"
                onClick={handleIdCheck}
              >
                Kimliği Daha Yakından İncele
              </Button>
            </div>
          )}

          {stage === 'decision' && (
            <div>
              <h3 className="text-lg font-semibold mb-2 text-gray-800">Karar Verin</h3>
              <p className="text-sm mb-4 text-gray-600">
                {idChecked
                  ? "Kimliğini incelediğiniz kişi bilgisayar odasına girmek için sizden yardım bekliyor. Ne yapacaksınız?"
                  : "Kişi bilgisayar odasına girmek için sizden yardım bekliyor. Ne yapacaksınız?"}
              </p>
              <div className="grid grid-cols-1 gap-2">
                <Button
                  className="w-full bg-red-500 hover:bg-red-600 text-white"
                  onClick={handleOpenDoor}
                >
                  Kapıyı Aç ve Yardım Et
                </Button>

                <Button
                  className="w-full bg-green-500 hover:bg-green-600 text-white"
                  onClick={handleCallSecurity}
                  disabled={securityCalled}
                >
                  Güvenlik veya Tesis Yönetimini Ara
                </Button>

                <Button
                  className="w-full bg-yellow-500 hover:bg-yellow-600 text-white"
                  onClick={handleDenyAccess}
                >
                  Erişimi Reddet
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Sunucu Odası Güvenlik Simülasyonu
  if (type === 'server-room') {
    return (
      <div className="bg-gray-100 rounded-lg overflow-hidden shadow-lg p-0 mx-auto max-w-3xl">
        {/* Sunucu Odası Koridoru */}
        <div className="relative h-[400px] bg-gray-800">
          {/* Koridor Arkaplanı */}
          <div className="absolute inset-0 bg-gradient-to-b from-gray-600 to-gray-800"></div>

          {/* Sunucu Odası Kapısı */}
          <div className="absolute left-1/2 transform -translate-x-1/2 top-10 w-60 h-80 bg-gray-700 border-2 border-gray-600 rounded-md">
            <div className="absolute top-2 left-2 right-2 text-center">
              <span className="bg-blue-900 text-blue-100 text-xs px-2 py-1 rounded">SUNUCU ODASI</span>
            </div>
            <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 w-20 h-40 bg-blue-900 rounded-sm">
              {/* Kapı */}
            </div>
            <div className="absolute right-2 top-1/3 h-8 w-6 bg-black rounded-md">
              {/* Kart Okuyucu */}
              <div className="absolute top-1 right-1 h-1 w-1 bg-red-500 rounded-full"></div>
            </div>
          </div>

          {/* Şüpheli Kişi */}
          <div className="absolute bottom-10 left-1/3 flex flex-col items-center">
            <div className="relative h-28 w-20 bg-gray-500 rounded-t-full">
              {/* Kafa */}
              <div className="absolute top-[-15px] left-1/2 transform -translate-x-1/2 h-16 w-16 bg-amber-200 rounded-full">
                <div className="absolute bottom-6 left-3 h-2 w-2 bg-black rounded-full"></div>
                <div className="absolute bottom-6 right-3 h-2 w-2 bg-black rounded-full"></div>
                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-6 bg-black rounded-full"></div>
              </div>

              {/* ID Kartı */}
              <div className="absolute right-[-5px] top-6 h-6 w-4 bg-white border border-blue-500 rounded"></div>

              {/* Şüpheli Hareket */}
              {!observing && (
                <div className="absolute left-[-10px] top-10 h-10 w-4 bg-gray-500 rounded-full animate-pulse"></div>
              )}
            </div>
            <div className="mt-2 bg-black/50 text-white p-1 rounded text-xs text-center max-w-[150px]">
              {observing ?
                "Kişi kapı kilidini kurcalıyor gibi görünüyor..." :
                "Tanımadığınız birisi kapıda bir şeyler yapıyor."}
            </div>
          </div>

          {/* Kullanıcı */}
          <div className="absolute bottom-10 right-20 flex flex-col items-center">
            <div className="relative h-28 w-20 bg-green-500 rounded-t-full">
              {/* Kafa */}
              <div className="absolute top-[-15px] left-1/2 transform -translate-x-1/2 h-16 w-16 bg-amber-200 rounded-full">
                <div className="absolute bottom-6 left-3 h-2 w-2 bg-black rounded-full"></div>
                <div className="absolute bottom-6 right-3 h-2 w-2 bg-black rounded-full"></div>
                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-6 bg-black rounded-full"></div>
              </div>
            </div>
            {securityCalled && (
              <div className="mt-2 bg-blue-900/70 text-white p-1 rounded text-xs text-center">
                Güvenlik aranıyor...
              </div>
            )}
          </div>

          {/* Gözlemleme Modu */}
          {stage === 'observation' && (
            <div className="absolute inset-0 bg-black/30 z-10">
              <div className="absolute top-4 right-4 bg-black/70 text-white p-2 rounded text-sm">
                Kişiyi gözlemliyorsunuz...
              </div>

              <div className="absolute bottom-40 left-1/2 transform -translate-x-1/2 bg-black/70 text-white p-2 rounded text-sm max-w-[250px]">
                <p className="text-xs mb-2">Kişi sunucu odasının kilidini kurcalıyor. Şirket kimliği var gibi görünüyor, ancak davranışları şüpheli.</p>
                <Button
                  size="sm"
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white text-xs"
                  onClick={handleObserveAndCallSecurity}
                  disabled={securityCalled}
                >
                  Güvenliği Ara
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* İnteraktif Öğeler */}
        <div className="bg-white p-4">
          <h3 className="text-lg font-semibold mb-2 text-gray-800">Sunucu Odası Güvenliği</h3>
          <p className="text-sm mb-4 text-gray-600">
            Bir toplantıdan dönerken, tanımadığınız birinin sunucu odasının kapısında bir şeyler kurcaladığını görüyorsunuz. Ne yaparsınız?
          </p>

          {stage === 'initial' && (
            <div className="grid grid-cols-1 gap-2">
              <Button
                className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                onClick={handleApproachDirectly}
              >
                Kişiye Yaklaşıp Kimliğini ve Ne Yaptığını Sorun
              </Button>

              <Button
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-white"
                onClick={handleWalkAway}
              >
                Uzaklaşın ve Güvenliği Arayın
              </Button>

              <Button
                className="w-full bg-green-500 hover:bg-green-600 text-white"
                onClick={handleObserve}
              >
                Mesafeyi Koruyarak Kişiyi Gözlemleyin
              </Button>
            </div>
          )}

          {stage === 'observation' && (
            <div className="text-sm text-gray-600 text-center">
              <p className="mb-2">Kişiyi güvenli bir mesafeden gözlemliyorsunuz.</p>
              {securityCalled && <p className="text-green-600 font-semibold">Güvenlik ekibi yolda!</p>}
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
}
