"use client";

import React, { useState, useEffect } from "react";
import { useGameStore } from "@/store/gameStore";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CyberContainer, CyberGlitchText, CyberAttackAnimation, BackgroundMatrix, CyberRadar, HackerTerminal, AttackParticles } from "@/components/ui/cyber-effects";
import Image from "next/image";
import { VirtualTerminal } from "./VirtualTerminal";
import { VirtualDesktop } from "./VirtualDesktop";
import { NetworkSimulation } from "./NetworkSimulation";
import { MultimediaViewer, type MediaContent } from "./MultimediaViewer";
import { findMediaById, getMediaForScenarioType } from "@/lib/mediaLibrary";
import { MobileDeviceSimulation } from "./MobileDeviceSimulation";
import { PhysicalSecuritySimulation } from "./PhysicalSecuritySimulation";
import { AISecuritySimulation } from "./AISecuritySimulation";
import { IoTSimulation } from "./IoTSimulation";
import { BlockchainSecuritySimulation } from "./BlockchainSecuritySimulation";

// Senaryo türüne göre renk ve ikon belirleme
const getTypeDetails = (type: string) => {
  switch (type) {
    case 'phishing':
      return { color: 'text-red-400', badge: 'bg-red-900/50 text-red-400', label: 'Oltalama Saldırısı' };
    case 'password':
      return { color: 'text-blue-400', badge: 'bg-blue-900/50 text-blue-400', label: 'Şifre Güvenliği' };
    case 'software':
      return { color: 'text-green-400', badge: 'bg-green-900/50 text-green-400', label: 'Yazılım Güvenliği' };
    case 'social':
      return { color: 'text-yellow-400', badge: 'bg-yellow-900/50 text-yellow-400', label: 'Sosyal Mühendislik' };
    case 'terminal':
      return { color: 'text-purple-400', badge: 'bg-purple-900/50 text-purple-400', label: 'Terminal Güvenliği' };
    case 'desktop':
      return { color: 'text-cyan-400', badge: 'bg-cyan-900/50 text-cyan-400', label: 'Masaüstü Güvenliği' };
    case 'network':
      return { color: 'text-pink-400', badge: 'bg-pink-900/50 text-pink-400', label: 'Ağ Güvenliği' };
    case 'mobile':
      return { color: 'text-amber-400', badge: 'bg-amber-900/50 text-amber-400', label: 'Mobil Güvenlik' };
    case 'physical':
      return { color: 'text-indigo-400', badge: 'bg-indigo-900/50 text-indigo-400', label: 'Fiziksel Güvenlik' };
    case 'ai':
      return { color: 'text-violet-400', badge: 'bg-violet-900/50 text-violet-400', label: 'Yapay Zeka Güvenliği' };
    case 'iot':
      return { color: 'text-teal-400', badge: 'bg-teal-900/50 text-teal-400', label: 'IoT Güvenliği' };
    case 'blockchain':
      return { color: 'text-rose-400', badge: 'bg-rose-900/50 text-rose-400', label: 'Blockchain Güvenliği' };
    default:
      return { color: 'text-gray-400', badge: 'bg-gray-900/50 text-gray-400', label: 'Genel Güvenlik' };
  }
};

export function ScenarioScreen() {
  const {
    scenarios,
    getCurrentScenario,
    selectOption,
    nextScenario,
    getScorePercentage,
    getRiskPercentage,
    currentScenarioIndex,
    difficultyLevel,
    timeRemaining,
    startTimer,
    stopTimer
  } = useGameStore();

  const currentScenario = getCurrentScenario();
  const [showExplanation, setShowExplanation] = useState(false);
  const [activeMedia, setActiveMedia] = useState<MediaContent | null>(null);
  const [availableMedia, setAvailableMedia] = useState<MediaContent[]>([]);
  const [showMediaGallery, setShowMediaGallery] = useState(false);
  const [attackActive, setAttackActive] = useState(false);

  // Zorluk seviyesine göre süre sınırını başlat
  useEffect(() => {
    if (!currentScenario) return;

    // Eğer senaryonun zaman sınırı varsa ve zorluk seviyesi 'hard' ise süreyi başlat
    if (currentScenario.timeLimit && difficultyLevel === 'hard' && !currentScenario.completed) {
      startTimer(currentScenario.timeLimit);
    }

    // Senaryo tipine göre kullanılabilir medya içeriklerini getir
    if (currentScenario.type) {
      const mediaContents = getMediaForScenarioType(currentScenario.type);
      setAvailableMedia(mediaContents);
    }

    // Saldırı animasyonunu başlat
    setAttackActive(false);
    const attackTimer = setTimeout(() => {
      setAttackActive(true);
    }, 1000);

    return () => {
      stopTimer(); // Bileşen temizlendiğinde zamanlayıcıyı durdur
      clearTimeout(attackTimer);
    };
  }, [currentScenario, difficultyLevel, startTimer, stopTimer]);

  // Süre dolduğunda otomatik olarak yanlış cevap seç
  useEffect(() => {
    if (timeRemaining === 0 && currentScenario && !currentScenario.completed) {
      // Yanlış bir seçeneği otomatik olarak seç (ilk yanlış seçenek)
      const wrongOption = currentScenario.options.find(option => !option.correct);
      if (wrongOption) {
        selectOption(currentScenario.id, wrongOption.id);
        setShowExplanation(true);
      }
    }
  }, [timeRemaining, currentScenario, selectOption]);

  // Senaryo yoksa
  if (!currentScenario) {
    return <div>Senaryo bulunamadı</div>;
  }

  const { color, badge, label } = getTypeDetails(currentScenario.type);
  const progress = ((currentScenarioIndex + 1) / scenarios.length) * 100;
  const scorePercentage = getScorePercentage();
  const riskPercentage = getRiskPercentage();

  const handleSelectOption = (optionId: string) => {
    if (currentScenario.completed) return;
    selectOption(currentScenario.id, optionId);
    setShowExplanation(true);
  };

  const handleNext = () => {
    setShowExplanation(false);
    setActiveMedia(null);
    setShowMediaGallery(false);
    setAttackActive(false);
    nextScenario();
  };

  const handleOpenMedia = (mediaId: string) => {
    const media = findMediaById(mediaId);
    if (media) {
      setActiveMedia(media);
      setShowMediaGallery(false);
    }
  };

  const selectedOption = currentScenario.options.find(opt => opt.id === currentScenario.selectedOption);

  // Senaryo türüne göre uygun saldırı türünü belirle
  const getAttackTypeForScenario = (scenarioType: string) => {
    switch (scenarioType) {
      case 'phishing':
        return 'phishing';
      case 'password':
        return 'bruteforce';
      case 'software':
        return 'malware';
      case 'social':
        return 'social';
      case 'network':
        return 'network';
      case 'terminal':
        return 'injection';
      case 'desktop':
        return 'ransomware';
      case 'mobile':
        return 'network';
      case 'physical':
        return 'mitm';
      case 'ai':
        return 'ai';
      case 'iot':
        return 'iot';
      case 'blockchain':
        return 'phishing'; // Default attack type for blockchain
      default:
        return 'ddos';
    }
  };

  // Simülasyon tipine göre uygun bileşeni göster
  const renderSimulation = () => {
    const simType = currentScenario.simulationType || 'quiz';
    const attackType = getAttackTypeForScenario(currentScenario.type);

    switch (simType) {
      case 'terminal':
        return (
          <div className="mb-4 relative">
            <VirtualTerminal />
            {attackActive && (
              <div className="absolute bottom-4 right-4 z-20 w-60">
                <CyberAttackAnimation type="injection" />
              </div>
            )}
          </div>
        );
      case 'desktop':
        return (
          <div className="mb-4 relative">
            <VirtualDesktop />
            {attackActive && (
              <div className="absolute bottom-4 right-4 z-20 w-60">
                <CyberAttackAnimation type="ransomware" />
              </div>
            )}
          </div>
        );
      case 'network':
        return (
          <div className="mb-4 relative">
            <NetworkSimulation />
            {attackActive && (
              <div className="absolute top-4 right-4 z-20 w-60">
                <CyberAttackAnimation type="network" />
              </div>
            )}
          </div>
        );
      case 'mobile':
        return (
          <div className="mb-4 relative flex flex-col items-center">
            {currentScenario.id === 'mobile-1' && (
              <MobileDeviceSimulation
                type="app-permissions"
                onAction={(action) => {
                  if (action === 'grant-permissions') {
                    selectOption(currentScenario.id, 'm1-1'); // Tüm izinlere izin verme
                    setShowExplanation(true);
                  } else if (action === 'deny-permissions') {
                    selectOption(currentScenario.id, 'm1-2'); // İzinleri reddetme
                    setShowExplanation(true);
                  }
                }}
              />
            )}
            {currentScenario.id === 'mobile-2' && (
              <MobileDeviceSimulation
                type="fake-store"
                image={currentScenario.image}
                onAction={(action) => {
                  if (action === 'install') {
                    selectOption(currentScenario.id, 'm2-1'); // Uygulamayı indirme
                    setShowExplanation(true);
                  } else if (action === 'close') {
                    selectOption(currentScenario.id, 'm2-2'); // Resmi mağazadan indirme
                    setShowExplanation(true);
                  }
                }}
              />
            )}
            {attackActive && (
              <div className="absolute top-4 right-4 z-20 w-60">
                <CyberAttackAnimation type="mobile" />
              </div>
            )}
          </div>
        );
      case 'physical':
        // Fiziksel güvenlik simülasyonu
        return (
          <div className="mb-4 relative flex flex-col items-center">
            {currentScenario.id === 'physical-1' && (
              <PhysicalSecuritySimulation
                onAction={(action) => {
                  if (action === 'open-door') {
                    selectOption(currentScenario.id, 'ph1-1'); // Kapıyı açma
                    setShowExplanation(true);
                  } else if (action === 'call-security') {
                    selectOption(currentScenario.id, 'ph1-2'); // Güvenlik/tesis yönetimini arama
                    setShowExplanation(true);
                  } else if (action === 'deny-access') {
                    selectOption(currentScenario.id, 'ph1-3'); // Erişimi reddetme
                    setShowExplanation(true);
                  }
                }}
              />
            )}
            {currentScenario.id === 'physical-2' && (
              <PhysicalSecuritySimulation
                type="server-room"
                onAction={(action) => {
                  if (action === 'approach-directly') {
                    selectOption(currentScenario.id, 'ph2-1'); // Doğrudan yaklaşma
                    setShowExplanation(true);
                  } else if (action === 'call-security') {
                    selectOption(currentScenario.id, 'ph2-3'); // Güvenlik çağırma ve gözlemleme
                    setShowExplanation(true);
                  } else if (action === 'walk-away') {
                    selectOption(currentScenario.id, 'ph2-2'); // Uzaklaşma
                    setShowExplanation(true);
                  }
                }}
              />
            )}
            {attackActive && (
              <div className="absolute top-4 right-4 z-20 w-60">
                <CyberAttackAnimation type="mitm" />
              </div>
            )}
          </div>
        );
      case 'aivoice':
        // Yapay zeka destekli oltalama simülasyonu
        return (
          <div className="mb-4 relative flex flex-col items-center">
            <AISecuritySimulation
              type="voice-analysis"
              onAction={(action) => {
                if (action === 'click-link') {
                  selectOption(currentScenario.id, 'ai1-1'); // Bağlantıya tıklama
                  setShowExplanation(true);
                } else if (action === 'verify-communication') {
                  selectOption(currentScenario.id, 'ai1-2'); // İletişimi doğrulama
                  setShowExplanation(true);
                } else if (action === 'analyze-more') {
                  selectOption(currentScenario.id, 'ai1-3'); // Daha fazla analiz
                  setShowExplanation(true);
                }
              }}
            />
            {attackActive && (
              <div className="absolute top-4 right-4 z-20 w-60">
                <CyberAttackAnimation type="ai" />
              </div>
            )}
          </div>
        );
      case 'aidata':
        // Yapay zeka veri güvenliği simülasyonu
        return (
          <div className="mb-4 relative flex flex-col items-center">
            {(currentScenario.id === 'ai-ethics-1') && (
              <AISecuritySimulation
                type="data-security"
                onAction={(action) => {
                  if (action === 'disable-ai') {
                    selectOption(currentScenario.id, 'ai2-1'); // AI sistemini devre dışı bırak
                    setShowExplanation(true);
                  } else if (action === 'reconfigure-ai') {
                    selectOption(currentScenario.id, 'ai2-2'); // AI sistemini yeniden yapılandır
                    setShowExplanation(true);
                  } else if (action === 'ignore-problem') {
                    selectOption(currentScenario.id, 'ai2-3'); // Sorunu görmezden gel
                    setShowExplanation(true);
                  }
                }}
              />
            )}
            {currentScenario.id === 'ai-security-2' && (
              <AISecuritySimulation
                type="model-manipulation"
                onAction={(action) => {
                  if (action === 'disable-ai') {
                    selectOption(currentScenario.id, 'ai2-1'); // Chatbot'u kapat
                    setShowExplanation(true);
                  } else if (action === 'restore-backup') {
                    selectOption(currentScenario.id, 'ai2-2'); // Yedekten geri yükle
                    setShowExplanation(true);
                  } else if (action === 'ignore-problem') {
                    selectOption(currentScenario.id, 'ai2-3'); // Sorunu görmezden gel
                    setShowExplanation(true);
                  }
                }}
              />
            )}
            {attackActive && (
              <div className="absolute top-4 right-4 z-20 w-60">
                <CyberAttackAnimation type="ai" />
              </div>
            )}
          </div>
        );

      // Yeni: IoT Güvenlik Simülasyonu
      case 'iot':
        return (
          <div className="mb-4 relative flex flex-col items-center">
            <IoTSimulation
              type="smart-home"
              onAction={(action) => {
                if (action === 'secure-all-devices') {
                  selectOption(currentScenario.id, 'iot1-1'); // Tüm cihazları güncelleyip güvenliğini artır
                  setShowExplanation(true);
                } else if (action === 'ignore-security') {
                  selectOption(currentScenario.id, 'iot1-2'); // Güvenlik uyarılarını görmezden gel
                  setShowExplanation(true);
                }
              }}
            />
            {attackActive && (
              <div className="absolute top-4 right-4 z-20 w-60">
                <CyberAttackAnimation type="iot" />
              </div>
            )}
          </div>
        );

      // Yeni: Blockchain/Kripto Para Güvenlik Simülasyonu
      case 'blockchain':
        return (
          <div className="mb-4 relative flex flex-col items-center">
            <BlockchainSecuritySimulation
              type="crypto-wallet"
              onAction={(action) => {
                if (action === 'reject-transaction') {
                  selectOption(currentScenario.id, 'bc1-2'); // İşlemi reddet - doğru seçenek
                  setShowExplanation(true);
                } else if (action === 'approve-transaction') {
                  selectOption(currentScenario.id, 'bc1-1'); // İşlemi onayla - yanlış seçenek
                  setShowExplanation(true);
                } else if (action === 'increase-security') {
                  selectOption(currentScenario.id, 'bc1-2'); // Güvenliği artır - doğru seçenek
                  setShowExplanation(true);
                }
              }}
            />
            {attackActive && (
              <div className="absolute top-4 right-4 z-20 w-60">
                <CyberAttackAnimation type="phishing" />
              </div>
            )}
          </div>
        );

      default:
        return (
          <>
            <CyberContainer className="mb-4 relative">
              {/* Matrix arka plan efekti - zorluk seviyesi hard ise daha hızlı ve yoğun */}
              <div className="absolute inset-0 overflow-hidden opacity-20">
                <BackgroundMatrix
                  density={difficultyLevel === 'hard' ? 'high' : 'medium'}
                  speed={difficultyLevel === 'hard' ? 'fast' : 'medium'}
                />
              </div>

              <CardHeader className="p-4 pb-2 relative z-10">
                <CardTitle className={`text-xl font-bold ${color}`}>
                  <span data-text={currentScenario.title} className={`glitch-text ${difficultyLevel === 'hard' ? 'flicker-animation' : ''}`}>
                    <CyberGlitchText intensity={difficultyLevel === 'hard' ? 'high' : 'low'}>{currentScenario.title}</CyberGlitchText>
                  </span>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  {label} - Karar vermeniz gereken bir durum
                </CardDescription>
              </CardHeader>

              <CardContent className="p-4 space-y-4 relative z-10">
                <p className={`text-white/90 ${attackActive && !currentScenario.completed && 'glitch-text'}`}>
                  {currentScenario.description}
                </p>

                {/* Senaryo görselini iyileştirilmiş şekilde göster - Daha büyük görüntü için yüksekliği artırdık */}
                {currentScenario.image && (
                  <div className="relative h-96 w-full rounded-md overflow-hidden border border-primary/30 my-6 group hover:border-primary/60 transition-all duration-300">
                    {/* Görsel üzerinde hafif bir glitch efekti */}
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-all pointer-events-none z-10" />

                    {/* Saldırı aktifken glitch efekti */}
                    {attackActive && !currentScenario.completed && (
                      <div className="absolute inset-0 z-20 pointer-events-none">
                        <div className={`absolute inset-0 ${getAttackTypeForScenario(currentScenario.type) === 'phishing' ? 'bg-red-500/5' :
                          getAttackTypeForScenario(currentScenario.type) === 'network' ? 'bg-blue-500/5' :
                          'bg-purple-500/5'} glitch`}></div>
                      </div>
                    )}

                    <Image
                      src={currentScenario.image}
                      alt={currentScenario.title}
                      fill
                      style={{ objectFit: 'contain' }}
                      className="p-4 bg-black transition-all duration-300 group-hover:scale-105"
                      priority
                    />
                  </div>
                )}

                {/* Saldırı Açıklaması */}
                {attackActive && !currentScenario.completed && (
                  <div className={`p-4 rounded-md text-base ${getAttackColorClass(getAttackTypeForScenario(currentScenario.type))} slide-in-right`}>
                    <h4 className="text-base font-semibold mb-2 flex items-center">
                      {getAttackIcon(getAttackTypeForScenario(currentScenario.type))}
                      <span className="ml-2">{getAttackLabel(getAttackTypeForScenario(currentScenario.type))}</span>
                    </h4>
                    <p className="text-sm opacity-80">
                      {getAttackDescription(getAttackTypeForScenario(currentScenario.type), difficultyLevel)}
                    </p>
                  </div>
                )}

                {!currentScenario.completed && (
                  <div className="mt-5 font-semibold text-primary text-lg">Nasıl tepki verirsiniz?</div>
                )}
              </CardContent>

              {/* Saldırı animasyonu */}
              {attackActive && !currentScenario.completed && (
                <div className="absolute top-4 right-4 z-20 w-60">
                  <CyberAttackAnimation type={attackType} />
                </div>
              )}
            </CyberContainer>

            {/* Öğrenme Materyalleri Butonu */}
            {availableMedia.length > 0 && (
              <div className="mb-4">
                <Button
                  variant="outline"
                  className="w-full border-primary/50 hover:border-primary hover:bg-primary/10"
                  onClick={() => setShowMediaGallery(!showMediaGallery)}
                >
                  <span className="mr-2">📚</span>
                  {showMediaGallery ? 'Öğrenme Materyallerini Gizle' : 'Öğrenme Materyallerini Göster'}
                </Button>
              </div>
            )}

            {/* Medya Galeri Görünümü */}
            {showMediaGallery && availableMedia.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                {availableMedia.map((media) => (
                  <Card
                    key={media.id}
                    className="cursor-pointer hover:bg-gray-900/50 border-primary/20 hover:border-primary/50 transition-all duration-300"
                    onClick={() => handleOpenMedia(media.id)}
                  >
                    <CardHeader className="p-3 pb-2">
                      <CardTitle className="text-sm font-medium">{media.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 pt-0">
                      <div className="text-xs text-gray-400 line-clamp-2">{media.description}</div>
                      <div className="mt-2 flex gap-1">
                        <Badge variant="outline" className="text-xs">
                          {media.type === 'video' ? '🎬 Video' :
                           media.type === 'image' ? '🖼️ Resim' :
                           media.type === 'infographic' ? '📊 İnfografik' :
                           '📄 Doküman'}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Aktif Medya İçeriği */}
            {activeMedia && (
              <div className="mb-4">
                <MultimediaViewer
                  content={activeMedia}
                  onClose={() => setActiveMedia(null)}
                />
              </div>
            )}

            {/* Seçenekler */}
            <div className="grid gap-3 mb-4">
              {currentScenario.options.map((option) => {
                const isSelected = currentScenario.selectedOption === option.id;
                const buttonClassName = isSelected
                  ? option.correct
                    ? "border-green-500 bg-green-900/20 hover:bg-green-900/30 text-left justify-start"
                    : "border-red-500 bg-red-900/20 hover:bg-red-900/30 text-left justify-start"
                  : "border-primary/30 hover:border-primary/60 text-left justify-start";

                // Simge seçimi - seçenek içeriğine göre uygun simge ekleyin
                let optionIcon = "";
                if (option.text.toLowerCase().includes("şifre") || option.text.toLowerCase().includes("izin")) {
                  optionIcon = "🔐 ";
                } else if (option.text.toLowerCase().includes("güncelleme") || option.text.toLowerCase().includes("kur")) {
                  optionIcon = "🔄 ";
                } else if (option.text.toLowerCase().includes("reddet") || option.text.toLowerCase().includes("silin")) {
                  optionIcon = "🗑️ ";
                } else if (option.text.toLowerCase().includes("bildirin") || option.text.toLowerCase().includes("bildir")) {
                  optionIcon = "🚨 ";
                } else if (option.text.toLowerCase().includes("kontrol") || option.text.toLowerCase().includes("doğrula")) {
                  optionIcon = "✓ ";
                } else if (option.text.toLowerCase().includes("yardım")) {
                  optionIcon = "💬 ";
                } else if (option.text.toLowerCase().includes("tıkla")) {
                  optionIcon = "🖱️ ";
                } else if (option.text.toLowerCase().includes("telefon") || option.text.toLowerCase().includes("ara")) {
                  optionIcon = "📱 ";
                } else {
                  optionIcon = "🔍 ";
                }

                return (
                  <Button
                    key={option.id}
                    variant="outline"
                    className={`${buttonClassName} p-4 h-auto flex items-start transition-all duration-300`}
                    disabled={currentScenario.completed && !isSelected}
                    onClick={() => handleSelectOption(option.id)}
                  >
                    <div className="flex items-start">
                      <span className="text-xl mr-3">{optionIcon}</span>
                      <div>
                        <span className="font-medium">{option.text}</span>
                        {isSelected && (
                          <div className={`mt-2 text-sm ${option.correct ? 'text-green-400' : 'text-red-400'}`}>
                            {option.correct ? '✓ Doğru seçim!' : '✗ Yanlış seçim!'}
                          </div>
                        )}
                      </div>
                    </div>
                  </Button>
                );
              })}
            </div>
          </>
        );
    }
  };

  // Süre göstergesini render et
  const renderTimer = () => {
    if (difficultyLevel === 'hard' && timeRemaining !== null && timeRemaining > 0 && !currentScenario.completed) {
      const minutes = Math.floor(timeRemaining / 60);
      const seconds = timeRemaining % 60;
      const formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

      return (
        <div className="flex items-center space-x-2">
          <div className="text-sm text-yellow-400">Süre: {formattedTime}</div>
          <Progress
            value={(timeRemaining / (currentScenario.timeLimit || 60)) * 100}
            className="w-24 h-2 bg-yellow-950"
            indicatorClassName={`${
              timeRemaining < 10 ? 'bg-red-500 animate-pulse' : 'bg-yellow-500'
            }`}
          />
        </div>
      );
    }

    return null;
  };

  // Saldırı türüne göre renk sınıfını belirle
  const getAttackColorClass = (attackType: string) => {
    switch (attackType) {
      case 'phishing':
        return 'bg-red-900/30 border border-red-500/40';
      case 'malware':
        return 'bg-purple-900/30 border border-purple-500/40';
      case 'ddos':
      case 'dos':
        return 'bg-blue-900/30 border border-blue-500/40';
      case 'encryption':
      case 'ransomware':
        return 'bg-yellow-900/30 border border-yellow-500/40';
      case 'injection':
        return 'bg-green-900/30 border border-green-500/40';
      case 'network':
        return 'bg-cyan-900/30 border border-cyan-500/40';
      case 'mitm':
        return 'bg-amber-900/30 border border-amber-500/40';
      case 'social':
        return 'bg-orange-900/30 border border-orange-500/40';
      case 'bruteforce':
        return 'bg-indigo-900/30 border border-indigo-500/40';
      case 'ai':
        return 'bg-violet-900/30 border border-violet-500/40';
      case 'iot':
        return 'bg-teal-900/30 border border-teal-500/40';
      case 'blockchain':
        return 'bg-rose-900/30 border border-rose-500/40';
      default:
        return 'bg-gray-900/30 border border-gray-500/40';
    }
  };

  // Saldırı türüne göre simge
  const getAttackIcon = (attackType: string) => {
    switch (attackType) {
      case 'phishing':
        return '📧';
      case 'malware':
        return '🦠';
      case 'ddos':
      case 'dos':
        return '🌐';
      case 'encryption':
        return '🔒';
      case 'ransomware':
        return '🔐';
      case 'injection':
        return '💉';
      case 'network':
        return '📡';
      case 'mitm':
        return '🕵️';
      case 'social':
        return '👤';
      case 'bruteforce':
        return '🔨';
      case 'ai':
        return '🤖';
      case 'iot':
        return '🏠';
      case 'blockchain':
        return '💰';
      default:
        return '⚠️';
    }
  };

  // Saldırı türüne göre etiket
  const getAttackLabel = (attackType: string) => {
    switch (attackType) {
      case 'phishing':
        return 'Oltalama Saldırısı Riski';
      case 'malware':
        return 'Kötücül Yazılım Tehdidi';
      case 'ddos':
        return 'DDoS Saldırısı Tespit Edildi';
      case 'dos':
        return 'DoS Saldırısı Riski';
      case 'encryption':
        return 'Şifreleme Saldırısı';
      case 'ransomware':
        return 'Fidye Yazılımı Tehdidi';
      case 'injection':
        return 'Kod Enjeksiyon Riski';
      case 'network':
        return 'Ağ Güvenlik Tehdidi';
      case 'mitm':
        return 'Ortadaki Adam Saldırısı';
      case 'social':
        return 'Sosyal Mühendislik Tehdidi';
      case 'bruteforce':
        return 'Kaba Kuvvet Saldırısı';
      case 'ai':
        return 'Yapay Zeka Destekli Saldırı';
      case 'iot':
        return 'IoT Güvenlik Tehdidi';
      case 'blockchain':
        return 'Blockchain Güvenlik Tehdidi';
      default:
        return 'Bilinmeyen Saldırı Tipi';
    }
  };

  // Saldırı türüne göre açıklama
  const getAttackDescription = (attackType: string, difficulty: string) => {
    const detailedMode = difficulty === 'easy' || difficulty === 'medium';

    switch (attackType) {
      case 'phishing':
        return detailedMode
          ? 'Oltalama e-postaları, mesajları veya web siteleri, meşru görünen ancak bilgi çalmayı amaçlayan içeriklerdir. E-posta adresleri, hatalı dilbilgisi ve aciliyet içeren mesajlara dikkat edin.'
          : 'Meşru görünen sahte e-posta veya mesaj saldırısı. Kimlik bilgilerinizi hedefler.';
      case 'malware':
        return detailedMode
          ? 'Kötücül yazılımlar bilgisayarınıza zarar vermek, verileri çalmak veya sistemi kontrol etmek için tasarlanmış programlardır. Virüs, trojan, solucan veya fidye yazılımları bu kategoriye girer.'
          : 'Sistemde zararlı yazılım tespit edildi. Verileriniz risk altında.';
      case 'ddos':
        return detailedMode
          ? 'Dağıtılmış Hizmet Engelleme (DDoS) saldırıları, çok sayıda kaynaktan bir sisteme, hizmete veya ağa aşırı trafik göndererek erişimi engellemeyi amaçlar.'
          : 'Sistem üzerinde yoğun trafik oluşturarak hizmet dışı bırakmayı amaçlayan saldırı.';
      case 'dos':
        return detailedMode
          ? 'Hizmet Engelleme (DoS) saldırıları, tek bir kaynaktan gelen yoğun trafik ile sistemi veya ağı çökertmeyi hedefler.'
          : 'Sistem kaynaklarını tüketerek hizmet dışı bırakmayı amaçlayan saldırı.';
      case 'encryption':
        return detailedMode
          ? 'Şifreleme saldırıları, şifreli verilere erişmek için çeşitli teknikler kullanır. Bu saldırılar, zayıf şifreleme algoritmaları veya anahtar yönetimi sorunlarını hedefler.'
          : 'Şifreli verilerinize yetkisiz erişim riski tespit edildi.';
      case 'ransomware':
        return detailedMode
          ? 'Fidye yazılımları, dosyalarınızı şifreler ve erişim için fidye talep eder. Genellikle e-posta ekleri veya kötücül siteler aracılığıyla yayılır.'
          : 'Sisteminizdeki veriler şifrelenerek fidye talep edilebilir.';
      case 'injection':
        return detailedMode
          ? 'Kod enjeksiyon saldırıları, zararlı kodun uygulamanıza enjekte edilmesini içerir. SQL enjeksiyonları, XSS (Siteler Arası Komut Dosyası) ve komut enjeksiyonları yaygın örneklerdir.'
          : 'Güvenli olmayan giriş verileri sisteme zararlı kod enjekte etmeye çalışabilir.';
      case 'network':
        return detailedMode
          ? 'Ağ saldırıları, ağ trafiğini dinleme, sahte paketler gönderme veya kimlik taklidi yapma gibi teknikler kullanır. Güvensiz Wi-Fi ağları özellikle risk altındadır.'
          : 'Ağ trafiğinizde anormallik tespit edildi. Veri sızma riski yüksek.';
      case 'mitm':
        return detailedMode
          ? 'Ortadaki Adam saldırıları, iki taraf arasındaki iletişimi gizlice dinleyen veya değiştiren saldırılardır. Şifrelenmemiş ağlar bu saldırılar için ideal ortamlardır.'
          : 'İletişiminiz üçüncü taraflar tarafından dinleniyor olabilir.';
      case 'social':
        return detailedMode
          ? 'Sosyal mühendislik, insanları kandırarak bilgi vermeye, güvenlik protokollerini atlamaya veya zararlı eylemler gerçekleştirmeye ikna etme sanatıdır. Hedef genellikle insan zafiyetleridir.'
          : 'Kişisel manipülasyon yoluyla bilgi elde etmeye çalışan saldırı tespit edildi.';
      case 'bruteforce':
        return detailedMode
          ? 'Kaba kuvvet saldırıları, bir şifreyi veya şifreleme anahtarını, tüm olası kombinasyonları deneyerek kırmaya çalışır. Zayıf şifreler bu tür saldırılara daha açıktır.'
          : 'Sistemlerinize yetkisiz erişim için şifre tahmin girişimleri tespit edildi.';
      case 'ai':
        return detailedMode
          ? 'Yapay zeka destekli saldırılar, ses taklidi, derin sahte (deepfake) içerik oluşturma veya gelişmiş şifre kırma teknikleri gibi yeni nesil tehditlerdir. Bu saldırılar zamanla daha sofistike hale gelmektedir.'
          : 'Yapay zeka teknolojileri kullanılarak geliştirilmiş güvenlik tehdidi tespit edildi.';
      case 'iot':
        return detailedMode
          ? 'IoT cihazları, güvenlik açıkları nedeniyle hedef olabilir. Tüm cihazların güncellenmesi ve güvenliğinin sağlanması önemlidir.'
          : 'IoT cihazlarınızda güvenlik açıkları tespit edildi.';
      case 'blockchain':
        return detailedMode
          ? 'Blockchain sistemleri, işlem güvenliği sağlamak için çeşitli teknikler kullanır. Ancak, yanlış onaylanan işlemler büyük kayıplara yol açabilir.'
          : 'Blockchain işlemlerinizde güvenlik riski tespit edildi.';
      default:
        return 'Bilinmeyen tipte bir siber saldırı tespit edildi. Güvenlik önlemlerinizi gözden geçirin.';
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-black text-white p-4">
      {/* Üst bilgi paneli */}
      <div className="flex justify-between items-center mb-4">
        <div className="flex space-x-2 items-center">
          <Badge className={badge}>
            {label}
          </Badge>
          <div className="text-sm">
            Senaryo: {currentScenarioIndex + 1}/{scenarios.length}
          </div>
        </div>

        <div className="flex space-x-4">
          {renderTimer()}
          <div className="flex flex-col items-end">
            <div className="text-xs text-muted-foreground mb-1">Skor</div>
            <Progress value={scorePercentage} className="w-24 h-2 bg-green-950" indicatorClassName="bg-green-500" />
          </div>
          <div className="flex flex-col items-end">
            <div className="text-xs text-muted-foreground mb-1">Risk</div>
            <Progress value={riskPercentage} className="w-24 h-2 bg-red-950" indicatorClassName="bg-red-500" />
          </div>
        </div>
      </div>

      {/* İpuçları - Kolay zorluk seviyesinde göster */}
      {difficultyLevel === 'easy' && !currentScenario.completed && currentScenario.simulationType === 'quiz' && (
        <div className="mb-4 bg-blue-900/30 border border-blue-500/40 rounded-md p-3">
          <h4 className="text-blue-400 font-medium mb-1">İpucu:</h4>
          <p className="text-sm text-blue-200/80">
            {currentScenario.type === 'phishing' && "E-posta adresi, aciliyet ifadeleri ve yazım hataları gibi ipuçlarına dikkat edin."}
            {currentScenario.type === 'password' && "Güçlü şifreler karmaşık, uzun ve tahmin edilmesi zordur."}
            {currentScenario.type === 'software' && "Güvenlik güncellemeleri, sisteminizi korumak için önemlidir."}
            {currentScenario.type === 'social' && "Kimlik doğrulama her zaman önemlidir, resmi kanallardan iletişim kurun."}
            {currentScenario.type === 'network' && "Ağ güvenliği için proaktif önlemler almak önemlidir."}
            {currentScenario.type === 'terminal' && "Terminal komutları, güvenlik denetimi için güçlü araçlardır."}
            {currentScenario.type === 'desktop' && "Şüpheli uygulamalardan ve dosyalardan uzak durun."}
            {currentScenario.type === 'mobile' && "Uygulamaların yalnızca gerçekten ihtiyaç duydukları izinleri verin."}
            {currentScenario.type === 'physical' && "Fiziksel erişim izinlerinde her zaman doğrulama yapın."}
          </p>
        </div>
      )}

      {/* Simülasyon içeriği */}
      {renderSimulation()}

      {/* Açıklama ve Sonraki butonları */}
      {showExplanation && selectedOption && (
        <div className="mt-auto">
          <Card className={`mb-4 border ${selectedOption.correct ? 'border-green-500' : 'border-red-500'}`}>
            <CardContent className="p-4">
              <h3 className={`font-bold mb-2 ${selectedOption.correct ? 'text-green-400' : 'text-red-400'}`}>
                {selectedOption.correct ? '✅ Doğru Karar!' : '❌ Yanlış Karar!'}
              </h3>
              <p>{selectedOption.explanation}</p>

              {!selectedOption.correct && (
                <div className="mt-2 text-red-400">
                  Risk seviyesi {selectedOption.risk} puan arttı!
                </div>
              )}
            </CardContent>
          </Card>

          <Button onClick={handleNext} className="w-full" size="lg">
            Sonraki Senaryo
          </Button>
        </div>
      )}

      {/* Simülasyon senaryoları için ilerleme butonu */}
      {currentScenario.simulationType && currentScenario.simulationType !== 'quiz' && !currentScenario.completed && (
        <div className="mt-4 grid gap-4">
          <p className="text-sm text-center text-gray-400">
            Bu simülasyonda öğrendiğiniz güvenlik tekniklerini deneyimleyin. Simülasyonu tamamladığınızda ilerlemek için bir seçeneği seçin.
          </p>
          <div className="grid gap-3">
            {currentScenario.options.map((option) => (
              <Button
                key={option.id}
                variant="outline"
                className="border-primary/30 hover:border-primary/60 text-left justify-start transition-all duration-300"
                onClick={() => handleSelectOption(option.id)}
              >
                {option.text}
              </Button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
