"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useGameStore, type DifficultyLevel } from "@/store/gameStore";
import { CyberGlitchText, BackgroundMatrix } from "@/components/ui/cyber-effects";
import { Badge } from "@/components/ui/badge";

export function WelcomeScreen() {
  const [usernameInput, setUsernameInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const { setUsername, startGame, difficultyLevel, setDifficultyLevel } = useGameStore();

  const handleStart = () => {
    if (!usernameInput.trim()) {
      setError("Lütfen bir kullanıcı adı girin");
      return;
    }
    setError(null);
    setUsername(usernameInput);
    startGame();
  };

  const handleSetDifficulty = (level: DifficultyLevel) => {
    setDifficultyLevel(level);
  };

  // Zorluk seviyesi açıklamaları
  const difficultyDescriptions = {
    easy: "Temel seviye - Daha fazla ipucu ve süre sınırı yok",
    medium: "Normal seviye - Standart senaryolar",
    hard: "Zor seviye - Bazı senaryolarda süre sınırı ve daha az ipucu"
  };

  return (
    <div className="flex min-h-screen bg-black text-white items-center justify-center p-4 md:p-8 relative">
      {/* Minimal matrix arka plan */}
      <div className="absolute inset-0 opacity-20 overflow-hidden">
        <BackgroundMatrix density="low" speed="slow" />
      </div>

      {/* Soldan gelen neon vurgu */}
      <div className="absolute left-0 top-0 h-full w-2 bg-gradient-to-b from-primary via-primary/30 to-transparent"></div>

      {/* Sağdan gelen neon vurgu */}
      <div className="absolute right-0 top-0 h-full w-2 bg-gradient-to-b from-transparent via-primary/30 to-primary"></div>

      <div className="w-full max-w-4xl relative z-10">
        {/* Header Kısmı */}
        <div className="text-center mb-8 max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/60">
              SİBER GÜVENLİK
            </span>
            <span className="block mt-1">
              <CyberGlitchText>SİMÜLASYONU</CyberGlitchText>
            </span>
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Çeşitli siber tehditler karşısında karar verme yeteneğinizi test edin. Şirket siber güvenlik ekibi olarak tehditleri analiz edin ve en iyi cevabı seçin.
          </p>
        </div>

        <div className="grid md:grid-cols-5 gap-8">
          {/* Sol Panel - Tanıtım */}
          <div className="md:col-span-2 space-y-4">
            <Card className="bg-black/80 border-primary/20 overflow-hidden">
              <CardHeader className="p-4 pb-2 border-b border-primary/10">
                <CardTitle className="text-lg text-primary">YENİ MODÜLLER V8</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-4">
                  {/* Yeni Modüller */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 rounded-md bg-indigo-950/40 border border-indigo-500/30">
                      <div className="flex-shrink-0 w-10 h-10 bg-indigo-900/50 rounded-full flex items-center justify-center text-xl">🔐</div>
                      <div>
                        <div className="font-medium text-indigo-300">Fiziksel Güvenlik</div>
                        <div className="text-xs text-gray-400">
                          Erişim kontrolü, sosyal mühendislik, fiziksel tehditler
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 rounded-md bg-purple-950/40 border border-purple-500/30">
                      <div className="flex-shrink-0 w-10 h-10 bg-purple-900/50 rounded-full flex items-center justify-center text-xl">🤖</div>
                      <div>
                        <div className="font-medium text-purple-300">Yapay Zeka Güvenliği</div>
                        <div className="text-xs text-gray-400">
                          AI ses analizi, chatbot manipülasyonu, model müdahalesi
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-300 mb-2">Mevcut Modüller</h3>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="bg-red-900/30 text-red-300 border-red-500/30">Oltalama</Badge>
                      <Badge variant="outline" className="bg-blue-900/30 text-blue-300 border-blue-500/30">Ağ Güvenliği</Badge>
                      <Badge variant="outline" className="bg-green-900/30 text-green-300 border-green-500/30">Terminal</Badge>
                      <Badge variant="outline" className="bg-cyan-900/30 text-cyan-300 border-cyan-500/30">Masaüstü</Badge>
                      <Badge variant="outline" className="bg-amber-900/30 text-amber-300 border-amber-500/30">Mobil</Badge>
                      <Badge variant="outline" className="bg-pink-900/30 text-pink-300 border-pink-500/30">Şifre</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="p-4 border border-primary/20 bg-black/80 rounded-md">
              <div className="flex items-center gap-2 mb-3">
                <div className="h-3 w-3 rounded-full bg-green-500 animate-pulse"></div>
                <h3 className="text-sm font-medium">Simülasyon İstatistikleri</h3>
              </div>

              <div className="grid grid-cols-2 gap-4 text-center text-sm">
                <div className="p-2 border border-gray-800 rounded">
                  <div className="text-2xl font-bold text-primary mb-1">10+</div>
                  <div className="text-xs text-gray-400">Senaryo</div>
                </div>

                <div className="p-2 border border-gray-800 rounded">
                  <div className="text-2xl font-bold text-primary mb-1">7</div>
                  <div className="text-xs text-gray-400">Güvenlik Alanı</div>
                </div>

                <div className="p-2 border border-gray-800 rounded">
                  <div className="text-2xl font-bold text-primary mb-1">3</div>
                  <div className="text-xs text-gray-400">Zorluk Seviyesi</div>
                </div>

                <div className="p-2 border border-gray-800 rounded">
                  <div className="text-2xl font-bold text-primary mb-1">100%</div>
                  <div className="text-xs text-gray-400">Etkileşimli</div>
                </div>
              </div>
            </div>
          </div>

          {/* Sağ Panel - Giriş Formu */}
          <div className="md:col-span-3">
            <Card className="bg-black/80 border-primary/20">
              <CardHeader className="border-b border-primary/10 p-4 pb-4">
                <CardTitle>Kullanıcı Girişi</CardTitle>
                <CardDescription>
                  Simülasyona başlamak için bilgilerinizi girin
                </CardDescription>
              </CardHeader>

              <CardContent className="p-6 space-y-5">
                {/* Hata Mesajı */}
                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {/* Kullanıcı Adı */}
                <div className="space-y-2">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-primary rounded-full mr-2"></div>
                    <label htmlFor="username" className="text-sm font-medium leading-none">
                      Kullanıcı Adınız
                    </label>
                  </div>
                  <Input
                    id="username"
                    placeholder="Adınızı girin"
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    className="bg-black/50 border-gray-800 focus:border-primary text-white"
                  />
                </div>

                {/* Zorluk Seviyesi */}
                <div className="space-y-3">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-primary rounded-full mr-2"></div>
                    <label className="text-sm font-medium">Zorluk Seviyesi</label>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <button
                      className={`p-3 text-center rounded-md transition-all border ${
                        difficultyLevel === "easy"
                          ? "bg-green-950/40 border-green-500 text-green-300"
                          : "bg-black/30 border-green-500/30 text-green-400/70 hover:bg-green-950/20"
                      }`}
                      onClick={() => handleSetDifficulty("easy")}
                    >
                      <div className="text-lg font-semibold">Kolay</div>
                    </button>

                    <button
                      className={`p-3 text-center rounded-md transition-all border ${
                        difficultyLevel === "medium"
                          ? "bg-blue-950/40 border-blue-500 text-blue-300"
                          : "bg-black/30 border-blue-500/30 text-blue-400/70 hover:bg-blue-950/20"
                      }`}
                      onClick={() => handleSetDifficulty("medium")}
                    >
                      <div className="text-lg font-semibold">Normal</div>
                    </button>

                    <button
                      className={`p-3 text-center rounded-md transition-all border ${
                        difficultyLevel === "hard"
                          ? "bg-red-950/40 border-red-500 text-red-300"
                          : "bg-black/30 border-red-500/30 text-red-400/70 hover:bg-red-950/20"
                      }`}
                      onClick={() => handleSetDifficulty("hard")}
                    >
                      <div className="text-lg font-semibold">Zor</div>
                    </button>
                  </div>

                  <p className="text-xs text-gray-400 mt-1 italic">
                    {difficultyDescriptions[difficultyLevel]}
                  </p>
                </div>
              </CardContent>

              <CardFooter className="p-6 pt-0">
                <Button
                  className="w-full bg-primary hover:bg-primary/80 text-black"
                  onClick={handleStart}
                  size="lg"
                >
                  <span className="mr-2">▶</span> Simülasyonu Başlat
                </Button>
              </CardFooter>
            </Card>

            <div className="mt-4 text-xs text-gray-500 text-center">
              <div>Siber Güvenlik Simülasyonu v8.0 • {new Date().toLocaleDateString('tr-TR')}</div>
              <div className="mt-1">Geliştirici: <span className="text-primary font-semibold">Siber.php</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
