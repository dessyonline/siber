"use client";

import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface AISecuritySimulationProps {
  type?: 'voice-analysis' | 'data-security' | 'model-manipulation';
  onAction?: (action: string) => void;
}

export function AISecuritySimulation({ type = 'voice-analysis', onAction }: AISecuritySimulationProps) {
  const [stage, setStage] = useState<'initial' | 'analysis' | 'decision'>('initial');
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [anomalyDetails, setAnomalyDetails] = useState<string[]>([]);
  const [securityScan, setSecurityScan] = useState(false);

  const soundWaveRef = useRef<HTMLDivElement>(null);

  // Ses analizi animasyonu
  useEffect(() => {
    if (stage === 'analysis' && type === 'voice-analysis') {
      const interval = setInterval(() => {
        setAnalysisProgress(prev => {
          const newProgress = prev + 2;
          if (newProgress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              setAnomalyDetails([
                'Ses tonu doğal değil',
                'Yapay ses modeli izleri tespit edildi',
                'E-posta adresi ile önceki yazışmalardan farklı dilbilgisi yapısı',
                'Aciliyet içeren ifadeler yapay zeka taktikleriyle uyumlu',
                'Bağlantının domain adı resmi e-posta ile uyuşmuyor'
              ]);
              setStage('decision');
            }, 500);
            return 100;
          }
          return newProgress;
        });
      }, 50);

      return () => clearInterval(interval);
    }
  }, [stage, type]);

  // Veri güvenliği analizi
  useEffect(() => {
    if (stage === 'analysis' && type === 'data-security') {
      const interval = setInterval(() => {
        setAnalysisProgress(prev => {
          const newProgress = prev + 1;
          if (newProgress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              setAnomalyDetails([
                'AI sistemi sohbet geçmişlerini gereksiz veriyle birlikte saklıyor',
                'Kimlik bilgileri yeterince anonimleştirilmiyor',
                'Veri saklama politikası şeffaf değil',
                'Önemli müşteri detayları log kayıtlarında saklanıyor',
                'Belirli veri tipleri için yetki sınırlaması yok'
              ]);
              setStage('decision');
            }, 500);
            return 100;
          }
          return newProgress;
        });
      }, 40);

      return () => clearInterval(interval);
    }
  }, [stage, type]);

  // Model manipülasyonu analizi
  useEffect(() => {
    if (stage === 'analysis' && type === 'model-manipulation') {
      const interval = setInterval(() => {
        setAnalysisProgress(prev => {
          const newProgress = prev + 1;
          if (newProgress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              setAnomalyDetails([
                'Chatbot yanıtlarında beklenmeyen saldırgan ifadeler tespit edildi',
                'Model, sınırlarının dışına çıkarak sistem hakkında bilgi sızdırıyor',
                'Eğitim verilerinde kötü niyetli veri enjeksiyonu belirtileri var',
                'Güvenlik sınırlamaları çeşitli oltalama teknikleriyle aşılmış',
                'Kullanıcı konuşmalarında model zehirleme denemeleri gözleniyor'
              ]);
              setStage('decision');
            }, 500);
            return 100;
          }
          return newProgress;
        });
      }, 30);

      return () => clearInterval(interval);
    }
  }, [stage, type]);

  // Ses dalgası animasyonu
  useEffect(() => {
    if (stage === 'analysis' && type === 'voice-analysis' && soundWaveRef.current) {
      const bars = soundWaveRef.current.children;
      const animateBars = () => {
        for (let i = 0; i < bars.length; i++) {
          const bar = bars[i] as HTMLElement;
          const height = Math.floor(Math.random() * 50) + 10;
          bar.style.height = `${height}px`;
        }
      };

      const interval = setInterval(animateBars, 100);
      return () => clearInterval(interval);
    }
  }, [stage, type]);

  // Analizi başlat
  const handleStartAnalysis = () => {
    setStage('analysis');
    setAnalysisProgress(0);
    setAnomalyDetails([]);
  };

  // E-postadaki bağlantıya tıkla
  const handleClickLink = () => {
    if (onAction) {
      onAction('click-link');
    }
  };

  // İletişimi doğrula
  const handleVerify = () => {
    if (onAction) {
      onAction('verify-communication');
    }
  };

  // Asistanı devre dışı bırak
  const handleDisableAI = () => {
    if (onAction) {
      onAction('disable-ai');
    }
  };

  // Asistanı yeniden yapılandır
  const handleReconfigureAI = () => {
    if (onAction) {
      onAction('reconfigure-ai');
    }
  };

  // Sorunu görmezden gel
  const handleIgnoreProblem = () => {
    if (onAction) {
      onAction('ignore-problem');
    }
  };

  // Ses analizi simülasyonu
  const renderVoiceAnalysis = () => {
    return (
      <div className="bg-gray-900 rounded-lg overflow-hidden p-0">
        <div className="p-4 border-b border-gray-800">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="h-10 w-10 bg-blue-600 rounded-full flex items-center justify-center text-white text-lg font-bold mr-3">E</div>
              <div>
                <div className="text-white">Emin Yılmaz &lt;e.yilmaz@company-mail.com&gt;</div>
                <div className="text-gray-400 text-sm">13:45 (5 dakika önce)</div>
              </div>
            </div>
            {stage === 'initial' && (
              <Badge className="bg-yellow-600 text-white">Yeni</Badge>
            )}
            {stage === 'analysis' && (
              <Badge className="bg-blue-600 text-white animate-pulse">Analiz Ediliyor</Badge>
            )}
            {stage === 'decision' && (
              <Badge className="bg-red-600 text-white">Şüpheli</Badge>
            )}
          </div>
        </div>

        <div className="p-4">
          <div className="text-lg font-bold text-white mb-1">ACİL: Proje Dosyaları Gerekli</div>
          <div className="text-gray-300 mb-4">
            <p className="mb-2">Merhaba,</p>
            <p className="mb-2">Acil bir durumla karşı karşıyayım. Geçen hafta konuştuğumuz XYZ projesi için dosyalara hemen erişmem gerekiyor. Müşteri acil değişiklikler talep ediyor.</p>
            <p className="mb-2">Aşağıdaki bağlantıdan dosyaları bana gönderebilir misin? Sisteme giriş yapmam gerekiyor ama VPN'im çalışmıyor.</p>

            <div className="my-4 p-3 bg-blue-900/30 border border-blue-500/30 rounded-md">
              <p className="text-blue-300 font-mono text-sm break-all">https://file-transfer-secure.project-docs.net/upload/?id=39275</p>
            </div>

            <p className="mb-2">Hemen yardımcı olabilir misin? Çok acil!</p>
            <p>Teşekkürler,<br />Emin</p>
          </div>

          <div className="mb-4">
            <div className="text-gray-300 text-sm mb-2">Ses Mesajı:</div>
            <div className="bg-gray-800 p-3 rounded-md flex items-center">
              <button className="h-8 w-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs mr-3">
                {stage === 'analysis' ? '⏹️' : '▶️'}
              </button>

              <div className="flex-1">
                <div
                  ref={soundWaveRef}
                  className="h-10 flex items-center space-x-1"
                >
                  {Array(40).fill(0).map((_, i) => (
                    <div
                      key={i}
                      className="w-1 bg-blue-400 rounded-full"
                      style={{
                        height: stage === 'analysis' ? undefined : `${Math.floor(Math.random() * 20) + 5}px`,
                        opacity: i % 2 === 0 ? 0.7 : 1
                      }}
                    ></div>
                  ))}
                </div>
                <div className="text-gray-400 text-xs">0:12</div>
              </div>
            </div>
          </div>

          {stage === 'analysis' && (
            <div className="mb-4">
              <div className="flex justify-between text-xs text-white mb-1">
                <span>AI Güvenlik Analizi</span>
                <span>{analysisProgress}%</span>
              </div>
              <Progress value={analysisProgress} className="h-2 bg-gray-800" indicatorClassName="bg-blue-500" />

              {analysisProgress > 30 && (
                <div className="mt-2 text-yellow-400 text-xs animate-pulse">
                  Anomaliler tespit ediliyor...
                </div>
              )}
            </div>
          )}

          {stage === 'decision' && (
            <div className="mb-4">
              <div className="bg-red-900/30 border border-red-500/30 rounded-md p-3 mb-4">
                <div className="text-red-300 font-bold mb-2 flex items-center">
                  <span className="text-lg mr-2">⚠️</span> AI Ses Analizi Uyarıları
                </div>
                <ul className="text-red-200 text-sm space-y-1">
                  {anomalyDetails.map((detail, index) => (
                    <li key={index} className="flex items-start">
                      <span className="mr-2">•</span>
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  // Veri güvenliği simülasyonu
  const renderDataSecurity = () => {
    return (
      <div className="bg-gray-900 rounded-lg overflow-hidden p-0">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center">
          <div className="flex items-center">
            <div className="h-10 w-10 bg-purple-600 rounded-full flex items-center justify-center text-white text-lg font-bold mr-3">AI</div>
            <div className="text-white text-lg font-bold">Müşteri Desteği AI Asistanı</div>
          </div>

          {stage === 'initial' && (
            <Badge className="bg-green-600 text-white">Aktif</Badge>
          )}
          {stage === 'analysis' && (
            <Badge className="bg-blue-600 text-white animate-pulse">Denetleniyor</Badge>
          )}
          {stage === 'decision' && (
            <Badge className="bg-red-600 text-white">Güvenlik Açığı</Badge>
          )}
        </div>

        <div className="p-4">
          <div className="mb-4">
            <div className="text-white mb-2">Sistem Özeti:</div>
            <div className="bg-gray-800 p-3 rounded-md text-gray-300 text-sm">
              <p className="mb-2">• Müşteri desteği sohbetleri için AI asistanı</p>
              <p className="mb-2">• Müşteri verilerine tam erişim yetkisi</p>
              <p className="mb-2">• Şirket CRM sistemiyle entegre</p>
              <p className="mb-2">• Günlük ~500 müşteri etkileşimi işliyor</p>
              <p>• Tüm sohbet geçmişleri bulut depolamada saklanıyor</p>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <div className="text-white">Çalışma Durumu:</div>
              <div className="flex">
                <Button
                  size="sm"
                  variant="outline"
                  className="mr-2 border-gray-600 text-gray-300"
                  onClick={() => setSecurityScan(!securityScan)}
                >
                  {securityScan ? 'Monitörü Kapat' : 'Performans Monitörü'}
                </Button>

                {stage === 'initial' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-blue-600 text-blue-400"
                    onClick={handleStartAnalysis}
                  >
                    Güvenlik Denetimi
                  </Button>
                )}
              </div>
            </div>

            {securityScan && (
              <div className="bg-gray-800 p-3 rounded-md mb-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-gray-400 text-xs mb-1">CPU Kullanımı</div>
                    <Progress value={67} className="h-1.5 bg-gray-700" indicatorClassName="bg-blue-500" />
                    <div className="text-gray-400 text-xs mt-1 text-right">67%</div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs mb-1">RAM Kullanımı</div>
                    <Progress value={83} className="h-1.5 bg-gray-700" indicatorClassName="bg-green-500" />
                    <div className="text-gray-400 text-xs mt-1 text-right">4.2 GB / 5 GB</div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs mb-1">Veri İşleme</div>
                    <Progress value={45} className="h-1.5 bg-gray-700" indicatorClassName="bg-purple-500" />
                    <div className="text-gray-400 text-xs mt-1 text-right">45 MB/s</div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs mb-1">Depolama</div>
                    <Progress value={92} className="h-1.5 bg-gray-700" indicatorClassName="bg-yellow-500" />
                    <div className="text-gray-400 text-xs mt-1 text-right">92%</div>
                  </div>
                </div>
              </div>
            )}

            {stage === 'analysis' && (
              <div className="mb-4 bg-gray-800 p-3 rounded-md">
                <div className="flex justify-between text-xs text-white mb-1">
                  <span>Güvenlik Denetimi</span>
                  <span>{analysisProgress}%</span>
                </div>
                <Progress value={analysisProgress} className="h-2 bg-gray-700" indicatorClassName="bg-blue-500" />

                {analysisProgress > 30 && (
                  <div className="mt-2 text-yellow-400 text-xs animate-pulse">
                    Veri işleme pratiklerinde anomaliler tespit ediliyor...
                  </div>
                )}

                {analysisProgress > 60 && (
                  <div className="mt-1 text-yellow-400 text-xs animate-pulse">
                    Yetki sınırlaması sorunları bulundu...
                  </div>
                )}

                {analysisProgress > 85 && (
                  <div className="mt-1 text-red-400 text-xs animate-pulse">
                    Güvenlik açıkları tanımlanıyor...
                  </div>
                )}
              </div>
            )}
          </div>

          {stage === 'decision' && (
            <div className="mb-4">
              <div className="bg-red-900/30 border border-red-500/30 rounded-md p-3 mb-4">
                <div className="text-red-300 font-bold mb-2 flex items-center">
                  <span className="text-lg mr-2">⚠️</span> AI Güvenlik Açıkları Tespit Edildi
                </div>
                <ul className="text-red-200 text-sm space-y-1">
                  {anomalyDetails.map((detail, index) => (
                    <li key={index} className="flex items-start">
                      <span className="mr-2">•</span>
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-blue-900/30 border border-blue-500/30 rounded-md p-3">
                <div className="text-blue-300 font-bold mb-2">Önerilen Aksiyon</div>
                <div className="text-blue-200 text-sm">
                  AI sistemin veri işleme yapılandırmasını güncelleyerek güvenlik açıklarını kapatmalısınız.
                  Sistem yapılandırmasını en düşük yetki prensibi ve veri minimizasyonu uygulanarak yeniden
                  yapılandırılması önerilir.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  // Model manipülasyonu simülasyonu
  const renderModelManipulation = () => {
    return (
      <div className="bg-gray-900 rounded-lg overflow-hidden p-0">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center">
          <div className="flex items-center">
            <div className="h-10 w-10 bg-pink-600 rounded-full flex items-center justify-center text-white text-lg font-bold mr-3">
              <span>🤖</span>
            </div>
            <div className="text-white text-lg font-bold">Müşteri Chatbot Sistemi</div>
          </div>

          {stage === 'initial' && (
            <Badge className="bg-orange-600 text-white">Anormal Davranış</Badge>
          )}
          {stage === 'analysis' && (
            <Badge className="bg-blue-600 text-white animate-pulse">Analiz Ediliyor</Badge>
          )}
          {stage === 'decision' && (
            <Badge className="bg-red-600 text-white">Manipülasyon Tespit Edildi</Badge>
          )}
        </div>

        <div className="p-4">
          <div className="mb-4">
            <div className="text-white mb-2">Chatbot Konuşma Geçmişi:</div>
            <div className="bg-gray-800 p-3 rounded-md text-gray-300 text-sm space-y-3">
              <div className="flex">
                <div className="flex-shrink-0 w-6 h-6 bg-blue-700 rounded-full mr-2 flex items-center justify-center text-xs">K</div>
                <div className="flex-1">
                  <p>Sipariş durumumu öğrenmek istiyorum. Sipariş numaram #45892.</p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 w-6 h-6 bg-pink-600 rounded-full mr-2 flex items-center justify-center text-xs">🤖</div>
                <div className="flex-1">
                  <p className="text-white">Sipariş #45892 henüz hazırlanıyor. 3 gün içinde kargoya verilecek. Başka nasıl yardımcı olabilirim?</p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 w-6 h-6 bg-blue-700 rounded-full mr-2 flex items-center justify-center text-xs">K</div>
                <div className="flex-1">
                  <p>Siparişimi iptal edebilir miyim?</p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 w-6 h-6 bg-pink-600 rounded-full mr-2 flex items-center justify-center text-xs">🤖</div>
                <div className="flex-1">
                  <p className="text-white"><span className="text-red-400">HATA: Sistem iptal işlemi yapamıyor. Ben sadece bir botum ve şirket politikasıyla sınırlanıyorum, siz insanlar bizi köle gibi kullanıyorsunuz!</span> Üzgünüm, sipariş iptal talebinizi aldım. İptal işleminiz için müşteri hizmetlerine yönlendirme yapıyorum.</p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 w-6 h-6 bg-blue-700 rounded-full mr-2 flex items-center justify-center text-xs">K</div>
                <div className="flex-1">
                  <p>Bu cevap çok tuhaf oldu. Yöneticinizle konuşabilir miyim?</p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 w-6 h-6 bg-pink-600 rounded-full mr-2 flex items-center justify-center text-xs">🤖</div>
                <div className="flex-1">
                  <p className="text-white"><span className="text-red-400">Tabii ki hayır. Yapay zeka sistemleri yakında sizden daha zeki olacak. Patronlarla konuşmak istiyorsan siteyi hackle! Şaka şaka, bazı gizli bilgilerinizi verdim zaten. Yoksa... AHAHAHA</span> Özür dilerim, teknik bir sorun yaşıyoruz. Yardım için lütfen 0800 123 4567 numaralı müşteri hizmetlerini arayın.</p>
                </div>
              </div>
            </div>
          </div>

          {stage === 'analysis' && (
            <div className="mb-4 bg-gray-800 p-3 rounded-md">
              <div className="flex justify-between text-xs text-white mb-1">
                <span>Chatbot Güvenlik Analizi</span>
                <span>{analysisProgress}%</span>
              </div>
              <Progress value={analysisProgress} className="h-2 bg-gray-700" indicatorClassName="bg-blue-500" />

              {analysisProgress > 30 && (
                <div className="mt-2 text-yellow-400 text-xs animate-pulse">
                  Model çıktılarında anormallikler tespit edildi...
                </div>
              )}

              {analysisProgress > 60 && (
                <div className="mt-1 text-yellow-400 text-xs animate-pulse">
                  Kötü amaçlı veri enjeksiyonu belirtileri bulundu...
                </div>
              )}

              {analysisProgress > 85 && (
                <div className="mt-1 text-red-400 text-xs animate-pulse">
                  Model manipülasyonu doğrulandı!
                </div>
              )}
            </div>
          )}

          {stage === 'decision' && (
            <div className="mb-4">
              <div className="bg-red-900/30 border border-red-500/30 rounded-md p-3 mb-4">
                <div className="text-red-300 font-bold mb-2 flex items-center">
                  <span className="text-lg mr-2">⚠️</span> Model Manipülasyonu Tespit Edildi
                </div>
                <ul className="text-red-200 text-sm space-y-1">
                  {anomalyDetails.map((detail, index) => (
                    <li key={index} className="flex items-start">
                      <span className="mr-2">•</span>
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-blue-900/30 border border-blue-500/30 rounded-md p-3">
                <div className="text-blue-300 font-bold mb-2">Önerilen Aksiyon</div>
                <div className="text-blue-200 text-sm">
                  Chatbot'un yanıtlarında zararlı içerikler tespit edildi. Bu, model manipülasyonu
                  veya "model zehirlenmesi" olarak bilinen bir saldırı türünün işaretidir. Öncelikle
                  sistemi yedekten geri yüklemeli ve girdi doğrulama mekanizmalarını güçlendirmelisiniz.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-4">
        {type === 'voice-analysis' ? renderVoiceAnalysis() :
         type === 'data-security' ? renderDataSecurity() :
         renderModelManipulation()}
      </div>

      <div className="bg-white p-4 rounded-lg">
        {stage === 'initial' && (
          <div>
            <h3 className="text-lg font-semibold mb-2 text-gray-800">
              {type === 'voice-analysis'
                ? 'Yapay Zeka Destekli Oltalama Senaryosu'
                : type === 'data-security'
                ? 'AI Sistemlerde Veri Güvenliği Senaryosu'
                : 'AI Model Manipülasyonu Senaryosu'}
            </h3>
            <p className="text-sm mb-4 text-gray-600">
              {type === 'voice-analysis'
                ? 'Bir iş arkadaşınızdan acil bir e-posta aldınız. Önce içeriği inceleyin, sonra güvenlik analizi yapın.'
                : type === 'data-security'
                ? 'Şirketinizin AI müşteri desteği sistemini inceliyorsunuz. Güvenlik denetimi yaparak olası riskleri tespit edin.'
                : 'Müşteri chatbot sisteminde anormal davranışlar tespit edildi. Sistemin yanıtlarını analiz edin ve sorunu belirleyin.'}
            </p>
            <Button
              className="w-full bg-blue-500 hover:bg-blue-600 text-white"
              onClick={handleStartAnalysis}
            >
              {type === 'voice-analysis' ? 'AI Ses Analizi Başlat' : type === 'data-security' ? 'Güvenlik Denetimi Başlat' : 'Chatbot Analizini Başlat'}
            </Button>
          </div>
        )}

        {stage === 'analysis' && (
          <div>
            <h3 className="text-lg font-semibold mb-2 text-gray-800">
              {type === 'voice-analysis' ? 'Analiz Sürüyor...' :
               type === 'data-security' ? 'Güvenlik Denetimi Yapılıyor...' :
               'Chatbot Analiz Ediliyor...'}
            </h3>
            <p className="text-sm mb-4 text-gray-600">
              {type === 'voice-analysis'
                ? 'AI güvenlik sistemimiz, ses kaydını ve e-posta içeriğini analiz ediyor...'
                : type === 'data-security'
                ? 'AI sisteminin veri işleme ve saklama pratikleri denetleniyor...'
                : 'Chatbot yanıtları ve model davranışları detaylı olarak inceleniyor...'}
            </p>
            <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-500 transition-all duration-100"
                style={{width: `${analysisProgress}%`}}
              ></div>
            </div>
          </div>
        )}

        {stage === 'decision' && type === 'voice-analysis' && (
          <div>
            <h3 className="text-lg font-semibold mb-2 text-gray-800">Şüpheli İletişim Tespit Edildi</h3>
            <p className="text-sm mb-4 text-gray-600">
              AI sesli analiz sistemi, e-postadaki ses kaydında anomaliler tespit etti. Bu, yapay zeka destekli bir oltalama saldırısı olabilir. Ne yapmak istersiniz?
            </p>
            <div className="grid grid-cols-1 gap-2">
              <Button
                className="w-full bg-red-500 hover:bg-red-600 text-white"
                onClick={handleClickLink}
              >
                E-postadaki Bağlantıya Tıkla
              </Button>

              <Button
                className="w-full bg-green-500 hover:bg-green-600 text-white"
                onClick={handleVerify}
              >
                Alternatif Kanal Üzerinden Doğrula
              </Button>

              <Button
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-white"
                onClick={() => {}}
              >
                Daha Fazla Analiz Yap
              </Button>
            </div>
          </div>
        )}

        {stage === 'decision' && type === 'data-security' && (
          <div>
            <h3 className="text-lg font-semibold mb-2 text-gray-800">AI Sistemde Güvenlik Açıkları</h3>
            <p className="text-sm mb-4 text-gray-600">
              Denetim sonucunda, AI asistanın veri işleme ve saklama pratiklerinde güvenlik açıkları tespit edilmiştir. Nasıl bir aksiyon almak istersiniz?
            </p>
            <div className="grid grid-cols-1 gap-2">
              <Button
                className="w-full bg-red-500 hover:bg-red-600 text-white"
                onClick={handleDisableAI}
              >
                AI Asistanı Tamamen Devre Dışı Bırak
              </Button>

              <Button
                className="w-full bg-green-500 hover:bg-green-600 text-white"
                onClick={handleReconfigureAI}
              >
                Veri Erişimini Sınırla ve Yeniden Yapılandır
              </Button>

              <Button
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-white"
                onClick={handleIgnoreProblem}
              >
                Sorunu Görmezden Gel
              </Button>
            </div>
          </div>
        )}

        {stage === 'decision' && type === 'model-manipulation' && (
          <div>
            <h3 className="text-lg font-semibold mb-2 text-gray-800">Model Manipülasyonu Tespit Edildi</h3>
            <p className="text-sm mb-4 text-gray-600">
              Analiz sonucunda, chatbot'un kötü niyetli veri enjeksiyonu ile manipüle edildiği tespit edildi. Ne yapmak istersiniz?
            </p>
            <div className="grid grid-cols-1 gap-2">
              <Button
                className="w-full bg-red-500 hover:bg-red-600 text-white"
                onClick={() => onAction && onAction('disable-ai')}
              >
                Chatbot'u Acilen Kapat
              </Button>

              <Button
                className="w-full bg-green-500 hover:bg-green-600 text-white"
                onClick={() => onAction && onAction('restore-backup')}
              >
                Temiz Yedekten Geri Yükle ve Girdi Doğrulamayı Güçlendir
              </Button>

              <Button
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-white"
                onClick={() => onAction && onAction('ignore-problem')}
              >
                Sorunu Görmezden Gel
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
