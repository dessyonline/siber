"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { CyberGlitchText } from "@/components/ui/cyber-effects";

interface NetworkDevice {
  id: string;
  name: string;
  type: "server" | "computer" | "router" | "firewall" | "switch";
  icon: string;
  secure: boolean;
  vulnerabilities: string[];
  position: { x: number; y: number };
}

interface NetworkAttack {
  id: string;
  name: string;
  description: string;
  targetType: "server" | "computer" | "router" | "firewall" | "switch" | "all";
  severity: "low" | "medium" | "high" | "critical";
  color: string;
  preventionMeasures: string[];
}

export function NetworkSimulation() {
  const [devices, setDevices] = useState<NetworkDevice[]>([
    {
      id: "server1",
      name: "Web Sunucusu",
      type: "server",
      icon: "🖥️",
      secure: false,
      vulnerabilities: ["Güncel olmayan yazılım", "Zayıf şifre politikası"],
      position: { x: 50, y: 30 }
    },
    {
      id: "router1",
      name: "Ana Yönlendirici",
      type: "router",
      icon: "📡",
      secure: false,
      vulnerabilities: ["Varsayılan şifre", "Güvensiz yönetim arayüzü"],
      position: { x: 50, y: 70 }
    },
    {
      id: "firewall1",
      name: "Güvenlik Duvarı",
      type: "firewall",
      icon: "🛡️",
      secure: true,
      vulnerabilities: [],
      position: { x: 30, y: 50 }
    },
    {
      id: "computer1",
      name: "İş İstasyonu 1",
      type: "computer",
      icon: "💻",
      secure: false,
      vulnerabilities: ["Antivirüs yok", "Yama eksikliği"],
      position: { x: 70, y: 40 }
    },
    {
      id: "computer2",
      name: "İş İstasyonu 2",
      type: "computer",
      icon: "💻",
      secure: false,
      vulnerabilities: ["Şüpheli uygulama yüklü"],
      position: { x: 70, y: 60 }
    }
  ]);

  const [attacks, setAttacks] = useState<NetworkAttack[]>([
    {
      id: "ddos",
      name: "DDoS Saldırısı",
      description: "Hizmet engelleme saldırısı, sunucunun kaynaklarını tüketerek hizmet vermesini engeller.",
      targetType: "server",
      severity: "high",
      color: "bg-red-500",
      preventionMeasures: [
        "DDoS koruma hizmeti kullanın",
        "Trafik filtreleme sistemleri kurun",
        "Yük dengeleme uygulayın"
      ]
    },
    {
      id: "mitm",
      name: "Ortadaki Adam Saldırısı",
      description: "Saldırgan, iki taraf arasındaki iletişimi gizlice dinler ve veri çalabilir.",
      targetType: "router",
      severity: "critical",
      color: "bg-purple-500",
      preventionMeasures: [
        "HTTPS kullanın",
        "Şifreli bağlantı protokolleri (SSH, SSL/TLS) kullanın",
        "Güvenli ağ doğrulaması yapın"
      ]
    },
    {
      id: "brute",
      name: "Kaba Kuvvet Saldırısı",
      description: "Sisteme erişmek için tüm olası şifre kombinasyonları denenir.",
      targetType: "all",
      severity: "medium",
      color: "bg-yellow-500",
      preventionMeasures: [
        "Güçlü şifre politikaları uygulayın",
        "Giriş denemelerini sınırlayın",
        "İki faktörlü kimlik doğrulama kullanın"
      ]
    },
    {
      id: "ransomware",
      name: "Fidye Yazılımı",
      description: "Bulaştığında, verileri şifreler ve kilitler. Erişim için fidye talep edilir.",
      targetType: "computer",
      severity: "critical",
      color: "bg-red-600",
      preventionMeasures: [
        "Düzenli yedekleme yapın",
        "Yazılımları güncel tutun",
        "Bilinmeyen dosya eklerini açmayın",
        "Güvenlik yazılımı kullanın"
      ]
    }
  ]);

  const [activeAttack, setActiveAttack] = useState<NetworkAttack | null>(null);
  const [targetDevice, setTargetDevice] = useState<NetworkDevice | null>(null);
  const [attackProgress, setAttackProgress] = useState<number>(0);
  const [attackSuccessful, setAttackSuccessful] = useState<boolean | null>(null);
  const [alertMessage, setAlertMessage] = useState<string>("");
  const [defenseSelected, setDefenseSelected] = useState<boolean>(false);
  const [networkStatus, setNetworkStatus] = useState<"normal" | "under-attack" | "compromised" | "secured">("normal");

  useEffect(() => {
    if (activeAttack && targetDevice && attackProgress > 0 && attackProgress < 100) {
      const timer = setTimeout(() => {
        setAttackProgress(prev => {
          // Savunma seçilirse, saldırı yavaşlar
          const increment = defenseSelected ? 3 : 10;
          return Math.min(prev + increment, 100);
        });
      }, 200);

      return () => clearTimeout(timer);
    }
  }, [activeAttack, targetDevice, attackProgress, defenseSelected]);

  useEffect(() => {
    if (attackProgress === 100) {
      if (defenseSelected) {
        setAttackSuccessful(false);
        setAlertMessage("Tebrikler! Saldırıyı başarıyla engellediniz.");
        setNetworkStatus("secured");
      } else {
        setAttackSuccessful(true);
        setAlertMessage(`Uyarı: ${targetDevice?.name} cihazı ${activeAttack?.name} nedeniyle ele geçirildi!`);
        setNetworkStatus("compromised");
      }
    }
  }, [attackProgress, defenseSelected, activeAttack, targetDevice]);

  const startAttack = (attack: NetworkAttack, device: NetworkDevice) => {
    setActiveAttack(attack);
    setTargetDevice(device);
    setAttackProgress(1);
    setAttackSuccessful(null);
    setDefenseSelected(false);
    setNetworkStatus("under-attack");
    setAlertMessage(`Dikkat: ${device.name} üzerinde ${attack.name} saldırısı tespit edildi!`);
  };

  const selectDefense = () => {
    setDefenseSelected(true);
  };

  const resetSimulation = () => {
    setActiveAttack(null);
    setTargetDevice(null);
    setAttackProgress(0);
    setAttackSuccessful(null);
    setDefenseSelected(false);
    setNetworkStatus("normal");
    setAlertMessage("");
  };

  const getDeviceStatusColor = (device: NetworkDevice) => {
    if (targetDevice && targetDevice.id === device.id) {
      if (networkStatus === "under-attack") return "border-yellow-500 animate-pulse";
      if (networkStatus === "compromised") return "border-red-500";
      if (networkStatus === "secured") return "border-green-500";
    }
    return device.secure ? "border-green-400/50" : "border-yellow-400/30";
  };

  return (
    <Card className="border-primary/30 bg-black text-white">
      <CardHeader className="p-4 border-b border-primary/20">
        <div className="flex justify-between items-center">
          <CardTitle className="text-primary text-xl">
            <CyberGlitchText intensity="low">Ağ Güvenliği Simülasyonu</CyberGlitchText>
          </CardTitle>
          <Badge variant="outline" className="border-primary/50">
            {networkStatus === "normal" && "Durum: Normal"}
            {networkStatus === "under-attack" && "Durum: Saldırı Altında!"}
            {networkStatus === "compromised" && "Durum: Güvenlik İhlali!"}
            {networkStatus === "secured" && "Durum: Saldırı Engellendi"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        {/* Alert mesajı */}
        {alertMessage && (
          <Alert className={`mb-4 ${attackSuccessful === true ? 'bg-red-900/40 border-red-500' : attackSuccessful === false ? 'bg-green-900/40 border-green-500' : 'bg-yellow-900/40 border-yellow-500'}`}>
            <AlertDescription>{alertMessage}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Ağ topolojisi görselleştirme */}
          <div className="col-span-2 bg-gray-900/50 rounded-lg border border-gray-800 p-4 relative h-[300px]">
            {/* Cihazlar arası bağlantılar (basit çizgiler) */}
            <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
              {/* Router-Server bağlantısı */}
              <line
                x1={`${devices[1].position.x}%`}
                y1={`${devices[1].position.y}%`}
                x2={`${devices[0].position.x}%`}
                y2={`${devices[0].position.y}%`}
                stroke={networkStatus === "compromised" ? "#ef4444" : "#4ade80"}
                strokeWidth="2"
                strokeDasharray={networkStatus === "under-attack" ? "5,5" : ""}
              />

              {/* Router-Computers bağlantısı */}
              <line
                x1={`${devices[1].position.x}%`}
                y1={`${devices[1].position.y}%`}
                x2={`${devices[3].position.x}%`}
                y2={`${devices[3].position.y}%`}
                stroke={networkStatus === "compromised" ? "#ef4444" : "#4ade80"}
                strokeWidth="2"
                strokeDasharray={networkStatus === "under-attack" ? "5,5" : ""}
              />
              <line
                x1={`${devices[1].position.x}%`}
                y1={`${devices[1].position.y}%`}
                x2={`${devices[4].position.x}%`}
                y2={`${devices[4].position.y}%`}
                stroke={networkStatus === "compromised" ? "#ef4444" : "#4ade80"}
                strokeWidth="2"
                strokeDasharray={networkStatus === "under-attack" ? "5,5" : ""}
              />

              {/* Firewall-Router bağlantısı */}
              <line
                x1={`${devices[2].position.x}%`}
                y1={`${devices[2].position.y}%`}
                x2={`${devices[1].position.x}%`}
                y2={`${devices[1].position.y}%`}
                stroke="#4ade80"
                strokeWidth="2"
              />
            </svg>

            {/* Cihazlar */}
            {devices.map(device => (
              <div
                key={device.id}
                className={`absolute p-2 bg-gray-800 rounded-lg cursor-pointer border ${getDeviceStatusColor(device)}`}
                style={{
                  left: `${device.position.x}%`,
                  top: `${device.position.y}%`,
                  transform: 'translate(-50%, -50%)'
                }}
                onClick={() => {
                  if (activeAttack && !targetDevice) {
                    if (activeAttack.targetType === "all" || activeAttack.targetType === device.type) {
                      startAttack(activeAttack, device);
                    }
                  }
                }}
              >
                <div className="flex flex-col items-center">
                  <div className="text-2xl">{device.icon}</div>
                  <div className="text-xs mt-1">{device.name}</div>
                </div>
              </div>
            ))}

            {/* Aktif saldırı gösterimi */}
            {activeAttack && targetDevice && (
              <div
                className={`absolute ${activeAttack.color} rounded-full animate-ping opacity-50`}
                style={{
                  left: `${targetDevice.position.x}%`,
                  top: `${targetDevice.position.y}%`,
                  width: `${attackProgress}px`,
                  height: `${attackProgress}px`,
                  transform: 'translate(-50%, -50%)'
                }}
              />
            )}
          </div>

          {/* Saldırı ve savunma paneli */}
          <div className="bg-gray-900/50 rounded-lg border border-gray-800 p-4 flex flex-col">
            {!activeAttack && (
              <>
                <h3 className="text-primary font-semibold mb-2">Saldırı Simülasyonu Başlat</h3>
                <p className="text-sm text-gray-400 mb-4">Simülasyon için bir saldırı türü seçin:</p>
                <div className="space-y-2">
                  {attacks.map(attack => (
                    <button
                      key={attack.id}
                      className={`w-full text-left p-2 border rounded flex justify-between items-center hover:bg-gray-800 ${attack.color.replace('bg', 'border')}`}
                      onClick={() => setActiveAttack(attack)}
                    >
                      <span>{attack.name}</span>
                      <Badge variant="outline" className={`${attack.severity === 'critical' ? 'border-red-500 text-red-400' : attack.severity === 'high' ? 'border-orange-500 text-orange-400' : 'border-yellow-500 text-yellow-400'}`}>
                        {attack.severity === 'critical' ? 'Kritik' : attack.severity === 'high' ? 'Yüksek' : 'Orta'}
                      </Badge>
                    </button>
                  ))}
                </div>
              </>
            )}

            {activeAttack && !targetDevice && (
              <>
                <h3 className="text-primary font-semibold mb-2">{activeAttack.name}</h3>
                <p className="text-sm mb-4">{activeAttack.description}</p>
                <div className="bg-gray-800 p-2 rounded mb-4">
                  <p className="text-sm text-yellow-400">Hedef seçin: Ağ haritasında bir {activeAttack.targetType === 'all' ? 'cihaza' : activeAttack.targetType === 'server' ? 'sunucuya' : 'cihaza'} tıklayın</p>
                </div>
                <Button
                  variant="outline"
                  className="mt-auto border-primary/50 hover:border-primary/80"
                  onClick={() => setActiveAttack(null)}
                >
                  Farklı Saldırı Seç
                </Button>
              </>
            )}

            {activeAttack && targetDevice && (
              <>
                <h3 className="text-red-400 font-semibold mb-2">Saldırı Devam Ediyor!</h3>
                <p className="text-sm mb-2">
                  <span className="text-yellow-400">{targetDevice.name}</span> cihazına <span className="text-red-400">{activeAttack.name}</span> saldırısı gerçekleşiyor.
                </p>

                <div className="mb-4">
                  <div className="flex justify-between text-xs mb-1">
                    <span>Saldırı İlerlemesi</span>
                    <span>%{attackProgress}</span>
                  </div>
                  <Progress value={attackProgress} className="h-2" />
                </div>

                {!defenseSelected && attackSuccessful === null && (
                  <>
                    <h4 className="text-primary font-semibold mb-2">Savunma Önlemleri</h4>
                    <div className="space-y-2 mb-4">
                      {activeAttack.preventionMeasures.map((measure, idx) => (
                        <div key={idx} className="text-sm p-2 bg-gray-800 rounded">
                          {measure}
                        </div>
                      ))}
                    </div>
                    <Button
                      className="bg-green-700 hover:bg-green-800 w-full mb-2"
                      onClick={selectDefense}
                    >
                      Savunma Önlemlerini Uygula
                    </Button>
                  </>
                )}

                {defenseSelected && attackSuccessful === null && (
                  <div className="bg-green-900/30 border border-green-500 p-3 rounded my-4">
                    <p className="text-sm">Savunma önlemleri uygulanıyor...</p>
                  </div>
                )}

                {attackSuccessful !== null && (
                  <div className={`${attackSuccessful ? 'bg-red-900/30 border-red-500' : 'bg-green-900/30 border-green-500'} border p-3 rounded my-4`}>
                    <p className="font-semibold mb-1">{attackSuccessful ? 'Saldırı Başarılı!' : 'Saldırı Engellendi!'}</p>
                    <p className="text-sm">{attackSuccessful ? 'Güvenlik ihlali gerçekleşti.' : 'Savunma önlemleri başarıyla uygulandı.'}</p>
                  </div>
                )}

                <Button
                  variant="outline"
                  className="mt-auto border-primary/50 hover:border-primary/80"
                  onClick={resetSimulation}
                >
                  Simülasyonu Sıfırla
                </Button>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
