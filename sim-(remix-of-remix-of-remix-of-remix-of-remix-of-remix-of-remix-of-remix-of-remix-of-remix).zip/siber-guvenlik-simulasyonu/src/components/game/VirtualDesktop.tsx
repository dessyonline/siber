"use client";

import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CyberGlitchText } from "@/components/ui/cyber-effects";
import Image from "next/image";

interface DesktopFile {
  id: string;
  name: string;
  type: "folder" | "text" | "image" | "executable" | "email";
  icon: string;
  content?: string;
  imageSrc?: string;
  malicious?: boolean;
  children?: DesktopFile[];
}

interface DesktopNotification {
  id: string;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "update";
  action?: () => void;
  actionText?: string;
}

export function VirtualDesktop() {
  const [activeWindow, setActiveWindow] = useState<DesktopFile | null>(null);
  const [notifications, setNotifications] = useState<DesktopNotification[]>([]);
  const [taskbarItems, setTaskbarItems] = useState<string[]>([]);
  const [malwareDetected, setMalwareDetected] = useState(false);
  const [emailOpen, setEmailOpen] = useState(false);
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);

  // Sanal dosya sistemi
  const desktopItems: DesktopFile[] = [
    {
      id: "documents",
      name: "Belgelerim",
      type: "folder",
      icon: "📁",
      children: [
        {
          id: "report",
          name: "gizli_rapor.txt",
          type: "text",
          icon: "📄",
          content: "Bu rapor şirket içi gizli bilgiler içermektedir. Paylaşmayın!"
        },
        {
          id: "passwords",
          name: "şifreler.txt",
          type: "text",
          icon: "🔒",
          content: "Email: user@example.com / P@ssw0rd123\nBanka: 1234 / 9876"
        }
      ]
    },
    {
      id: "phishing-email",
      name: "Yeni Email",
      type: "email",
      icon: "✉️",
      content: "Sayın müşterimiz,\n\nBanka hesabınızla ilgili önemli bir güvenlik bildirimi almış bulunmaktayız. Hesap bilgilerinizi güncellemek için aşağıdaki bağlantıya tıklayınız.\n\nHesap Güncelleme\n\nEn içten dileklerimizle,\nFinans Bankası Güvenlik Ekibi"
    },
    {
      id: "update",
      name: "Yazılım Güncellemesi",
      type: "executable",
      icon: "🔄",
      malicious: false,
      content: "Yazılım güncellemesi kurulmaya hazır"
    },
    {
      id: "game",
      name: "FreeCryptoGame.exe",
      type: "executable",
      icon: "🎮",
      malicious: true,
      content: "Ücretsiz oyun kurulumu"
    },
    {
      id: "photos",
      name: "Resimlerim",
      type: "folder",
      icon: "🖼️",
      children: [
        {
          id: "photo1",
          name: "tatil.jpg",
          type: "image",
          icon: "🏖️",
          imageSrc: "https://same-assets.com/image_placeholder.png"
        }
      ]
    }
  ];

  // Bildirim oluşturan fonksiyon
  const createNotification = (notification: DesktopNotification) => {
    setNotifications(prev => [...prev, notification]);
    // Otomatik kapanma
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== notification.id));
    }, 5000);
  };

  // Bir dosyayı açma işlevi
  const openFile = (file: DesktopFile) => {
    setActiveWindow(file);

    if (!taskbarItems.includes(file.id)) {
      setTaskbarItems(prev => [...prev, file.id]);
    }

    // Kötü amaçlı dosya kontrolü
    if (file.malicious) {
      setTimeout(() => {
        setMalwareDetected(true);
        createNotification({
          id: `malware-${Date.now()}`,
          title: "Güvenlik Uyarısı!",
          message: "Sisteminizde kötü amaçlı yazılım tespit edildi!",
          type: "error"
        });
      }, 1000);
    }

    // Email açıldıysa
    if (file.type === "email") {
      setEmailOpen(true);
    }

    // Update açıldıysa
    if (file.id === "update") {
      setUpdateDialogOpen(true);
    }
  };

  // Dosyayı kapat
  const closeFile = (fileId: string) => {
    if (activeWindow?.id === fileId) {
      setActiveWindow(null);
    }
    setTaskbarItems(prev => prev.filter(id => id !== fileId));
  };

  // Phishing e-postasındaki bağlantıyı tıklama (kötü amaçlı eylem)
  const clickPhishingLink = () => {
    setEmailOpen(false);
    createNotification({
      id: `phish-${Date.now()}`,
      title: "Dikkat!",
      message: "Az önce bir phishing bağlantısına tıkladınız! Bu eylem kişisel bilgilerinizi tehlikeye atabilir.",
      type: "error"
    });
    setMalwareDetected(true);
  };

  // Güncelleme diyaloğuna yanıt verme
  const handleUpdateResponse = (install: boolean) => {
    setUpdateDialogOpen(false);

    if (install) {
      createNotification({
        id: `update-${Date.now()}`,
        title: "Güncelleme Başarılı",
        message: "Sistem güvenlik güncellemesi başarıyla kuruldu.",
        type: "info"
      });
    } else {
      createNotification({
        id: `update-${Date.now()}`,
        title: "Güncelleme Ertelendi",
        message: "Güvenlik güncellemesini ertelemek sisteminizi risk altında bırakabilir.",
        type: "warning"
      });
    }
  };

  // Dosya içeriğini gösteren fonksiyon
  const renderFileContent = (file: DesktopFile) => {
    switch (file.type) {
      case "text":
        return (
          <div className="p-4 font-mono text-sm bg-white text-black min-h-[200px] whitespace-pre-wrap">
            {file.content}
          </div>
        );
      case "image":
        return (
          <div className="p-2 bg-white flex justify-center">
            {file.imageSrc && (
              <Image
                src={file.imageSrc}
                alt={file.name}
                width={300}
                height={200}
                className="object-contain"
              />
            )}
          </div>
        );
      case "folder":
        return (
          <div className="p-4 bg-gray-100 text-black min-h-[200px]">
            <div className="grid grid-cols-3 gap-2">
              {file.children?.map((childFile) => (
                <div
                  key={childFile.id}
                  className="flex flex-col items-center p-2 hover:bg-blue-100 cursor-pointer rounded"
                  onClick={() => openFile(childFile)}
                >
                  <div className="text-2xl">{childFile.icon}</div>
                  <div className="text-xs text-center mt-1 truncate w-full">{childFile.name}</div>
                </div>
              ))}
            </div>
          </div>
        );
      case "email":
        return (
          <div className="bg-white text-black p-4 min-h-[200px]">
            <div className="border-b pb-2 mb-4">
              <div><strong>Konu:</strong> Acil: Banka Hesabınız Hakkında</div>
              <div><strong>Kimden:</strong> finans-bank-support@secure-bank-validation.com</div>
              <div><strong>Kime:</strong> customer@example.com</div>
            </div>
            <div className="whitespace-pre-wrap">
              {file.content}
              <div className="mt-4">
                <button
                  className="text-blue-600 underline"
                  onClick={clickPhishingLink}
                >
                  Hesap Bilgilerimi Güncelle
                </button>
              </div>
            </div>
          </div>
        );
      case "executable":
        return (
          <div className="bg-gray-800 text-white p-4 min-h-[200px] flex flex-col items-center justify-center">
            <div className="text-4xl mb-4">{file.icon}</div>
            <div className="text-center">{file.content}</div>
            {file.id === "update" && (
              <Button
                className="mt-4 bg-blue-500 hover:bg-blue-600"
                onClick={() => setUpdateDialogOpen(true)}
              >
                Şimdi Kur
              </Button>
            )}
            {file.id === "game" && (
              <Button
                className="mt-4 bg-red-500 hover:bg-red-600"
                onClick={() => {
                  setMalwareDetected(true);
                  createNotification({
                    id: `malware-game-${Date.now()}`,
                    title: "Tehlikeli Yazılım!",
                    message: "Bu uygulama bilgisayarınıza kötü amaçlı yazılım yüklemeye çalışıyor!",
                    type: "error"
                  });
                }}
              >
                Kurulumu Başlat
              </Button>
            )}
          </div>
        );
      default:
        return <div>Desteklenmeyen dosya türü</div>;
    }
  };

  return (
    <Card className="border-primary/30 bg-black text-white">
      <CardHeader className="p-4 border-b border-primary/20">
        <div className="flex justify-between items-center">
          <CardTitle className="text-primary text-xl">
            <CyberGlitchText intensity="low">Sanal Masaüstü</CyberGlitchText>
          </CardTitle>
          <Badge variant="outline" className="border-primary/50">CyberOS v1.0</Badge>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {/* Sanal masaüstü */}
        <div className="relative h-[500px] bg-gradient-to-br from-blue-950 to-indigo-900 p-4">
          {/* Masaüstü dosyaları */}
          <div className="grid grid-cols-4 gap-2 md:grid-cols-6">
            {desktopItems.map((item) => (
              <div
                key={item.id}
                className="flex flex-col items-center p-2 hover:bg-white/10 cursor-pointer rounded transition"
                onClick={() => openFile(item)}
              >
                <div className="text-3xl mb-1">{item.icon}</div>
                <div className="text-xs text-center text-white">{item.name}</div>
              </div>
            ))}
          </div>

          {/* Aktif pencere */}
          {activeWindow && (
            <div className="absolute inset-x-8 top-16 bottom-12 bg-gray-200 shadow-xl rounded overflow-hidden border border-gray-400">
              {/* Pencere başlığı */}
              <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-2 flex justify-between items-center">
                <div className="flex items-center">
                  <span className="mr-2">{activeWindow.icon}</span>
                  <span>{activeWindow.name}</span>
                </div>
                <button
                  className="w-6 h-6 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center text-white"
                  onClick={() => setActiveWindow(null)}
                >
                  ✕
                </button>
              </div>

              {/* Pencere içeriği */}
              {renderFileContent(activeWindow)}
            </div>
          )}

          {/* Görev çubuğu */}
          <div className="absolute left-0 right-0 bottom-0 h-10 bg-gray-900/80 border-t border-gray-700 flex items-center px-4">
            <div className="mr-4 text-2xl cursor-pointer">🏠</div>

            {/* Açık uygulamalar */}
            <div className="flex space-x-2">
              {taskbarItems.map(id => {
                const file = desktopItems.find(item => item.id === id) ||
                             desktopItems.flatMap(item => item.children || []).find(child => child?.id === id);

                if (!file) return null;

                return (
                  <div
                    key={file.id}
                    className={`flex items-center px-3 py-1 rounded ${activeWindow?.id === file.id ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'}`}
                    onClick={() => file.id === activeWindow?.id ? setActiveWindow(null) : openFile(file)}
                  >
                    <span className="mr-2">{file.icon}</span>
                    <span className="text-xs">{file.name}</span>
                  </div>
                );
              })}
            </div>

            <div className="ml-auto text-sm text-white/80">15:30</div>
          </div>

          {/* Bildirimler */}
          <div className="absolute top-2 right-2 w-72 space-y-2">
            {notifications.map(notification => (
              <Alert
                key={notification.id}
                className={`
                  shadow-lg text-white
                  ${notification.type === 'info' ? 'bg-blue-600/90' : ''}
                  ${notification.type === 'warning' ? 'bg-yellow-600/90' : ''}
                  ${notification.type === 'error' ? 'bg-red-600/90' : ''}
                  ${notification.type === 'update' ? 'bg-green-600/90' : ''}
                `}
              >
                <div className="font-semibold">{notification.title}</div>
                <AlertDescription>
                  {notification.message}
                  {notification.action && (
                    <Button
                      className="mt-2 w-full"
                      size="sm"
                      onClick={notification.action}
                    >
                      {notification.actionText}
                    </Button>
                  )}
                </AlertDescription>
              </Alert>
            ))}
          </div>

          {/* Malware tespit uyarısı */}
          {malwareDetected && (
            <div className="absolute inset-0 bg-red-900/80 flex items-center justify-center z-50">
              <div className="bg-black/90 border-2 border-red-500 p-6 rounded-lg max-w-md text-center">
                <div className="text-4xl text-red-500 mb-4">⚠️</div>
                <h3 className="text-xl font-bold text-red-400 mb-2">
                  <CyberGlitchText intensity="medium">GÜVENLİK UYARISI!</CyberGlitchText>
                </h3>
                <p className="mb-4">Sisteminizde kötü amaçlı yazılım tespit edildi! Verileriniz risk altında olabilir.</p>
                <Button
                  className="bg-red-600 hover:bg-red-700"
                  onClick={() => setMalwareDetected(false)}
                >
                  Taramayı Başlat
                </Button>
              </div>
            </div>
          )}
        </div>
      </CardContent>

      {/* Güncelleme diyaloğu */}
      <Dialog open={updateDialogOpen} onOpenChange={setUpdateDialogOpen}>
        <DialogContent className="bg-gray-900 border-blue-500">
          <DialogHeader>
            <DialogTitle className="text-blue-400">Sistem Güncellemesi</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>Önemli güvenlik güncellemeleri kurulmaya hazır. Şimdi kurmak ister misiniz?</p>
            <p className="text-sm text-gray-400 mt-2">Bu güncelleme kritik güvenlik açıklarını kapatır ve sisteminizi korur.</p>
          </div>
          <div className="flex space-x-4 justify-end">
            <Button
              variant="outline"
              onClick={() => handleUpdateResponse(false)}
            >
              Daha Sonra
            </Button>
            <Button
              className="bg-blue-600"
              onClick={() => handleUpdateResponse(true)}
            >
              Şimdi Kur
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
