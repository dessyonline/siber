"use client";

import { useState, useEffect } from "react";
import { useGameStore, type Achievement } from "@/store/gameStore";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { motion, AnimatePresence } from "framer-motion";

export function Achievements() {
  const { achievements } = useGameStore();
  const [showUnlocked, setShowUnlocked] = useState(true);
  const [newlyUnlocked, setNewlyUnlocked] = useState<string[]>([]);
  const [unlockAnimations, setUnlockAnimations] = useState<Record<string, boolean>>({});

  // Önceki başarı durumlarını izleme
  const [prevAchievements, setPrevAchievements] = useState<Achievement[]>([]);

  // Başarıları kilitleme durumuna göre filtrele
  const filteredAchievements = showUnlocked
    ? achievements.filter(a => a.unlocked)
    : achievements;

  // Tamamlanan başarıların yüzdesi
  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalCount = achievements.length;
  const completionPercentage = Math.round((unlockedCount / totalCount) * 100);

  // Başarı kategorilerini tanımla
  const achievementCategories = {
    gameplay: ['first-game', 'perfectionist', 'speed-demon'],
    progress: ['level-5', 'category-master', 'all-categories'],
    security: ['low-risk'],
  };

  // Kategori başlıklarını tanımla
  const categoryTitles = {
    gameplay: 'Oyun İlerleme',
    progress: 'Seviye & Gelişim',
    security: 'Güvenlik Uzmanı',
  };

  // Yeni açılan başarıları takip et
  useEffect(() => {
    if (prevAchievements.length > 0) {
      const newUnlocked = achievements
        .filter(a => a.unlocked)
        .filter(a => !prevAchievements.find(pa => pa.id === a.id && pa.unlocked))
        .map(a => a.id);

      if (newUnlocked.length > 0) {
        setNewlyUnlocked(newUnlocked);

        // Animasyon için bayrak ayarla
        const animations: Record<string, boolean> = {};
        newUnlocked.forEach(id => {
          animations[id] = true;
        });

        setUnlockAnimations(animations);

        // Animasyonu 5 saniye sonra temizle
        setTimeout(() => {
          setUnlockAnimations({});
        }, 5000);
      }
    }

    setPrevAchievements(achievements);
  }, [achievements, prevAchievements]);

  // Kategori bazlı başarıları grupla ve göster
  const renderAchievementsByCategory = () => {
    return Object.entries(categoryTitles).map(([categoryKey, title]) => {
      const categoryAchievements = filteredAchievements.filter(a =>
        achievementCategories[categoryKey as keyof typeof achievementCategories].includes(a.id)
      );

      if (categoryAchievements.length === 0 && showUnlocked) return null;

      const totalInCategory = achievements.filter(a =>
        achievementCategories[categoryKey as keyof typeof achievementCategories].includes(a.id)
      ).length;

      const unlockedInCategory = achievements.filter(a =>
        achievementCategories[categoryKey as keyof typeof achievementCategories].includes(a.id) && a.unlocked
      ).length;

      const categoryProgress = (unlockedInCategory / totalInCategory) * 100;

      return (
        <div key={categoryKey} className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-primary/80">{title}</h3>
            <span className="text-xs text-gray-400">{unlockedInCategory}/{totalInCategory} Tamamlandı</span>
          </div>

          <Progress
            value={categoryProgress}
            className="h-1 mb-3"
            indicatorClassName={`bg-gradient-to-r ${
              categoryKey === 'gameplay' ? 'from-blue-500 to-cyan-500' :
              categoryKey === 'progress' ? 'from-green-500 to-emerald-500' :
              'from-purple-500 to-pink-500'
            }`}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {filteredAchievements
              .filter(a => achievementCategories[categoryKey as keyof typeof achievementCategories].includes(a.id))
              .map((achievement) => (
                <motion.div
                  key={achievement.id}
                  className={`
                    border ${achievement.unlocked ? 'border-green-600/30' : 'border-gray-700'}
                    rounded-md p-3 flex items-start gap-3 relative overflow-hidden
                    ${achievement.unlocked ? 'bg-green-900/10' : 'bg-gray-900/30 opacity-80'}
                    ${unlockAnimations[achievement.id] ? 'ring-2 ring-green-500/50' : ''}
                  `}
                  animate={unlockAnimations[achievement.id] ? {
                    scale: [1, 1.05, 1],
                    boxShadow: ['0 0 0 rgba(0,0,0,0)', '0 0 20px rgba(74,222,128,0.5)', '0 0 0 rgba(0,0,0,0)']
                  } : {}}
                  transition={{ duration: 1.5, repeat: 2 }}
                >
                  {unlockAnimations[achievement.id] && (
                    <motion.div
                      className="absolute inset-0 bg-green-500/20"
                      animate={{ opacity: [1, 0] }}
                      transition={{ duration: 1.5, repeat: 2 }}
                    />
                  )}

                  <div className={`text-2xl h-10 w-10 flex items-center justify-center rounded-full ${
                    achievement.unlocked ? 'bg-green-900/30' : 'bg-gray-800/50'
                  }`}>
                    {achievement.icon}
                  </div>

                  <div>
                    <h3 className={`font-medium ${achievement.unlocked ? 'text-green-400' : 'text-gray-400'}`}>
                      {achievement.title}
                      {newlyUnlocked.includes(achievement.id) && (
                        <Badge className="ml-2 bg-green-900/50 text-green-400 animate-pulse">Yeni!</Badge>
                      )}
                    </h3>
                    <p className="text-xs text-gray-400 mt-1">{achievement.description}</p>
                    {achievement.unlocked && achievement.unlockedAt && (
                      <div className="text-xs text-green-400/80 mt-1">
                        Kazanıldı: {achievement.unlockedAt.toLocaleDateString('tr-TR')}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
          </div>
        </div>
      );
    });
  };

  // Hiç başarı kazanılmamışsa
  if (achievements.filter(a => a.unlocked).length === 0 && showUnlocked) {
    return (
      <Card className="bg-black/30 border border-primary/20 p-4 mb-4">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg text-primary">Başarılar</CardTitle>
            <Badge className="bg-primary/20 text-primary">{completionPercentage}% Tamamlandı</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-6 px-2 space-y-3">
            <div className="text-4xl mb-3">🏆</div>
            <p className="text-center text-gray-400 text-sm">
              Henüz hiç başarı rozeti kazanmadınız. Simülasyonu tamamlayarak rozetler kazanabilirsiniz.
            </p>
            <button
              onClick={() => setShowUnlocked(false)}
              className="text-primary text-sm hover:underline mt-2"
            >
              Tüm Başarıları Göster
            </button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-black/30 border border-primary/20 p-4 mb-4">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg text-primary">Başarılar</CardTitle>
          <div className="flex items-center gap-2">
            <Badge className="bg-primary/20 text-primary">
              {unlockedCount}/{totalCount} Tamamlandı
            </Badge>
            <button
              onClick={() => setShowUnlocked(!showUnlocked)}
              className="text-xs text-primary hover:underline"
            >
              {showUnlocked ? 'Tümünü Göster' : 'Sadece Kazanılanlar'}
            </button>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {/* Genel ilerleme çubuğu */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-1 text-xs">
            <span className="text-gray-400">Genel İlerleme</span>
            <span className="text-primary font-medium">{completionPercentage}%</span>
          </div>
          <Progress
            value={completionPercentage}
            className="h-2"
            indicatorClassName="bg-gradient-to-r from-blue-600 via-purple-500 to-pink-500"
          />
        </div>

        {/* Kategori bazlı başarılar */}
        {renderAchievementsByCategory()}

        {/* Diğer başarılar */}
        <div className="mt-4">
          <h3 className="text-sm font-medium text-primary/80 mb-2">Diğer Başarılar</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {filteredAchievements
              .filter(a => !Object.values(achievementCategories).flat().includes(a.id))
              .map((achievement) => (
                <motion.div
                  key={achievement.id}
                  className={`
                    border ${achievement.unlocked ? 'border-green-600/30' : 'border-gray-700'}
                    rounded-md p-3 flex items-start gap-3 relative overflow-hidden
                    ${achievement.unlocked ? 'bg-green-900/10' : 'bg-gray-900/30 opacity-80'}
                    ${unlockAnimations[achievement.id] ? 'ring-2 ring-green-500/50' : ''}
                  `}
                  animate={unlockAnimations[achievement.id] ? {
                    scale: [1, 1.05, 1],
                    boxShadow: ['0 0 0 rgba(0,0,0,0)', '0 0 20px rgba(74,222,128,0.5)', '0 0 0 rgba(0,0,0,0)']
                  } : {}}
                  transition={{ duration: 1.5, repeat: 2 }}
                >
                  {unlockAnimations[achievement.id] && (
                    <motion.div
                      className="absolute inset-0 bg-green-500/20"
                      animate={{ opacity: [1, 0] }}
                      transition={{ duration: 1.5, repeat: 2 }}
                    />
                  )}

                  <div className={`text-2xl h-10 w-10 flex items-center justify-center rounded-full ${
                    achievement.unlocked ? 'bg-green-900/30' : 'bg-gray-800/50'
                  }`}>
                    {achievement.icon}
                  </div>

                  <div>
                    <h3 className={`font-medium ${achievement.unlocked ? 'text-green-400' : 'text-gray-400'}`}>
                      {achievement.title}
                      {newlyUnlocked.includes(achievement.id) && (
                        <Badge className="ml-2 bg-green-900/50 text-green-400 animate-pulse">Yeni!</Badge>
                      )}
                    </h3>
                    <p className="text-xs text-gray-400 mt-1">{achievement.description}</p>
                    {achievement.unlocked && achievement.unlockedAt && (
                      <div className="text-xs text-green-400/80 mt-1">
                        Kazanıldı: {achievement.unlockedAt.toLocaleDateString('tr-TR')}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
          </div>
        </div>

        {achievements.filter(a => a.unlocked).length === 0 && !showUnlocked && (
          <p className="text-center text-sm text-gray-400 mt-3">
            Simülasyonu tamamlayarak ve farklı zorluklardaki senaryolarda başarı göstererek bu rozetleri kazanabilirsiniz.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
