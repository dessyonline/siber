"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CyberGlitchText, CyberContainer, HackerTerminal } from "@/components/ui/cyber-effects";
import { getAllCategories, getTermById, getTermsByCategory, searchTerms, type SecurityTerm, type TermCategory } from "@/lib/cybersecurityTerms";
import Image from "next/image";

interface CybersecurityDictionaryProps {
  onClose: () => void;
}

export function CybersecurityDictionary({ onClose }: CybersecurityDictionaryProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<TermCategory | "all">("all");
  const [filteredTerms, setFilteredTerms] = useState<SecurityTerm[]>([]);
  const [selectedTerm, setSelectedTerm] = useState<SecurityTerm | null>(null);
  const [categories, setCategories] = useState<TermCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Kategorileri ve terimleri yükle
  useEffect(() => {
    // Tüm kategorileri getir
    setCategories(getAllCategories());

    // Varsayılan terim listesini yükle
    handleSearch();

    // Yükleme animasyonu için kısa bir gecikme
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 800);

    return () => clearTimeout(timer);
  }, []);

  // Arama ve filtreleme fonksiyonu
  const handleSearch = () => {
    let results = searchQuery.trim()
      ? searchTerms(searchQuery)
      : [];

    if (searchQuery.trim() === "") {
      results = selectedCategory === "all"
        ? getAllCategories().flatMap(cat => getTermsByCategory(cat))
        : getTermsByCategory(selectedCategory as TermCategory);
    } else if (selectedCategory !== "all") {
      results = results.filter(term => term.category === selectedCategory);
    }

    setFilteredTerms(results);
  };

  // Kategori değiştirince arama sonuçlarını güncelle
  useEffect(() => {
    handleSearch();
  }, [selectedCategory]);

  // Arama sorgusunu değiştirince
  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    // Hemen arama yapmak için
    const timer = setTimeout(() => {
      handleSearch();
    }, 300);

    return () => clearTimeout(timer);
  };

  // İlgili terimleri göster
  const showRelatedTerm = (termId: string) => {
    const term = getTermById(termId);
    if (term) {
      setSelectedTerm(term);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl h-[80vh] flex flex-col">
        <CyberContainer className="w-full h-full overflow-hidden flex flex-col">
          {/* Yükleme animasyonu */}
          {isLoading && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 z-50">
              <div className="animate-spin w-12 h-12 border-t-2 border-b-2 border-primary rounded-full mb-4"></div>
              <HackerTerminal className="w-64" />
            </div>
          )}

          <CardHeader className="p-4 pb-2 border-b border-primary/30 flex-none">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-xl font-bold text-primary">
                  <CyberGlitchText intensity="low">Siber Güvenlik Sözlüğü</CyberGlitchText>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Siber güvenlik terimlerini arayın ve öğrenin
                </CardDescription>
              </div>
              <Button variant="outline" size="sm" className="border-red-500/50 text-red-400 hover:bg-red-900/20" onClick={onClose}>
                Kapat
              </Button>
            </div>
          </CardHeader>

          <CardContent className="p-4 flex-grow overflow-hidden flex gap-4">
            {/* Sol panel - Arama ve liste */}
            <div className="w-1/3 flex flex-col h-full">
              <div className="space-y-3 mb-3">
                <Input
                  placeholder="Terim ara..."
                  value={searchQuery}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  className="bg-black text-white border-primary/50 focus:border-primary"
                />

                <div className="flex flex-wrap gap-2">
                  <Badge
                    variant={selectedCategory === "all" ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => setSelectedCategory("all")}
                  >
                    Tümü
                  </Badge>
                  {categories.map((category) => (
                    <Badge
                      key={category}
                      variant={selectedCategory === category ? "default" : "outline"}
                      className={`cursor-pointer ${
                        getCategoryStyle(category).badge
                      }`}
                      onClick={() => setSelectedCategory(category)}
                    >
                      {category}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex-grow overflow-y-auto border border-primary/20 rounded-md">
                {filteredTerms.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-gray-400 p-4 text-center">
                    <div className="text-2xl mb-2">🔍</div>
                    <p>Sonuç bulunamadı</p>
                    <p className="text-xs mt-1">Farklı anahtar kelimeler veya kategoriler deneyin</p>
                  </div>
                ) : (
                  <div className="p-1 space-y-1">
                    {filteredTerms.map((term) => (
                      <div
                        key={term.id}
                        className={`p-2 rounded-md cursor-pointer transition-colors ${
                          selectedTerm?.id === term.id
                            ? 'bg-primary/20 border border-primary/40'
                            : 'hover:bg-gray-900'
                        }`}
                        onClick={() => setSelectedTerm(term)}
                      >
                        <div className="font-medium">{term.term}</div>
                        <div className="text-xs text-gray-400 truncate">{term.shortDescription}</div>
                        <div className="mt-1">
                          <Badge variant="outline" className={getCategoryStyle(term.category).badge}>
                            {term.category}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Sağ panel - Terim detayları */}
            <div className="w-2/3 border border-primary/20 rounded-md overflow-y-auto bg-black/50 relative">
              {selectedTerm ? (
                <div className="p-4">
                  <h2 className="text-xl font-bold text-primary mb-1">{selectedTerm.term}</h2>
                  <Badge variant="outline" className={`mb-3 ${getCategoryStyle(selectedTerm.category).badge}`}>
                    {selectedTerm.category}
                  </Badge>

                  <div className="prose prose-invert prose-sm max-w-none">
                    <p className="text-gray-300">{selectedTerm.definition}</p>

                    {selectedTerm.example && (
                      <div className="mt-4">
                        <h3 className="text-sm font-medium text-primary">Örnek:</h3>
                        <p className="text-sm bg-gray-900/50 p-2 rounded-md border-l-2 border-primary/50 mt-1">
                          {selectedTerm.example}
                        </p>
                      </div>
                    )}

                    {selectedTerm.imageUrl && (
                      <div className="mt-4">
                        <div className="relative h-48 w-full max-w-lg mx-auto rounded-md overflow-hidden border border-primary/30">
                          <Image
                            src={selectedTerm.imageUrl}
                            alt={selectedTerm.term}
                            fill
                            style={{ objectFit: 'contain' }}
                            className="p-2 bg-black"
                          />
                        </div>
                      </div>
                    )}

                    {selectedTerm.relatedTerms && selectedTerm.relatedTerms.length > 0 && (
                      <div className="mt-4">
                        <h3 className="text-sm font-medium text-primary">İlgili Terimler:</h3>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {selectedTerm.relatedTerms.map((termId) => {
                            const relatedTerm = getTermById(termId);
                            return relatedTerm ? (
                              <Badge
                                key={termId}
                                variant="outline"
                                className="cursor-pointer hover:bg-primary/10"
                                onClick={() => showRelatedTerm(termId)}
                              >
                                {relatedTerm.term.split(' ')[0]}
                              </Badge>
                            ) : null;
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-gray-400 p-4 text-center">
                  <div className="text-4xl mb-3">📚</div>
                  <p>Detaylarını görmek için bir terim seçin</p>
                  <p className="text-xs mt-2">Soldaki listeden bir terim seçebilir veya arama yapabilirsiniz</p>
                </div>
              )}
            </div>
          </CardContent>

          <CardFooter className="p-3 border-t border-primary/30 justify-between flex-none">
            <div className="text-xs text-gray-400">
              Toplam {filteredTerms.length} terim listeleniyor
            </div>
            <div className="text-xs text-gray-400">
              Siber güvenliğinizi güçlendirmek için terimleri öğrenin
            </div>
          </CardFooter>
        </CyberContainer>
      </div>
    </div>
  );
}

// Kategori stillerini döndüren yardımcı fonksiyon
function getCategoryStyle(category: string) {
  switch (category) {
    case 'Saldırı Türleri':
      return { badge: 'bg-red-900/20 border-red-500/50 text-red-400' };
    case 'Güvenlik Önlemleri':
      return { badge: 'bg-green-900/20 border-green-500/50 text-green-400' };
    case 'Ağ Güvenliği':
      return { badge: 'bg-blue-900/20 border-blue-500/50 text-blue-400' };
    case 'Şifreleme':
      return { badge: 'bg-yellow-900/20 border-yellow-500/50 text-yellow-400' };
    case 'Sosyal Mühendislik':
      return { badge: 'bg-orange-900/20 border-orange-500/50 text-orange-400' };
    case 'Mobil Güvenlik':
      return { badge: 'bg-purple-900/20 border-purple-500/50 text-purple-400' };
    case 'IoT Güvenliği':
      return { badge: 'bg-cyan-900/20 border-cyan-500/50 text-cyan-400' };
    case 'Genel':
      return { badge: 'bg-gray-900/20 border-gray-500/50 text-gray-400' };
    default:
      return { badge: 'bg-primary/20 border-primary/50' };
  }
}
