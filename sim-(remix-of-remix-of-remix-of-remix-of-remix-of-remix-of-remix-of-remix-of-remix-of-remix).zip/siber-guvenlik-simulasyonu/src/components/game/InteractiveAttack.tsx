"use client";

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { CyberContainer, CyberGlitchText } from "@/components/ui/cyber-effects";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

// Saldırı türleri
export type AttackType =
  | 'phishing'
  | 'malware'
  | 'ddos'
  | 'ransomware'
  | 'mitm'
  | 'sql-injection'
  | 'bruteforce';

// Zorluk seviyeleri
export type Difficulty = 'easy' | 'medium' | 'hard';

// Interaktif saldırı props
interface InteractiveAttackProps {
  type: AttackType;
  difficulty: Difficulty;
  onDefend: (success: boolean, score: number) => void;
}

export function InteractiveAttack({ type, difficulty, onDefend }: InteractiveAttackProps) {
  const [isActive, setIsActive] = useState(false);
  const [attackProgress, setAttackProgress] = useState(0);
  const [defenseProgress, setDefenseProgress] = useState(0);
  const [attackSpeed, setAttackSpeed] = useState(0);
  const [defenseTools, setDefenseTools] = useState<string[]>([]);
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [logs, setLogs] = useState<{text: string, type: 'attack' | 'defense' | 'info'}[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [success, setSuccess] = useState(false);
  const [score, setScore] = useState(0);
  const attackInterval = useRef<NodeJS.Timeout | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Zorluk ve saldırı türüne göre oyun parametrelerini ayarla
  useEffect(() => {
    // Oyunu başlat
    initializeGame();

    // Komponent temizlendiğinde interval'i temizle
    return () => {
      if (attackInterval.current) {
        clearInterval(attackInterval.current);
      }
    };
  }, [type, difficulty]);

  // Oyunu başlat
  const initializeGame = () => {
    setLogs([{ text: "Siber güvenlik sistemi başlatılıyor...", type: "info" }]);

    // Zorluk seviyesine göre saldırı hızını ve süreyi ayarla
    let speed = 0;
    switch (difficulty) {
      case 'easy':
        speed = 2; // Her 500ms'de %2 ilerleme
        break;
      case 'medium':
        speed = 3; // Her 500ms'de %3 ilerleme
        break;
      case 'hard':
        speed = 5; // Her 500ms'de %5 ilerleme
        break;
    }
    setAttackSpeed(speed);

    // Saldırı türüne göre savunma araçlarını ayarla
    const tools = getDefenseTools(type);
    setDefenseTools(tools);

    // Oyunu başlatmak için kısa bir gecikme
    setTimeout(() => {
      setIsActive(true);
      addLog(`${getAttackName(type)} saldırısı tespit edildi!`, "attack");

      // Saldırı ilerlemesini başlat
      attackInterval.current = setInterval(() => {
        setAttackProgress(prev => {
          const newValue = prev + speed;

          if (newValue >= 100) {
            // Saldırı başarılı oldu, oyun bitti
            endGame(false);
            return 100;
          }

          return newValue;
        });
      }, 500);

    }, 1500);
  };

  // Savunma aracını seç
  const selectDefenseTool = (tool: string) => {
    setSelectedTool(tool);
    addLog(`"${tool}" savunma aracı seçildi.`, "defense");

    // Aracın etkinliğini hesapla
    const effectiveness = calculateToolEffectiveness(tool, type);

    if (effectiveness > 0) {
      // Savunma ilerlemesini artır
      const increase = effectiveness * (difficulty === 'easy' ? 2 : difficulty === 'medium' ? 1.5 : 1);
      setDefenseProgress(prev => Math.min(prev + increase, 100));

      // Etkili savunma logu
      addLog(`${tool} ile savunma başarılı! (%${effectiveness} etkinlik)`, "defense");
    } else {
      // Etkisiz savunma
      addLog(`${tool} bu saldırı tipine karşı etkisiz.`, "info");
    }

    // Savunma %100'e ulaştıysa oyunu bitir
    if (defenseProgress + effectiveness >= 100) {
      endGame(true);
    }
  };

  // Oyunu bitir
  const endGame = (isSuccessful: boolean) => {
    if (attackInterval.current) {
      clearInterval(attackInterval.current);
    }

    setGameOver(true);
    setSuccess(isSuccessful);

    // Skoru hesapla
    const timeBonus = 100 - attackProgress;
    const difficultyMultiplier = difficulty === 'easy' ? 1 : difficulty === 'medium' ? 1.5 : 2;
    const finalScore = Math.round((isSuccessful ? 100 : 0) + timeBonus * difficultyMultiplier);
    setScore(finalScore);

    // Sonuçları bildir
    addLog(isSuccessful
      ? `Tebrikler! Saldırıyı başarıyla durdurdunuz.`
      : `Saldırı başarılı oldu! Sistem tehlike altında.`,
      isSuccessful ? "defense" : "attack"
    );

    // Callback'i çağır
    setTimeout(() => {
      onDefend(isSuccessful, finalScore);
    }, 2000);
  };

  // Log ekle
  const addLog = (text: string, type: 'attack' | 'defense' | 'info') => {
    setLogs(prev => [...prev, { text, type }]);

    // Otomatik olarak log alanını aşağıya kaydır
    if (containerRef.current) {
      setTimeout(() => {
        if (containerRef.current) {
          containerRef.current.scrollTop = containerRef.current.scrollHeight;
        }
      }, 100);
    }
  };

  // Animasyon sınıflarını hesapla
  const getAnimationClasses = () => {
    switch (type) {
      case 'ddos':
        return 'animate-ping';
      case 'ransomware':
        return 'animate-pulse';
      case 'phishing':
        return 'animate-bounce';
      default:
        return 'animate-pulse';
    }
  };

  // Saldırı verilerini göster
  return (
    <CyberContainer className="relative overflow-hidden">
      <div className="p-4">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xl font-bold text-primary">
              <CyberGlitchText intensity="medium">{getAttackName(type)} Saldırısı</CyberGlitchText>
            </h2>
            <p className="text-sm text-gray-400">
              Saldırıyı durdurmak için en etkili savunma araçlarını kullanın
            </p>
          </div>

          <Badge
            variant="outline"
            className={`${getDifficultyColor(difficulty)} ${isActive ? getAnimationClasses() : ''}`}
          >
            {difficulty === 'easy' ? 'Kolay' : difficulty === 'medium' ? 'Orta' : 'Zor'} Seviye
          </Badge>
        </div>

        {/* İlerleme çubukları */}
        <div className="grid grid-cols-1 gap-2 mb-6">
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-red-400">Saldırı İlerlemesi</span>
              <span className="text-red-400">{Math.round(attackProgress)}%</span>
            </div>
            <Progress
              value={attackProgress}
              className="h-3 bg-red-950"
              indicatorClassName={`bg-red-500 ${attackProgress > 75 ? 'animate-pulse' : ''}`}
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-green-400">Savunma İlerlemesi</span>
              <span className="text-green-400">{Math.round(defenseProgress)}%</span>
            </div>
            <Progress
              value={defenseProgress}
              className="h-3 bg-green-950"
              indicatorClassName="bg-green-500"
            />
          </div>
        </div>

        {/* Savunma araçları */}
        <div className="mb-4">
          <h3 className="text-sm font-medium text-white mb-2">Savunma Araçları:</h3>
          <div className="flex flex-wrap gap-2">
            {defenseTools.map(tool => (
              <Button
                key={tool}
                size="sm"
                variant={selectedTool === tool ? "default" : "outline"}
                onClick={() => selectDefenseTool(tool)}
                disabled={gameOver}
                className="transition-all duration-200"
              >
                {getToolIcon(tool)} {tool}
              </Button>
            ))}
          </div>
        </div>

        {/* Log alanı */}
        <div className="border border-primary/20 rounded-md p-2 bg-black/50 h-40 overflow-y-auto mb-4" ref={containerRef}>
          {logs.map((log, index) => (
            <div
              key={index}
              className={`text-xs mb-1 ${
                log.type === 'attack' ? 'text-red-400' :
                log.type === 'defense' ? 'text-green-400' :
                'text-gray-400'
              }`}
            >
              <span className="opacity-70">[{new Date().toLocaleTimeString()}]</span> {log.text}
            </div>
          ))}
        </div>

        {/* Sonuç mesajı */}
        {gameOver && (
          <div className={`p-3 rounded-md mb-4 ${
            success ? 'bg-green-900/30 border border-green-500/50' : 'bg-red-900/30 border border-red-500/50'
          }`}>
            <h3 className={`font-bold ${success ? 'text-green-400' : 'text-red-400'}`}>
              {success ? '✅ Saldırı engellendi!' : '❌ Saldırı başarılı oldu!'}
            </h3>
            <p className="text-sm">
              {success
                ? 'Tebrikler! Saldırıyı başarıyla durdurdunuz. Sistem güvende.'
                : 'Maalesef savunma yetersiz kaldı. Sistem saldırıya uğradı.'
              }
            </p>
            <div className="mt-2 font-medium">
              Skor: {score} puan
            </div>
          </div>
        )}
      </div>
    </CyberContainer>
  );
}

// Saldırı tipine göre savunma araçlarını getir
function getDefenseTools(type: AttackType): string[] {
  const commonTools = ['Güvenlik Duvarı', 'Antivirus'];

  switch (type) {
    case 'phishing':
      return [...commonTools, 'E-posta Filtreleme', 'Kullanıcı Eğitimi', 'Anti-Spam', 'Link Tarayıcı'];
    case 'malware':
      return [...commonTools, 'Malware Tarayıcı', 'Host IDS', 'Davranış Analizi', 'Patch Management'];
    case 'ddos':
      return [...commonTools, 'DDoS Koruma', 'Trafik Filtreleme', 'Yük Dengeleme', 'Rate Limiting'];
    case 'ransomware':
      return [...commonTools, 'Düzenli Yedekleme', 'Dosya İzleme', 'Sandbox', 'EDR Çözümü'];
    case 'mitm':
      return [...commonTools, 'TLS/SSL', 'VPN', 'İki Faktörlü Kimlik Doğrulama', 'Sertifika Doğrulama'];
    case 'sql-injection':
      return [...commonTools, 'Web Application Firewall', 'Input Validation', 'Parametrize SQL', 'Kod Analizi'];
    case 'bruteforce':
      return [...commonTools, 'Account Lockout', 'CAPTCHA', 'İki Faktörlü Kimlik Doğrulama', 'Şifre Politikası'];
    default:
      return commonTools;
  }
}

// Savunma aracının etkinliğini hesapla (0-40 arası)
function calculateToolEffectiveness(tool: string, attackType: AttackType): number {
  // Saldırı türüne göre en etkili araçları tanımla
  const effectiveness: Record<string, Record<string, number>> = {
    'phishing': {
      'E-posta Filtreleme': 35,
      'Kullanıcı Eğitimi': 40,
      'Anti-Spam': 30,
      'Link Tarayıcı': 25,
      'Güvenlik Duvarı': 10,
      'Antivirus': 15
    },
    'malware': {
      'Antivirus': 40,
      'Malware Tarayıcı': 40,
      'Host IDS': 30,
      'Davranış Analizi': 35,
      'Patch Management': 25,
      'Güvenlik Duvarı': 15
    },
    'ddos': {
      'DDoS Koruma': 40,
      'Trafik Filtreleme': 35,
      'Yük Dengeleme': 30,
      'Rate Limiting': 25,
      'Güvenlik Duvarı': 20,
      'Antivirus': 5
    },
    'ransomware': {
      'Düzenli Yedekleme': 40,
      'Antivirus': 25,
      'Dosya İzleme': 35,
      'Sandbox': 30,
      'EDR Çözümü': 35,
      'Güvenlik Duvarı': 10
    },
    'mitm': {
      'TLS/SSL': 40,
      'VPN': 35,
      'İki Faktörlü Kimlik Doğrulama': 30,
      'Sertifika Doğrulama': 35,
      'Güvenlik Duvarı': 15,
      'Antivirus': 5
    },
    'sql-injection': {
      'Web Application Firewall': 35,
      'Input Validation': 40,
      'Parametrize SQL': 40,
      'Kod Analizi': 30,
      'Güvenlik Duvarı': 20,
      'Antivirus': 5
    },
    'bruteforce': {
      'Account Lockout': 40,
      'CAPTCHA': 35,
      'İki Faktörlü Kimlik Doğrulama': 40,
      'Şifre Politikası': 30,
      'Güvenlik Duvarı': 15,
      'Antivirus': 5
    }
  };

  // Aracın ilgili saldırı türüne karşı etkinliğini döndür
  return effectiveness[attackType]?.[tool] || 5; // Tanımlanmamışsa %5 etkili
}

// Saldırı türüne göre isim döndür
function getAttackName(type: AttackType): string {
  switch (type) {
    case 'phishing':
      return 'Oltalama';
    case 'malware':
      return 'Kötücül Yazılım';
    case 'ddos':
      return 'DDoS';
    case 'ransomware':
      return 'Fidye Yazılımı';
    case 'mitm':
      return 'Man-in-the-Middle';
    case 'sql-injection':
      return 'SQL Enjeksiyonu';
    case 'bruteforce':
      return 'Kaba Kuvvet';
    default:
      return 'Siber Saldırı';
  }
}

// Zorluk seviyesine göre renk döndür
function getDifficultyColor(difficulty: Difficulty): string {
  switch (difficulty) {
    case 'easy':
      return 'bg-green-900/20 border-green-500/50 text-green-400';
    case 'medium':
      return 'bg-yellow-900/20 border-yellow-500/50 text-yellow-400';
    case 'hard':
      return 'bg-red-900/20 border-red-500/50 text-red-400';
    default:
      return 'bg-blue-900/20 border-blue-500/50 text-blue-400';
  }
}

// Araca göre icon döndür
function getToolIcon(tool: string): string {
  switch (tool) {
    case 'Güvenlik Duvarı':
      return '🛡️';
    case 'Antivirus':
      return '🦠';
    case 'E-posta Filtreleme':
      return '📧';
    case 'Kullanıcı Eğitimi':
      return '👨‍🏫';
    case 'Anti-Spam':
      return '🚫';
    case 'Link Tarayıcı':
      return '🔍';
    case 'Malware Tarayıcı':
      return '🔎';
    case 'Host IDS':
      return '📡';
    case 'Davranış Analizi':
      return '📊';
    case 'Patch Management':
      return '🔧';
    case 'DDoS Koruma':
      return '🌐';
    case 'Trafik Filtreleme':
      return '🚦';
    case 'Yük Dengeleme':
      return '⚖️';
    case 'Rate Limiting':
      return '⏱️';
    case 'Düzenli Yedekleme':
      return '💾';
    case 'Dosya İzleme':
      return '👁️';
    case 'Sandbox':
      return '📦';
    case 'EDR Çözümü':
      return '🔍';
    case 'TLS/SSL':
      return '🔒';
    case 'VPN':
      return '🔐';
    case 'İki Faktörlü Kimlik Doğrulama':
      return '🔑';
    case 'Sertifika Doğrulama':
      return '📜';
    case 'Web Application Firewall':
      return '🧱';
    case 'Input Validation':
      return '✅';
    case 'Parametrize SQL':
      return '💼';
    case 'Kod Analizi':
      return '🔬';
    case 'Account Lockout':
      return '🔒';
    case 'CAPTCHA':
      return '🤖';
    case 'Şifre Politikası':
      return '📋';
    default:
      return '🛠️';
  }
}
