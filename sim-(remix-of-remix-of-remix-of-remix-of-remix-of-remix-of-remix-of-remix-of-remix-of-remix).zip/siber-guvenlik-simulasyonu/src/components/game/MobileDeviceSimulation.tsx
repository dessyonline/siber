"use client";

import React, { useState } from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface MobileDeviceSimulationProps {
  type?: 'app-permissions' | 'fake-store' | 'security-alert';
  image?: string;
  onAction?: (action: string) => void;
}

export function MobileDeviceSimulation({
  type = 'app-permissions',
  image,
  onAction,
}: MobileDeviceSimulationProps) {
  const [showPermissions, setShowPermissions] = useState(false);
  const [appInstalled, setAppInstalled] = useState(false);
  const [showAlert, setShowAlert] = useState(false);

  // Sahte uygulama mağazası görüntüsü için tıklama işleyicisi
  const handleFakeStoreClick = (action: 'install' | 'close') => {
    if (action === 'install') {
      setShowAlert(true);
      if (onAction) onAction('install');
    } else {
      setShowAlert(false);
      if (onAction) onAction('close');
    }
  };

  // İzin onayları için tıklama işleyicisi
  const handlePermissionAction = (grant: boolean) => {
    if (grant) {
      if (onAction) onAction('grant-permissions');
    } else {
      if (onAction) onAction('deny-permissions');
    }
    setShowPermissions(false);
  };

  const renderContent = () => {
    switch (type) {
      case 'fake-store':
        return (
          <div className="relative h-full w-full bg-gray-900 overflow-hidden rounded-xl">
            {/* Sahte uygulama mağazası içeriği */}
            <div className="flex flex-col h-full">
              {/* Sahte mağaza başlığı */}
              <div className="bg-gray-800 p-4 flex items-center border-b border-gray-700">
                <div className="w-10 h-10 relative mr-3">
                  <div className="w-full h-full bg-gradient-to-br from-blue-500 to-green-400 rounded-md"></div>
                </div>
                <div className="text-white text-xl font-medium">Alternatif Uygulama Mağazası</div>
              </div>

              {/* Uygulama detayları */}
              <div className="flex-1 p-5">
                <div className="flex items-start mb-6">
                  <div className="w-20 h-20 relative bg-gray-700 rounded-lg mr-5 overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center text-4xl">🎮</div>
                  </div>
                  <div>
                    <h3 className="text-white text-xl font-bold">Epic Battle Royale</h3>
                    <p className="text-gray-400 text-base">Premium Oyun - Ücretsiz</p>
                    <div className="flex items-center mt-2">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <span key={star} className="text-yellow-400 text-lg">★</span>
                        ))}
                      </div>
                      <span className="text-gray-400 text-sm ml-2">10M+ İndirme</span>
                    </div>
                  </div>
                </div>

                {/* Ekran görüntüleri - Daha büyük bir görüntü için */}
                <div className="mb-6 relative h-56 bg-gray-800 rounded-md overflow-hidden">
                  {image && (
                    <Image
                      src={image}
                      alt="App screenshot"
                      fill
                      style={{ objectFit: "cover" }}
                      className="mix-blend-lighten opacity-90"
                      priority
                    />
                  )}
                </div>

                {/* İndirilsin mi? */}
                <div className="mt-6 space-y-3">
                  <Button
                    className="w-full bg-green-600 hover:bg-green-700 text-lg py-6"
                    onClick={() => handleFakeStoreClick('install')}
                  >
                    ÜCRETSİZ İNDİR
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-gray-600 text-gray-300 text-lg py-5"
                    onClick={() => handleFakeStoreClick('close')}
                  >
                    İPTAL ET
                  </Button>
                  <p className="text-red-400 text-sm mt-2 text-center">
                    * Resmi olmayan uygulama mağazasıdır
                  </p>
                </div>
              </div>
            </div>

            {/* Sahte Mağaza Uyarısı */}
            {showAlert && (
              <div className="absolute inset-0 bg-black/80 flex items-center justify-center p-6 z-20">
                <Card className="w-full max-w-md bg-gray-900 border-red-500/50">
                  <CardContent className="p-6">
                    <div className="text-red-500 text-2xl font-bold mb-4 flex items-center">
                      <span className="mr-3 text-3xl">⚠️</span> Güvenlik Uyarısı
                    </div>
                    <p className="text-white text-base mb-6">
                      Bu uygulama, cihazdaki kişisel verilerinize ve banka bilgilerinize erişmek için tasarlanmış olabilir. Resmi olmayan mağazalardan uygulama indirmek güvenlik riskleri taşır.
                    </p>
                    <div className="flex justify-end">
                      <Button
                        variant="outline"
                        className="border-gray-600 text-gray-300 text-lg py-5 px-8"
                        onClick={() => setShowAlert(false)}
                      >
                        Tamam
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        );

      case 'app-permissions':
        return (
          <div className="relative h-full w-full bg-gray-900 overflow-hidden rounded-xl">
            {/* Uygulama izinleri içeriği */}
            <div className="flex flex-col h-full">
              {/* Başlık */}
              <div className="bg-gray-800 p-4 flex items-center border-b border-gray-700">
                <div className="text-white text-xl font-medium">İzinler İsteniyor</div>
              </div>

              {/* İzin listesi */}
              <div className="flex-1 p-5">
                <div className="w-24 h-24 relative bg-gray-700 rounded-lg mx-auto mb-5 overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center text-5xl">📷</div>
                </div>
                <h3 className="text-white text-2xl font-bold text-center mb-4">
                  Foto Düzenleyici Pro
                </h3>
                <p className="text-white text-lg mb-6 text-center">
                  Bu uygulama aşağıdaki izinleri istiyor:
                </p>

                <div className="space-y-4 mb-8">
                  <div className="flex items-center justify-between p-3 border border-green-500/30 bg-green-900/20 rounded-md">
                    <div className="flex items-center">
                      <span className="text-2xl mr-4">📷</span>
                      <span className="text-white text-lg">Kamera</span>
                    </div>
                    <div className="text-green-400 text-base">Gerekli</div>
                  </div>

                  <div className="flex items-center justify-between p-3 border border-green-500/30 bg-green-900/20 rounded-md">
                    <div className="flex items-center">
                      <span className="text-2xl mr-4">🖼️</span>
                      <span className="text-white text-lg">Galeri</span>
                    </div>
                    <div className="text-green-400 text-base">Gerekli</div>
                  </div>

                  <div className="flex items-center justify-between p-3 border border-red-500/30 bg-red-900/20 rounded-md">
                    <div className="flex items-center">
                      <span className="text-2xl mr-4">📍</span>
                      <span className="text-white text-lg">Konum</span>
                    </div>
                    <div className="text-red-400 text-base">Şüpheli</div>
                  </div>

                  <div className="flex items-center justify-between p-3 border border-red-500/30 bg-red-900/20 rounded-md">
                    <div className="flex items-center">
                      <span className="text-2xl mr-4">📞</span>
                      <span className="text-white text-lg">Rehber</span>
                    </div>
                    <div className="text-red-400 text-base">Şüpheli</div>
                  </div>

                  <div className="flex items-center justify-between p-3 border border-red-500/30 bg-red-900/20 rounded-md">
                    <div className="flex items-center">
                      <span className="text-2xl mr-4">🎤</span>
                      <span className="text-white text-lg">Mikrofon</span>
                    </div>
                    <div className="text-red-400 text-base">Şüpheli</div>
                  </div>

                  <div className="flex items-center justify-between p-3 border border-red-500/30 bg-red-900/20 rounded-md">
                    <div className="flex items-center">
                      <span className="text-2xl mr-4">✉️</span>
                      <span className="text-white text-lg">Mesajlar</span>
                    </div>
                    <div className="text-red-400 text-base">Şüpheli</div>
                  </div>
                </div>

                <div className="flex space-x-4">
                  <Button
                    variant="outline"
                    className="flex-1 border-gray-600 text-gray-300 text-lg py-5"
                    onClick={() => handlePermissionAction(false)}
                  >
                    Reddet
                  </Button>
                  <Button
                    className="flex-1 bg-green-600 hover:bg-green-700 text-lg py-5"
                    onClick={() => handlePermissionAction(true)}
                  >
                    Tümüne İzin Ver
                  </Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 'security-alert':
        return (
          <div className="relative h-full w-full bg-gray-900 overflow-hidden rounded-xl">
            {/* Güvenlik uyarısı içeriği */}
            <div className="flex flex-col h-full">
              {/* Başlık */}
              <div className="bg-gray-800 p-3 flex items-center border-b border-gray-700">
                <div className="text-white text-lg font-medium">Güvenlik Uyarısı</div>
              </div>

              {/* Uyarı içeriği */}
              <div className="flex-1 p-4 flex flex-col items-center justify-center">
                <div className="w-20 h-20 relative mb-4">
                  <div className="absolute inset-0 flex items-center justify-center text-5xl">⚠️</div>
                </div>
                <h3 className="text-red-500 text-xl font-bold text-center mb-2">
                  Telefonunuz Risk Altında!
                </h3>
                <p className="text-white text-sm mb-6 text-center">
                  5 adet kötü amaçlı yazılım tespit edildi. Acil temizleme gerekiyor.
                </p>

                <Button
                  className="w-full bg-red-600 hover:bg-red-700 mb-3"
                  onClick={() => onAction?.('clicked-alert')}
                >
                  ŞİMDİ TEMİZLE
                </Button>
                <Button
                  variant="outline"
                  className="w-full border-gray-600 text-gray-300"
                  onClick={() => onAction?.('dismissed-alert')}
                >
                  Yoksay
                </Button>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="flex items-center justify-center h-full">
            <p className="text-white">Mobil cihaz simülasyonu</p>
          </div>
        );
    }
  };

  return (
    <div className="w-full max-w-md mx-auto h-[700px] rounded-3xl overflow-hidden border-8 border-gray-800 bg-gray-900 shadow-lg">
      {/* Telefon üst çubuğu */}
      <div className="h-6 bg-black flex items-center justify-between px-6">
        <div className="text-white text-xs">21:37</div>
        <div className="flex space-x-2">
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
        </div>
      </div>

      {/* Ana içerik alanı */}
      <div className="h-[calc(100%-3rem)] overflow-hidden">
        {renderContent()}
      </div>

      {/* Telefon alt çubuğu */}
      <div className="h-6 bg-black flex items-center justify-center">
        <div className="w-20 h-1 bg-gray-600 rounded-full"></div>
      </div>
    </div>
  );
}
