"use client";

import React, { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useGameStore } from "@/store/gameStore";
import { CyberGlitchText } from "@/components/ui/cyber-effects";
import html2canvas from "html2canvas";
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import type { ScenarioType } from "@/store/gameStore";
import { Progress } from "@/components/ui/progress";

// Kategori adlarını Türkçeye çeviren yardımcı fonksiyon
const categoryNames: Record<ScenarioType, string> = {
  phishing: "Oltalama",
  password: "Şifre Güvenliği",
  software: "Yazılım Güvenliği",
  social: "Sosyal Mühendislik",
  network: "Ağ Güvenliği",
  terminal: "Terminal Güvenliği",
  desktop: "Masaüstü Güvenliği",
  mobile: "Mobil Güvenlik",
  physical: "Fiziksel Güvenlik",
  ai: "Yapay Zeka Güvenliği",
  blockchain: "Blockchain Güvenliği",
  iot: "IoT Güvenliği"
};

// Değerlendirme algoritması
function getPersonalEvaluation(score: number): string {
  if (score >= 90) return "Harika! Yüksek siber güvenlik farkındalığı ve uygulama düzeyine sahipsiniz. Gerçek hayatta karmaşık saldırıları tanıyıp doğru tepki verebilirsiniz. Teknik detaylara da hâkimsiniz. Gelişiminiz için yeni tehdit türlerini ve ileri düzey koruma tekniklerini takip edin.";
  if (score >= 75) return "Çok iyi! Modern tehditleri büyük ölçüde tanıyabiliyor, çoğu senaryoda doğru tepki verebiliyorsunuz. Ancak bazı ileri saldırı desenleri veya sosyal mühendislik konularında dikkatli olmalısınız. Gerçek vakalarda detaylara dikkat etmeye devam edin.";
  if (score >= 60) return "Fena değil! Temel tehditleri ayırt edebiliyorsunuz ve kritik hatalardan çoğunlukla kaçındınız. Oltalama, yazılım güncelleme ve parola yönetimi konularına özellikle dikkat etmelisiniz. Deneyimle öğrenmeye devam edin.";
  if (score >= 40) return "Ortalama! Bazı temel kavramlarda eksikleriniz var. Özellikle sosyal mühendislik, mobil güvenlik ve ağ risklerinde hatalarınız mevcut. Pratik yaparak ve dökümantasyon okuyarak ilerlemenizi öneririz.";
  return "Geliştirilmesi Gereken Alanlar! Pek çok temel konuda eksik var. Sık yapılan hatalar: mesajlardaki linklere tıklamak, şüpheli izinlere dikkat etmemek, zayıf veya tekrar edilen şifreler kullanmak. Farkındalığınızı artırmak için siber.php ve benzeri kaynaklardan bol bol pratik öneriyoruz.";
}

export function ImprovedCertificate() {
  const { username, score, getScorePercentage, resetGame, getCategoryPerformance } = useGameStore();
  const certificateRef = useRef<HTMLDivElement>(null);
  const scorePercentage = getScorePercentage();
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [certificateImage, setCertificateImage] = useState<string | null>(null);
  const categoryPerformance = getCategoryPerformance();

  // Yeni: En iyi ve en zayıf kategorileri bul
  const sortedCategories = [...categoryPerformance].sort((a, b) => b.percentage - a.percentage);
  const bestCategory = sortedCategories.length > 0 ? sortedCategories[0] : null;
  const worstCategory = sortedCategories.length > 0 ? sortedCategories[sortedCategories.length - 1] : null;

  // Tarihi formatlama
  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString('tr-TR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  // Sertifika seri numarası
  const serialNumber = `SG-${Date.now().toString().slice(-8)}`;

  // Sertifikayı PNG olarak indirme
  const downloadCertificate = async () => {
    if (!certificateRef.current) return;

    try {
      const canvas = await html2canvas(certificateRef.current, {
        scale: 2,
        backgroundColor: null,
        logging: false
      });

      const image = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.href = image;
      link.download = `${username.replace(/\s+/g, '_')}_Siber_Guvenlik_Sertifikasi.png`;
      link.click();
    } catch (error) {
      console.error("Sertifika indirme hatası:", error);
    }
  };

  // Sertifikayı paylaşım için hazırlama
  const prepareForSharing = async () => {
    if (!certificateRef.current) return;

    try {
      const canvas = await html2canvas(certificateRef.current, {
        scale: 2,
        backgroundColor: null,
        logging: false
      });

      const image = canvas.toDataURL("image/png");
      setCertificateImage(image);
      setShowShareDialog(true);
    } catch (error) {
      console.error("Sertifika paylaşım hatası:", error);
    }
  };

  // Instagram'da paylaşım için
  const shareOnInstagram = () => {
    if (!certificateImage) return;

    const textarea = document.createElement('textarea');
    textarea.value = `🔒 Siber Güvenlik Simülasyonunu %${scorePercentage.toFixed(0)} başarı ile tamamladım! Daha fazla eğitim için siber.php hesabını takip edin! #SiberGüvenlik #SiberFarkındalık #siber.php`;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
  };

  return (
    <div className="flex flex-col items-center">
      <div
        ref={certificateRef}
        className="relative w-full max-w-3xl p-2 my-6"
      >
        <Card className={`relative overflow-hidden border-2 border-primary/50 bg-gradient-to-r from-zinc-900 to-zinc-800 p-8`}>
          {/* Arka plan efektleri */}
          <div className="absolute inset-0 bg-grid-white/10 opacity-20" />
          <div className="absolute top-0 left-0 w-32 h-32 bg-white opacity-10 rounded-full -translate-x-1/2 -translate-y-1/2 blur-2xl" />
          <div className="absolute bottom-0 right-0 w-32 h-32 bg-white opacity-10 rounded-full translate-x-1/2 translate-y-1/2 blur-2xl" />

          {/* Sertifika içeriği (yeni: başarı puanı & yapay zekâ değerlendirmesi) */}
          <div className="relative z-10 text-center space-y-8 py-4 text-white">
            <div className="mb-2">
              <div className="text-2xl  md:text-4xl font-extrabold tracking-wide mb-3 text-primary drop-shadow-lg">Başarı Puanı: {Math.round(scorePercentage)}/100</div>
              <div className="text-base md:text-lg text-white/80 mb-5">{username}</div>
            </div>

            <div className="bg-black/40 border border-primary/30 rounded-lg p-4 mt-2 max-w-xl mx-auto shadow-xl">
              <div className="text-left md:text-base text-sm font-medium text-primary mb-2">
                Yapay Zeka Kişisel Değerlendirme:
              </div>
              <div className="text-white/90">
                {getPersonalEvaluation(scorePercentage)}
              </div>
            </div>

            {/* YENİ: Kategori performans göstergesi */}
            {categoryPerformance.length > 0 && (
              <div className="mt-4 bg-black/40 border border-primary/30 rounded-lg p-4 shadow-xl">
                <div className="text-left md:text-base text-sm font-medium text-primary mb-3">
                  Kategori Bazlı Performans:
                </div>

                {/* Yetenek sütunları */}
                <div className="grid grid-cols-5 gap-2 mb-4">
                  {sortedCategories.slice(0, 5).map((cat) => (
                    <div key={`cert-bar-${cat.category}`} className="flex flex-col items-center">
                      <div className="w-full flex flex-col items-center">
                        <div
                          className="w-4 rounded-t-md"
                          style={{
                            height: `${cat.skillRating * 0.35}px`,
                            background: cat.percentage >= 90 ? 'linear-gradient(to top, #065f46, #10b981)' :
                                      cat.percentage >= 70 ? 'linear-gradient(to top, #1e40af, #3b82f6)' :
                                      cat.percentage >= 50 ? 'linear-gradient(to top, #854d0e, #eab308)' :
                                      cat.percentage >= 30 ? 'linear-gradient(to top, #9a3412, #f97316)' :
                                      'linear-gradient(to top, #7f1d1d, #ef4444)'
                          }}
                        ></div>
                        <div className="mt-1 text-center text-[0.6rem] text-white/70 truncate w-12">
                          {categoryNames[cat.category as ScenarioType]}
                        </div>
                      </div>
                      <div className="mt-1 text-[0.6rem] font-medium" style={{
                        color: cat.percentage >= 90 ? '#10b981' :
                               cat.percentage >= 70 ? '#3b82f6' :
                               cat.percentage >= 50 ? '#eab308' :
                               cat.percentage >= 30 ? '#f97316' :
                               '#ef4444'
                      }}>
                        %{Math.round(cat.percentage)}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Güçlü ve zayıf alanlar */}
                {bestCategory && worstCategory && bestCategory.category !== worstCategory.category && (
                  <div className="grid grid-cols-2 gap-2 text-xs border-t border-white/10 pt-3">
                    <div>
                      <span className="text-green-400 mb-1 block">En İyi Alanınız:</span>
                      <Badge className="bg-green-900/30 text-green-400 text-[0.65rem]">
                        {categoryNames[bestCategory.category as ScenarioType]} - %{Math.round(bestCategory.percentage)}
                      </Badge>
                    </div>
                    <div>
                      <span className="text-red-400 mb-1 block">Geliştirilecek Alan:</span>
                      <Badge className="bg-red-900/30 text-red-400 text-[0.65rem]">
                        {categoryNames[worstCategory.category as ScenarioType]} - %{Math.round(worstCategory.percentage)}
                      </Badge>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex flex-wrap items-center justify-center gap-8 mt-8 text-white/70 text-sm">
              <div>
                <span className="block font-semibold">Tarih</span>
                <span>{formattedDate}</span>
              </div>
              <div className="hidden md:block border-l border-primary/30 h-8"></div>
              <div>
                <span className="block font-semibold">Sertifika No</span>
                <span>{serialNumber}</span>
              </div>
            </div>

            {/* Siber.php geliştirici ve referansı aynı şekilde */}
            <div className="mt-8 pt-4 border-t border-white/10 text-center text-xs text-white/60">
              <div>Daha fazla siber güvenlik eğitimi için: <span className="font-semibold text-white">siber.php</span></div>
              <div className="mt-2">Bu simülasyon <span className="text-white font-bold">Siber.php</span> tarafından geliştirilmiştir.</div>
              <div className="mt-1">© {new Date().getFullYear()} Tüm hakları saklıdır.</div>
            </div>
          </div>
        </Card>
      </div>

      <div className="flex flex-wrap gap-4 justify-center">
        <Button
          onClick={downloadCertificate}
          className="bg-primary hover:bg-primary/80"
          size="lg"
        >
          Sertifikayı İndir
        </Button>

        <Button
          onClick={prepareForSharing}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          size="lg"
        >
          Instagram'da Paylaş
        </Button>

        {/* Instagram takip butonu */}
        <Button
          className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
          size="lg"
          onClick={() => window.open('https://www.instagram.com/siber.php', '_blank')}
        >
          Instagram'da Takip Et
        </Button>

        <Button
          onClick={resetGame}
          variant="outline"
          size="lg"
        >
          Yeniden Başla
        </Button>
      </div>

      <p className="text-sm text-muted-foreground mt-6 text-center max-w-md">
        Bu sertifika, siber güvenlik farkındalık eğitimini tamamladığınızı gösterir.
        Gerçek dünyada siber güvenlik bilincini artırmak için bu bilgileri çevrenizle paylaşabilirsiniz.
        <br />
        <span className="text-primary font-medium mt-2 block">Daha fazla eğitim için siber.php adresini ziyaret edin.</span>
      </p>

      {/* Paylaşım diyaloğu */}
      <AlertDialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <AlertDialogContent className="bg-gray-900 border-primary">
          <AlertDialogHeader>
            <AlertDialogTitle>Instagram'da Paylaş</AlertDialogTitle>
            <AlertDialogDescription>
              Sertifikanızı Instagram'da paylaşmak için:
              1. Aşağıdaki metin otomatik olarak kopyalandı.
              2. Sertifika görselini kaydedin.
              3. Instagram hikayenizde veya gönderide bu görsel ve metni kullanın.
            </AlertDialogDescription>
          </AlertDialogHeader>

          {certificateImage && (
            <div className="my-4 border border-gray-800 rounded-md overflow-hidden">
              <img src={certificateImage} alt="Sertifika" className="w-full" />
            </div>
          )}

          <div className="bg-gray-800 p-3 rounded-md text-sm mb-4">
            <p className="text-white/80">🔒 Siber Güvenlik Simülasyonunu %{scorePercentage.toFixed(0)} başarı ile tamamladım! Daha fazla eğitim için siber.php hesabını takip edin! #SiberGüvenlik #SiberFarkındalık #siber.php</p>
          </div>

          <div className="bg-blue-900/20 border border-blue-500/30 p-3 rounded-md mb-4">
            <h4 className="text-blue-400 text-sm font-medium mb-1">Önemli Bilgi</h4>
            <p className="text-sm text-white/70">Siber güvenlik hakkında daha fazla öğrenmek için <span className="text-blue-400 font-medium">siber.php</span> Instagram hesabını takip edin!</p>
          </div>

          <AlertDialogFooter>
            <AlertDialogAction asChild>
              <Button
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 w-full"
                onClick={shareOnInstagram}
              >
                Metni Kopyala ve Instagram'da Paylaş
              </Button>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
