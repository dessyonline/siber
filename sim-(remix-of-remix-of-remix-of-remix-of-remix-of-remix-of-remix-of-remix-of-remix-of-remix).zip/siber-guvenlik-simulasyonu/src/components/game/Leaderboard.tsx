"use client";

import { useState, useEffect } from "react";
import { useGameStore } from "@/store/gameStore";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function Leaderboard() {
  const { leaderboard, username, updateLeaderboard } = useGameStore();
  const [expanded, setExpanded] = useState(false);
  const [userRank, setUserRank] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Liderlik tablosunu yükle ve kullanıcının sıralamasını belirle
  useEffect(() => {
    setIsLoading(true);
    try {
      // Kullanıcının sıralamasını bul
      if (username && leaderboard.length > 0) {
        const rank = leaderboard.findIndex(entry => entry.username === username);
        setUserRank(rank !== -1 ? rank + 1 : null);
      }
    } finally {
      setIsLoading(false);
    }
  }, [leaderboard, username]);

  // Liderlik tablosunu güncelle
  const handleRefreshLeaderboard = () => {
    setIsLoading(true);
    updateLeaderboard();
    setTimeout(() => setIsLoading(false), 500); // Küçük bir gecikme ekle
  };

  // Boş liderlik tablosu kontrolü
  if (!leaderboard || leaderboard.length === 0) {
    return (
      <Card className="bg-black/30 border border-primary/20 p-4 mb-4">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg text-primary">Liderlik Tablosu</CardTitle>
            <Button
              variant="outline"
              className="text-xs bg-transparent border-primary/30 hover:bg-primary/10 h-8 px-2"
              onClick={handleRefreshLeaderboard}
              disabled={isLoading}
            >
              {isLoading ? "Yükleniyor..." : "Yenile"}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-center text-gray-400 text-sm py-6">
            Henüz liderlik tablosunda hiç kayıt yok. Bir oyun tamamladığınızda skorunuz burada görünecek.
          </p>
        </CardContent>
      </Card>
    );
  }

  // Görüntülenecek kayıt sayısı
  const displayCount = expanded ? leaderboard.length : Math.min(5, leaderboard.length);

  // Kullanıcı sıralamada gösterilen kısımda değilse ama sıralamada varsa
  const userIsHidden = userRank !== null && userRank > displayCount && !expanded;

  // Seviyeye göre renk sınıfı döndür
  const getLevelColorClass = (level: number) => {
    if (level >= 15) return "text-rose-400 font-bold";
    if (level >= 10) return "text-purple-400 font-bold";
    if (level >= 7) return "text-blue-400 font-semibold";
    if (level >= 5) return "text-cyan-400 font-semibold";
    if (level >= 3) return "text-green-400";
    return "text-gray-300";
  };

  // Liderlik tablosunu göster
  return (
    <Card className="bg-black/30 border border-primary/20 p-4 mb-4 relative overflow-hidden">
      {/* Yükleniyor göstergesi */}
      {isLoading && (
        <div className="absolute inset-0 bg-black/60 flex items-center justify-center z-10">
          <div className="animate-pulse text-primary">Yükleniyor...</div>
        </div>
      )}

      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg text-primary">Liderlik Tablosu</CardTitle>
          <div className="flex items-center gap-2">
            {userRank !== null && (
              <Badge variant="outline" className="bg-primary/10 text-primary">
                Sıralamanız: {userRank}.
              </Badge>
            )}
            <Button
              variant="outline"
              className="text-xs bg-transparent border-primary/30 hover:bg-primary/10 h-8 px-2"
              onClick={handleRefreshLeaderboard}
              disabled={isLoading}
            >
              Yenile
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-primary border-b border-primary/20">
                <th className="px-4 py-2 text-left">Sıra</th>
                <th className="px-4 py-2 text-left">Kullanıcı</th>
                <th className="px-4 py-2 text-center">Puan</th>
                <th className="px-4 py-2 text-center">Seviye</th>
                <th className="px-4 py-2 text-center">Başarılar</th>
              </tr>
            </thead>
            <tbody>
              {leaderboard.slice(0, displayCount).map((entry, index) => (
                <tr
                  key={`${entry.username}-${index}`}
                  className={`
                    border-b border-gray-800 transition-colors duration-200
                    ${entry.username === username ? 'bg-primary/10 hover:bg-primary/20' : 'hover:bg-black/50'}
                    ${index === 0 ? 'text-yellow-400' : ''}
                    ${index === 1 ? 'text-gray-300' : ''}
                    ${index === 2 ? 'text-amber-700' : ''}
                  `}
                >
                  <td className="px-4 py-3">
                    {index === 0 && <span className="mr-2">🥇</span>}
                    {index === 1 && <span className="mr-2">🥈</span>}
                    {index === 2 && <span className="mr-2">🥉</span>}
                    {index > 2 && `${index + 1}.`}
                  </td>
                  <td className="px-4 py-3 font-medium">
                    {entry.username}
                    {entry.username === username && (
                      <Badge className="ml-2 bg-primary/20 text-primary">Sen</Badge>
                    )}
                  </td>
                  <td className="px-4 py-3 text-center font-medium">
                    {Math.round(entry.score)}
                    <span className="text-xs text-gray-400">%</span>
                  </td>
                  <td className={`px-4 py-3 text-center ${getLevelColorClass(entry.level)}`}>
                    {entry.level}
                    {entry.level >= 10 && <span className="ml-1">🏆</span>}
                    {entry.level >= 15 && <span className="ml-1">💎</span>}
                  </td>
                  <td className="px-4 py-3 text-center">
                    {entry.achievements > 0 ? (
                      <span className="flex items-center justify-center">
                        {entry.achievements}
                        <span className="ml-1 text-xs">
                          {entry.achievements >= 5 ? "🏅" : "🎖️"}
                        </span>
                      </span>
                    ) : (
                      <span className="text-gray-500">-</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Kullanıcının sıralaması gizliyse ama sıralamada varsa */}
        {userIsHidden && (
          <div className="border-t border-gray-800 py-2 px-4 bg-primary/5 flex items-center justify-between">
            <div className="flex items-center">
              <span className="text-gray-400 mr-2">{userRank}.</span>
              <span className="font-medium">{username}</span>
              <Badge className="ml-2 bg-primary/20 text-primary">Sen</Badge>
            </div>
            <div className="flex items-center gap-6">
              <span className="font-medium">{Math.round(leaderboard[userRank - 1].score)}%</span>
              <span className={getLevelColorClass(leaderboard[userRank - 1].level)}>
                {leaderboard[userRank - 1].level}
              </span>
              <span>
                {leaderboard[userRank - 1].achievements}
                <span className="ml-1 text-xs">🎖️</span>
              </span>
            </div>
          </div>
        )}

        {leaderboard.length > 5 && (
          <button
            onClick={() => setExpanded(!expanded)}
            className="w-full text-center text-primary text-sm py-2 mt-2 hover:bg-primary/10 rounded-md transition-colors duration-200"
          >
            {expanded ? 'Tabloyu Küçült' : `Tümünü Göster (${leaderboard.length})`}
          </button>
        )}
      </CardContent>
    </Card>
  );
}
