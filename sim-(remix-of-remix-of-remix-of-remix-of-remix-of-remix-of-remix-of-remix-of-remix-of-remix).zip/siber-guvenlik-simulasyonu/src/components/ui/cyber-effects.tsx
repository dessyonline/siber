"use client";

import type React from "react";
import { useState, useEffect, useRef } from "react";
import { useInView } from "react-intersection-observer";
import { cn } from "@/lib/utils";

interface CyberContainerProps
  extends React.DetailedHTMLProps<
    React.HTMLAttributes<HTMLDivElement>,
    HTMLDivElement
  > {
  children: React.ReactNode;
  hoverEffect?: boolean;
}

export function CyberContainer({
  children,
  className,
  hoverEffect = false,
  ...props
}: CyberContainerProps) {
  return (
    <div
      className={cn(
        "relative border border-primary/30 bg-black rounded-lg overflow-hidden",
        hoverEffect ? "group transition-all duration-300 hover:border-primary/60" : "",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}

interface CyberGlitchTextProps {
  children: React.ReactNode;
  intensity?: "low" | "medium" | "high";
}

export function CyberGlitchText({
  children,
  intensity = "medium",
}: CyberGlitchTextProps) {
  const [glitchText, setGlitchText] = useState<string | null>(null);
  const originalText = typeof children === "string" ? children : "";
  const { ref, inView } = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  // Glitch efektini oluştur
  useEffect(() => {
    if (typeof children !== "string" || !inView) return;

    const intensityLevel = {
      low: 150,
      medium: 100,
      high: 50,
    };

    const interval = Math.max(30, intensityLevel[intensity] || 100);
    const originalStr = children as string;

    const glitchInterval = setInterval(() => {
      // Rastgele glitch oluşturma olasılığı
      const shouldGlitch = Math.random() < 0.3;
      if (shouldGlitch) {
        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+{}:<>?|";
        const randomIndex = Math.floor(Math.random() * originalStr.length);
        const randomChar = chars.charAt(Math.floor(Math.random() * chars.length));

        const newText = originalStr.substring(0, randomIndex) +
                      randomChar +
                      originalStr.substring(randomIndex + 1);

        setGlitchText(newText);

        // Orijinal metne hızlıca geri dön
        setTimeout(() => {
          setGlitchText(originalStr);
        }, 50);
      }
    }, interval);

    return () => clearInterval(glitchInterval);
  }, [children, inView, intensity]);

  return (
    <span ref={ref} className="inline-block">
      {glitchText !== null ? glitchText : children}
    </span>
  );
}

// Yeni eklenen siber saldırı animasyonu
export type CyberAttackType =
  | 'phishing'
  | 'malware'
  | 'ddos'
  | 'encryption'
  | 'injection'
  | 'network'
  | 'social'
  | 'bruteforce'
  | 'mitm'
  | 'ransomware'
  | 'mobile'
  | 'ai'
  | 'iot'
  | 'blockchain';

interface CyberAttackAnimationProps {
  type: CyberAttackType;
  active?: boolean;
  className?: string;
}

// Saldırı türüne göre animasyon konfigürasyonu
const getAttackConfig = (type: CyberAttackType) => {
  switch (type) {
    case 'phishing':
      return {
        color: 'bg-red-500',
        animClass: 'animate-ripple-fast',
        icon: '📧', // Email icon
        label: 'Oltalama Saldırısı'
      };
    case 'malware':
      return {
        color: 'bg-purple-500',
        animClass: 'animate-pulse',
        icon: '🦠', // Virus icon
        label: 'Kötücül Yazılım'
      };
    case 'ddos':
      return {
        color: 'bg-blue-500',
        animClass: 'animate-ripple',
        icon: '🌊', // Wave icon
        label: 'DDoS Saldırısı'
      };
    case 'encryption':
      return {
        color: 'bg-yellow-500',
        animClass: 'animate-pulse',
        icon: '🔒', // Lock icon
        label: 'Şifreleme Saldırısı'
      };
    case 'injection':
      return {
        color: 'bg-green-500',
        animClass: 'animate-ripple-fast',
        icon: '💉', // Injection icon
        label: 'Kod Enjeksiyonu'
      };
    case 'network':
      return {
        color: 'bg-cyan-500',
        animClass: 'animate-ripple',
        icon: '📡', // Antenna icon
        label: 'Ağ Saldırısı'
      };
    case 'social':
      return {
        color: 'bg-orange-500',
        animClass: 'animate-pulse',
        icon: '🧠', // Brain icon
        label: 'Sosyal Mühendislik'
      };
    case 'bruteforce':
      return {
        color: 'bg-indigo-500',
        animClass: 'animate-ripple-fast',
        icon: '🔨', // Hammer icon
        label: 'Kaba Kuvvet'
      };
    case 'mitm':
      return {
        color: 'bg-amber-500',
        animClass: 'animate-ripple',
        icon: '🕵️', // Detective icon
        label: 'Ortadaki Adam'
      };
    case 'ransomware':
      return {
        color: 'bg-rose-500',
        animClass: 'animate-pulse',
        icon: '💰', // Money bag icon
        label: 'Fidye Yazılımı'
      };
    case 'mobile':
      return {
        color: 'bg-amber-500',
        animClass: 'animate-ripple',
        icon: '📱', // Mobile icon
        label: 'Mobil Saldırı'
      };
    case 'ai':
      return {
        color: 'bg-violet-500',
        animClass: 'animate-pulse',
        icon: '🤖', // Robot icon
        label: 'AI Destekli Saldırı'
      };
    case 'iot':
      return {
        color: 'bg-teal-500',
        animClass: 'animate-ripple-fast',
        icon: '🏠', // House icon
        label: 'IoT Saldırısı'
      };
    case 'blockchain':
      return {
        color: 'bg-rose-500',
        animClass: 'animate-pulse',
        icon: '💰', // Money bag icon
        label: 'Blockchain Saldırısı'
      };
    default:
      return {
        color: 'bg-gray-500',
        animClass: 'animate-pulse',
        icon: '⚠️', // Warning icon
        label: 'Bilinmeyen Saldırı'
      };
  }
};

export function CyberAttackAnimation({
  type,
  active = true,
  className
}: CyberAttackAnimationProps) {
  const config = getAttackConfig(type);

  if (!active) return null;

  return (
    <div className={cn(
      "relative overflow-hidden rounded-md p-4 border border-white/10",
      config.color,
      className
    )}>
      <div className="absolute -inset-1 opacity-30 blur-xl">
        <div className={`h-full w-full ${config.animClass}`}>
          <div className="h-full w-full rounded-full bg-white/30"></div>
        </div>
      </div>

      <AttackParticles type={type} color={config.particleColor} />

      <div className="relative z-10 flex items-center space-x-3">
        <div className={`text-2xl ${config.animClass}`}>{config.icon}</div>
        <div>
          <div className="text-sm font-bold text-white">
            <CyberGlitchText intensity="high">{config.label}</CyberGlitchText>
          </div>
          <div className="text-xs text-white/70">Aktif Saldırı Tespit Edildi</div>
        </div>
      </div>
    </div>
  );
}

// Yeni eklenen saldırı parçacıkları animasyonu
interface AttackParticlesProps {
  type: string;
  color: string;
  count?: number;
}

export function AttackParticles({ type, color, count = 20 }: AttackParticlesProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Canvas'ı parent element boyutuna ayarla
    const resizeCanvas = () => {
      const parent = canvas.parentElement;
      if (parent) {
        canvas.width = parent.offsetWidth;
        canvas.height = parent.offsetHeight;
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Parçacık sınıfı
    class Particle {
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;

      constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * 3 + 1;

        // Saldırı türüne göre hareket deseni değişikliği
        if (type === 'phishing' || type === 'social') {
          // Doğrusal hareket
          this.speedX = Math.random() * 1 - 0.5;
          this.speedY = Math.random() * 1 - 0.5;
        } else if (type === 'ddos' || type === 'dos') {
          // Hızlı ve kaotik hareket
          this.speedX = Math.random() * 3 - 1.5;
          this.speedY = Math.random() * 3 - 1.5;
        } else if (type === 'ransomware' || type === 'encryption') {
          // Spiral hareket için temel hız
          this.speedX = Math.random() * 2 - 1;
          this.speedY = Math.random() * 2 - 1;
        } else if (type === 'bruteforce') {
          // Düz ancak sert hareketler
          this.speedX = Math.random() > 0.5 ? 1 : -1;
          this.speedY = Math.random() > 0.5 ? 1 : -1;
        } else {
          // Standart rastgele hareket
          this.speedX = Math.random() * 2 - 1;
          this.speedY = Math.random() * 2 - 1;
        }
      }

      update() {
        // Özel hareket desenleri
        if (type === 'ransomware' || type === 'encryption') {
          // Spiral hareket
          const angle = Math.atan2(this.y - canvas.height/2, this.x - canvas.width/2);
          this.x += Math.cos(angle) * this.speedX;
          this.y += Math.sin(angle) * this.speedY;
        } else {
          // Normal hareket
          this.x += this.speedX;
          this.y += this.speedY;
        }

        // Sınır kontrolü
        if (this.x > canvas.width || this.x < 0) {
          this.x = Math.random() * canvas.width;
        }
        if (this.y > canvas.height || this.y < 0) {
          this.y = Math.random() * canvas.height;
        }
      }

      draw() {
        if (!ctx) return;
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Parçacıkları oluştur
    const particles: Particle[] = [];
    for (let i = 0; i < count; i++) {
      particles.push(new Particle());
    }

    // Animasyon döngüsü
    function animate() {
      if (!ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (const particle of particles) {
        particle.update();
        particle.draw();
      }

      requestAnimationFrame(animate);
    }

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [type, color, count]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full z-0"
      style={{ opacity: 0.7 }}
    />
  );
}

// Matrix arka plan efekti
export function BackgroundMatrix({ density = 'medium', speed = 'medium' }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Matrix karakter seti
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%^&*()_+-=[]{}|;:,./<>?';

    // Boyut ve hız ayarları
    const densitySettings = {
      low: 25,
      medium: 45,
      high: 65
    };

    const speedSettings = {
      slow: 15,
      medium: 30,
      fast: 50
    };

    const fontSize = 10;
    const columns = Math.floor(canvas.width / fontSize);

    // Her bir sütun için düşme hızları
    const drops = Array(columns).fill(1);

    // Animasyon döngüsü
    function draw() {
      // Hafif saydamlık ekleyelim ki kalıcı etki oluşsun
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Her bir karakteri çizelim
      ctx.fillStyle = '#0F0'; // Matrix yeşili
      ctx.font = `${fontSize}px monospace`;

      for (let i = 0; i < drops.length; i++) {
        // Rastgele karakter seçelim
        const text = chars[Math.floor(Math.random() * chars.length)];

        // i * fontSize pozisyonuna karakter yazdıralım
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        // Aşağıya düşme
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }

        drops[i]++;
      }
    }

    // Animasyon döngüsünü başlatalım
    const densityValue = densitySettings[density as keyof typeof densitySettings] || densitySettings.medium;
    const speedValue = speedSettings[speed as keyof typeof speedSettings] || speedSettings.medium;

    const interval = setInterval(draw, 1000 / speedValue);

    // Temizleme işlevi
    return () => clearInterval(interval);
  }, [density, speed]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full z-0 opacity-20"
    />
  );
}

// Siber Radar Animasyonu
export function CyberRadar({ className }: { className?: string }) {
  return (
    <div className={cn("relative h-40 w-40 rounded-full", className)}>
      <div className="absolute inset-0 rounded-full border border-green-500/30 bg-green-500/5"></div>
      <div className="absolute inset-4 rounded-full border border-green-500/40 bg-green-500/5"></div>
      <div className="absolute inset-8 rounded-full border border-green-500/50 bg-green-500/5"></div>
      <div className="absolute inset-12 rounded-full border border-green-500/60 bg-green-500/5"></div>
      <div className="absolute inset-16 rounded-full border border-green-500/70"></div>

      <div className="absolute inset-0 origin-center">
        <div className="absolute h-1/2 w-1 left-1/2 -ml-0.5 top-0 origin-bottom animate-[spin_4s_linear_infinite]">
          <div className="h-full w-full bg-gradient-to-t from-transparent to-green-500 opacity-70"></div>
        </div>
      </div>

      {/* Nokta animasyonları */}
      <div className="absolute top-1/4 right-1/4 h-2 w-2 rounded-full bg-green-500 animate-ping"></div>
      <div className="absolute bottom-1/3 left-1/3 h-1.5 w-1.5 rounded-full bg-red-500 animate-ping animation-delay-500"></div>
    </div>
  );
}

// Hacker Terminal Animasyonu
export function HackerTerminal({ className }: { className?: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [text, setText] = useState<string[]>([
    "> Initializing cyber attack simulation...",
    "> Scanning system vulnerabilities...",
    "> Identifying target points...",
    "> Preparing infiltration vectors..."
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setText(prev => {
        // Yeni komutlar ekle
        const newCommands = [
          "> Attempting SSH brute force...",
          "> Testing firewall defenses...",
          "> Searching for open ports...",
          "> Checking for outdated software...",
          "> Deploying packet sniffer...",
          "> Access point detected...",
          "> Injecting malicious payload...",
          "> Bypassing security protocols...",
          "> Escalating privileges...",
          "> Establishing backdoor connection..."
        ];

        const randomCommand = newCommands[Math.floor(Math.random() * newCommands.length)];

        // 5 satır limit, en eski satırı çıkar
        const updated = [...prev, randomCommand];
        if (updated.length > 5) {
          updated.shift();
        }

        return updated;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={cn("bg-black border border-green-500/30 rounded p-2 font-mono text-xs", className)} ref={containerRef}>
      {text.map((line, index) => (
        <div key={index} className="text-green-500">
          {line}
          {index === text.length - 1 && <span className="animate-pulse ml-1">_</span>}
        </div>
      ))}
    </div>
  );
}
