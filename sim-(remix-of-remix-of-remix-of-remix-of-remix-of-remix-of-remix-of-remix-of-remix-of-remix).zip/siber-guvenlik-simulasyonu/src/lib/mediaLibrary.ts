import { type MediaContent, MediaType } from "@/components/game/MultimediaViewer";
import type { ScenarioType } from "@/store/gameStore";

// Her senaryo türüne bağlı multimedya içerikleri
interface MediaLibrary {
  [key: string]: MediaContent[];
}

// Medya içerik kütüphanesi
export const mediaLibrary: MediaLibrary = {
  // Oltalama (Phishing) Senaryoları için medya içerikleri
  "phishing": [
    {
      id: "phishing-diagram",
      title: "Oltalama Saldırısı Nasıl Çalışır?",
      description: "Oltalama saldırıları genellikle sahte e-postalar, mesajlar veya web siteleri aracılığıyla gerçekleştirilir. Bu metin, tipik bir oltalama saldırısının adımlarını açıklamaktadır. Oltalama saldırıları genellikle şunları içerir: 1) Güvenilir bir kurum gibi görünen sahte iletişim, 2) Aciliyet veya korku yaratmak, 3) Kişisel bilgi talep etmek, 4) Sahte web siteleri veya formlar kullanmak.",
      type: "text",
      source: "",
      creditText: "Siber Güvenlik Eğitimi",
      tags: ["Oltalama", "E-posta Güvenliği", "Sosyal Mühendislik"]
    },
    {
      id: "phishing-examples",
      title: "Oltalama E-postası Örnekleri",
      description: "Gerçek oltalama e-postalarının tipik özellikleri ve bunları nasıl tespit edebileceğiniz hakkında bilgiler. Adres çubuğunu ve gönderici bilgilerini her zaman kontrol etmek önemlidir. Şüpheli işaretler: Dilbilgisi hataları, genel hitap şekli, şüpheli bağlantılar, aciliyet hissi uyandırma, şüpheli ekler, beklenmedik iletişim, şifre veya kişisel bilgi talepleri.",
      type: "text",
      source: "",
      creditText: "Siber Güvenlik Kurumu",
      tags: ["Oltalama", "E-posta Güvenliği", "Tespit Yöntemleri"]
    },
    {
      id: "social-engineering",
      title: "Sosyal Mühendislik Teknikleri",
      description: "Sosyal mühendislik, insanları manipüle ederek bilgi elde etme sanatıdır. Yaygın sosyal mühendislik teknikleri: Pretexting (bahane uydurma), Baiting (tuzak kurma), Quid pro quo (karşılık bekleme), Tailgating (izinsiz takip) ve Phishing (oltalama). Bu teknikleri tanımak için eleştirel düşünün, beklenmedik istekleri doğrulayın ve temel güvenlik prosedürlerinden asla taviz vermeyin.",
      type: "text",
      source: "",
      creditText: "Siber Güvenlik Akademisi",
      tags: ["Oltalama", "Sosyal Mühendislik", "Güvenlik İhlali"]
    }
  ],

  // Şifre Güvenliği Senaryoları
  "password": [
    {
      id: "password-strength",
      title: "Güçlü Şifre Oluşturma",
      description: "Güçlü şifrelerin özellikleri ve nasıl oluşturulacağı hakkında bilgiler. Karmaşık ve benzersiz şifreler oluşturmak, hesaplarınızı korumak için kritik öneme sahiptir. Güçlü bir şifre en az 12 karakter uzunluğunda olmalı, büyük ve küçük harfler, sayılar ve özel karakterler içermeli, kolayca tahmin edilebilir bilgiler (doğum tarihi gibi) içermemeli ve her hesap için farklı olmalıdır.",
      type: "text",
      source: "",
      creditText: "Şifre Güvenliği İnisiyatifi",
      tags: ["Şifre Güvenliği", "Güçlü Şifre", "Kimlik Doğrulama"]
    },
    {
      id: "two-factor-auth",
      title: "İki Faktörlü Kimlik Doğrulama",
      description: "İki faktörlü kimlik doğrulamanın önemi ve nasıl kullanılacağı. Bu ek güvenlik katmanı, şifreniz ele geçirilse bile hesaplarınızı korur. 2FA, şifrenize ek olarak ikinci bir doğrulama faktörü kullanır: SMS kodu, kimlik doğrulama uygulaması, güvenlik anahtarı veya biyometrik doğrulama. Bu yöntem hesaplarınızın güvenliğini önemli ölçüde artırır.",
      type: "text",
      source: "",
      creditText: "Güvenlik Araştırmaları Merkezi",
      tags: ["2FA", "MFA", "Kimlik Doğrulama", "Güvenlik"]
    },
    {
      id: "password-manager",
      title: "Şifre Yöneticisi Kullanımı",
      description: "Şifre yöneticilerinin çalışma prensibi ve güvenli kullanımı. Şifre yöneticileri, farklı hesaplar için benzersiz ve karmaşık şifreler kullanmanıza olanak tanır. Bu araçlar şifrelerinizi güvenli bir şekilde şifrelenmiş bir veritabanında saklar, karmaşık ve güçlü şifreler oluşturur, otomatik doldurma özelliği sunar ve çoklu cihaz senkronizasyonu sağlar. Yalnızca tek bir ana şifreyi hatırlamanız yeterlidir.",
      type: "text",
      source: "",
      creditText: "Dijital Güvenlik Portalı",
      tags: ["Şifre Yöneticisi", "Şifre Güvenliği", "Araçlar"]
    }
  ],

  // Yazılım Güvenliği Senaryoları
  "software": [
    {
      id: "software-updates",
      title: "Yazılım Güncellemelerinin Önemi",
      description: "Yazılım güncellemelerinin siber güvenlik açısından neden kritik olduğu ve güncel kalmanın yolları. Güncellemeler genellikle kritik güvenlik açıklarını giderir. Bu güncellemeler, keşfedilen güvenlik açıklarını kapatır, bilgisayar korsanlarının sistemlerinize sızmasını engeller, performans iyileştirmeleri sağlar ve yeni özellikler sunar. Otomatik güncellemeleri etkinleştirin ve düzenli olarak yazılımlarınızı kontrol edin.",
      type: "text",
      source: "",
      creditText: "Yazılım Güvenliği Derneği",
      tags: ["Yazılım Güncellemeleri", "Yama Yönetimi", "Güvenlik Açıkları"]
    },
    {
      id: "secure-download",
      title: "Güvenli İndirme Uygulamaları",
      description: "Yazılım ve dosyaları güvenli bir şekilde indirmek için önerilen yöntemler. Güvenilir kaynaklardan indirme yapmak ve indirilen dosyaları virüs taramasından geçirmek önemlidir. Resmi uygulama mağazalarını ve geliştiricilerin web sitelerini kullanın, indirmeden önce dosya uzantılarını kontrol edin, kullanıcı yorumlarını ve değerlendirmeleri okuyun, HTTPS ile güvenli bağlantı kullandığınızdan emin olun.",
      type: "text",
      source: "",
      creditText: "Dijital Güvenlik Enstitüsü",
      tags: ["Güvenli İndirme", "Dosya Doğrulama", "Malware Koruması"]
    },
    {
      id: "malware-types",
      title: "Kötücül Yazılım Türleri",
      description: "Yaygın kötücül yazılım türleri ve bunların çalışma prensipleri. Virüsler: diğer dosyalara bulaşır. Trojanlar: yararlı yazılım gibi görünüp arka planda zararlı işlemler yapar. Solucanlar: kendini kopyalayarak yayılır. Fidye yazılımı: dosyalarınızı şifreler ve şifre çözme için fidye ister. Casus yazılım: kullanıcı aktivitelerini izler. Reklam yazılımı: istenmeyen reklamlar gösterir. Rootkit: sistem üzerinde gizli erişim sağlar.",
      type: "text",
      source: "",
      creditText: "Antivirüs Araştırma Laboratuvarı",
      tags: ["Malware", "Virüs", "Ransomware", "Trojan"]
    }
  ],

  // Sosyal Mühendislik Senaryoları
  "social": [
    {
      id: "social-engineering-tactics",
      title: "Sosyal Mühendislik Taktikleri",
      description: "Siber suçluların kullandığı yaygın sosyal mühendislik teknikleri ve bunları nasıl tespit edebileceğiniz. Sosyal mühendislik, teknik güvenlik önlemlerini atlatmak için insan psikolojisini kullanır. Temel taktikler: Otorite kullanma (yetkili biri gibi davranma), Aciliyet yaratma (hızlı karar vermeye zorlama), Korku uyandırma (tehdit veya kayıp korkusu yaratma), Yardımseverlik gösterme (yardım etme bahanesiyle bilgi alma), Ortak fikir/ilgi alanı geliştirme (güven oluşturmak için benzerlikler kurma).",
      type: "text",
      source: "",
      creditText: "Siber İstihbarat Merkezi",
      tags: ["Sosyal Mühendislik", "Manipülasyon", "Dolandırıcılık"]
    },
    {
      id: "social-engineering-defense",
      title: "Sosyal Mühendisliğe Karşı Savunma",
      description: "Sosyal mühendislik saldırılarına karşı savunma teknikleri ve farkındalık eğitimi. Şüpheci olmak ve beklenmedik istekleri doğrulamak önemlidir. Savunma teknikleri: Beklenmedik iletişimleri doğrulayın, kişisel bilgileri paylaşmadan önce iki kez düşünün, duygusal manipülasyona karşı dikkatli olun, acil talepler karşısında mantıklı düşünün, şirket politikalarını harfiyen uygulayın, düzenli güvenlik eğitimleri alın ve farkındalığınızı güncel tutun.",
      type: "text",
      source: "",
      creditText: "Siber Savunma Akademisi",
      tags: ["Sosyal Mühendislik", "Savunma", "Farkındalık"]
    },
    {
      id: "pretexting-explained",
      title: "Pretexting (Bahane Uydurma) Tekniği",
      description: "Pretexting tekniğinin nasıl kullanıldığı ve kendinizi nasıl koruyabileceğiniz. Sahte kimlikler ve senaryolar kullanarak bilgi toplama yöntemidir. Bu teknikte, saldırgan önceden hazırladığı bir hikaye ve sahte kimlik ile kurbanın güvenini kazanmaya çalışır. Örneğin, BT destek personeli, banka görevlisi veya araştırmacı gibi rollerle hassas bilgilere erişmek isterler. Korunmak için kimlik doğrulama prosedürlerini uygulayın ve beklenmedik aramaları veya ziyaretçileri doğrulayın.",
      type: "text",
      source: "",
      creditText: "Güvenlik Eğitim Merkezi",
      tags: ["Pretexting", "Sosyal Mühendislik", "Dolandırıcılık"]
    }
  ],

  // Terminal Güvenliği Senaryoları
  "terminal": [
    {
      id: "terminal-basics",
      title: "Terminal Güvenlik Temelleri",
      description: "Linux terminalinde temel güvenlik komutları ve uygulamaları. Terminal güvenliği, sistem yöneticileri için kritik bir beceridir. Temel güvenlik komutları: 'chmod' (dosya izinlerini yönetme), 'chown' (dosya sahipliğini değiştirme), 'sudo' (yönetici ayrıcalıklarıyla komut çalıştırma), 'passwd' (şifre değiştirme), 'ssh' (güvenli uzak bağlantı). Güvenli terminal kullanımı için en az ayrıcalık ilkesini benimsemeli ve komut çalıştırmadan önce içeriğini anlamalısınız.",
      type: "text",
      source: "",
      creditText: "Linux Güvenlik Vakfı",
      tags: ["Terminal", "Linux", "Komut Satırı", "Güvenlik"]
    },
    {
      id: "terminal-security-tools",
      title: "Terminal Güvenlik Araçları",
      description: "Linux ve Unix sistemlerde kullanılabilecek güvenlik araçları ve komutları. Bu araçlar, sistemleri izlemek, güvenlik açıklarını tespit etmek ve saldırıları önlemek için kullanılır. Önemli güvenlik araçları: 'netstat' (ağ bağlantılarını izleme), 'iptables' (güvenlik duvarı yapılandırma), 'fail2ban' (brute force saldırılarını engelleme), 'lynis' (güvenlik denetimi), 'nmap' (ağ tarama), 'tcpdump' (ağ trafiği analizi), 'snort' (saldırı tespit sistemi), 'clamav' (virüs tarama).",
      type: "text",
      source: "",
      creditText: "Açık Kaynak Güvenlik İnisiyatifi",
      tags: ["Terminal", "Güvenlik Araçları", "Linux"]
    },
    {
      id: "terminal-best-practices",
      title: "Terminal Güvenlik İyi Uygulamaları",
      description: "Terminal kullanırken dikkat edilmesi gereken güvenlik uygulamaları ve ipuçları. Yetki yükseltme, şifreleme ve kaynakları doğrulama konularında en iyi uygulamalar. Güvenli terminal kullanımı için: Root hesabı yerine sudo kullanın, SSH için anahtar tabanlı kimlik doğrulama kullanın, güçlü parolalar belirleyin, terminal geçmişini temizleyin, komut dosyalarını çalıştırmadan önce inceleyin, sistemin güncel olduğundan emin olun ve yapılandırma dosyalarının izinlerini sıkılaştırın.",
      type: "text",
      source: "",
      creditText: "Sistem Yöneticileri Topluluğu",
      tags: ["Terminal", "İyi Uygulamalar", "Güvenlik"]
    }
  ],

  // Masaüstü Güvenliği Senaryoları
  "desktop": [
    {
      id: "desktop-security-basics",
      title: "Masaüstü Güvenlik Temelleri",
      description: "Masaüstü bilgisayarlarda temel güvenlik uygulamaları ve korunma yöntemleri. İşletim sistemi güncelleştirmeleri, antivirüs yazılımı ve güvenlik duvarı yapılandırması gibi konulara odaklanır. Masaüstü bilgisayarınızı korumak için: İşletim sistemi ve yazılımları güncel tutun, güçlü şifreler kullanın, güvenlik duvarını etkinleştirin, antivirüs yazılımı kullanın, düzenli yedekleme yapın, bilgisayarınızı kilitlemeyi alışkanlık haline getirin ve şüpheli e-postaları ve bağlantıları açmaktan kaçının.",
      type: "text",
      source: "",
      creditText: "Bilgisayar Güvenliği Merkezi",
      tags: ["Masaüstü Güvenliği", "İşletim Sistemi", "Antivirüs"]
    },
    {
      id: "secure-browsing",
      title: "Güvenli Web Tarama",
      description: "Web tarayıcılarında güvenli gezinme teknikleri ve ayarları. Tarayıcı uzantıları, çerezler ve pop-up engelleyiciler hakkında öneriler içerir. Güvenli web tarama için: Tarayıcınızı güncel tutun, reklam engelleyiciler ve anti-takip uzantıları kullanın, gizlilik ayarlarını yapılandırın, HTTPS bağlantılarını tercih edin, bilinmeyen sitelerden dosya indirmekten kaçının, düzenli olarak çerezleri ve tarama geçmişini temizleyin ve şüpheli web sitelerinden uzak durun.",
      type: "text",
      source: "",
      creditText: "İnternet Güvenliği Vakfı",
      tags: ["Web Tarayıcı", "Güvenli Gezinme", "Tarayıcı Ayarları"]
    },
    {
      id: "desktop-privacy",
      title: "Masaüstü Gizlilik Ayarları",
      description: "İşletim sistemlerinde gizlilik ayarlarının yapılandırılması ve kişisel verilerin korunması. Windows ve macOS'ta gizlilik ayarlarını nasıl yöneteceğinizi açıklar. İşletim sistemi gizlilik ayarlarınızı optimum hale getirmek için: Konum takibini kapatın veya sınırlayın, uygulama izinlerini gözden geçirin, teşhis veri toplama ayarlarını sınırlayın, kamera ve mikrofon erişimini kontrol edin, reklam kimliğini devre dışı bırakın ve uygulama geçmişi özelliğini kapatın veya sınırlayın.",
      type: "text",
      source: "",
      creditText: "Dijital Haklar Platformu",
      tags: ["Gizlilik", "Veri Koruma", "İşletim Sistemi"]
    }
  ],

  // Ağ Güvenliği Senaryoları
  "network": [
    {
      id: "network-threats",
      title: "Ağ Güvenlik Tehditleri",
      description: "Yaygın ağ güvenlik tehditleri ve saldırı teknikleri hakkında bilgiler. DDoS saldırıları: Sistemi aşırı yükleyerek hizmet dışı bırakır. Ortadaki adam saldırıları: İletişim arasına girerek verileri dinler veya değiştirir. Paket koklama: Ağ trafiğini izleyerek hassas bilgileri yakalar. Port tarama: Açık portları tespit ederek zayıf noktaları bulur. ARP zehirlemesi: Yerel ağda veri yönlendirmesini manipüle eder. DNS zehirlemesi: Alan adı çözümlemelerini sahte hedeflere yönlendirir.",
      type: "text",
      source: "",
      creditText: "Ağ Güvenliği Enstitüsü",
      tags: ["Ağ Güvenliği", "Saldırı Teknikleri", "Tehditler"]
    },
    {
      id: "firewall-basics",
      title: "Güvenlik Duvarı Temelleri",
      description: "Güvenlik duvarlarının çalışma prensibi ve etkin yapılandırması. Kişisel ve kurumsal güvenlik duvarlarının kullanımı ve konfigürasyonu hakkında bilgiler içerir. Güvenlik duvarları, ağa giren ve çıkan trafiği belirli kurallar çerçevesinde izleyip filtreleyerek koruma sağlar. Stateful inspection, paket filtreleme, uygulama katmanı filtreleme gibi yöntemler kullanır. Etkili koruma için varsayılan reddetme politikası uygulanmalı ve düzenli olarak kurallar güncellenmelidir.",
      type: "text",
      source: "",
      creditText: "Siber Savunma Laboratuvarı",
      tags: ["Güvenlik Duvarı", "Ağ Güvenliği", "Yapılandırma"]
    },
    {
      id: "secure-wifi",
      title: "Güvenli Wi-Fi Ağları",
      description: "Kablosuz ağları güvence altına almak için önerilen uygulamalar ve ayarlar. Wi-Fi şifreleme, misafir ağları ve güvenli yapılandırma hakkında kapsamlı bilgiler içerir. Güvenli bir Wi-Fi ağı için: WPA3 veya en azından WPA2 şifreleme kullanın, güçlü ve benzersiz parolalar belirleyin, varsayılan router şifresini değiştirin, ağ adını (SSID) yayınlamayı kapatmayı değerlendirin, misafirler için ayrı bir ağ oluşturun ve firmware güncellemelerini düzenli olarak yapın.",
      type: "text",
      source: "",
      creditText: "Kablosuz Güvenlik Birliği",
      tags: ["Wi-Fi", "Kablosuz Ağ", "Ağ Güvenliği"]
    }
  ],

  // Son olarak, Genel kategorisi
  "general": [
    {
      id: "cyber-security-overview",
      title: "Siber Güvenlik Genel Bakış",
      description: "Siber güvenliğin temel kavramları ve bileşenleri hakkında kapsamlı bir giriş. Tehdit türleri, savunma katmanları ve güvenlik ilkeleri gibi temel konuları içerir. Siber güvenlik, bilgi ve sistemleri yetkisiz erişime, değişikliğe ve hasara karşı koruma uygulamasıdır. Savunmanın derinliği, en az ayrıcalık ilkesi, veri gizliliği ve bütünlüğü, güncelleme ve yama yönetimi, kimlik doğrulama ve yetkilendirme, güvenlik duvarları ve saldırı tespit sistemleri temel bileşenlerdir.",
      type: "text",
      source: "",
      creditText: "Siber Güvenlik Akademisi",
      tags: ["Siber Güvenlik", "Temel Kavramlar", "Eğitim"]
    },
    {
      id: "emerging-threats",
      title: "Gelişen Siber Tehditler",
      description: "Son dönemde ortaya çıkan siber tehditler ve savunma stratejileri. Fidye yazılımları, hedefli saldırılar ve tedarik zinciri saldırıları gibi güncel tehditleri kapsar. Yeni nesil tehditler arasında: Gelişmiş fidye yazılımı saldırıları (çifte şantaj taktiği), ileri düzey kalıcı tehditler (APT), nesnelerin interneti (IoT) cihazlarına yönelik saldırılar, tedarik zinciri saldırıları, yapay zeka destekli saldırılar, bulut hizmetlerine yönelik tehditler, akıllı telefon hedefli zararlı yazılımlar ve kimlik avı saldırıları yer almaktadır.",
      type: "text",
      source: "",
      creditText: "Tehdit İstihbarat Merkezi",
      tags: ["Siber Tehditler", "Trendler", "Savunma Stratejileri"]
    },
    {
      id: "incident-response",
      title: "Siber Olay Müdahale",
      description: "Siber güvenlik olaylarına etkili müdahale ve yönetim prensipleri. Olay tespit, sınırlama, ortadan kaldırma ve kurtarma aşamalarını içeren kapsamlı bir rehber. Etkili bir siber olay müdahale planı şu aşamaları içerir: 1) Hazırlık: Planlar ve prosedürler geliştirme, 2) Tespit ve Analiz: Olayı tanıma ve değerlendirme, 3) Sınırlama: Zararın yayılmasını önleme, 4) Ortadan Kaldırma: Tehdidi sistemlerden çıkarma, 5) Kurtarma: Sistemleri normal operasyona döndürme, 6) Öğrenilen Dersler: Olayı analiz etme ve gelecekteki olayları önlemek için iyileştirmeler yapma.",
      type: "text",
      source: "",
      creditText: "Olay Müdahale Konsorsiyumu",
      tags: ["Olay Müdahale", "Kriz Yönetimi", "Güvenlik Operasyonları"]
    }
  ]
};

// Senaryo türüne göre medya içeriklerini getirme
export function getMediaForScenarioType(type: ScenarioType | string): MediaContent[] {
  return mediaLibrary[type] || mediaLibrary.general;
}

// ID'ye göre medya içeriği bulma (tüm kütüphanede arama yapar)
export function findMediaById(id: string): MediaContent | null {
  for (const category in mediaLibrary) {
    const media = mediaLibrary[category].find(item => item.id === id);
    if (media) return media;
  }
  return null;
}

// Etiketlere göre medya içeriklerini bulma
export function findMediaByTags(tags: string[]): MediaContent[] {
  const results: MediaContent[] = [];

  for (const category in mediaLibrary) {
    const categoryMedia = mediaLibrary[category];
    for (const media of categoryMedia) {
      if (media.tags?.some(tag => tags.includes(tag))) {
        results.push(media);
      }
    }
  }

  return results;
}
