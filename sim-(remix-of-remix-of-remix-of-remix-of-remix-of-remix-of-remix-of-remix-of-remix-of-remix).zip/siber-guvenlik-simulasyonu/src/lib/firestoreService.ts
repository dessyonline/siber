import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  query,
  where,
  orderBy,
  limit,
  type Timestamp,
  type DocumentData,
  serverTimestamp
} from 'firebase/firestore';
import { db } from './firebase';
import type { Scenario, ScenarioType } from '@/store/gameStore';

// Kullanıcı ilerlemesi için tipler
export interface UserProgress {
  userId: string;
  username: string;
  displayName: string;
  completedScenarios: string[];
  score: number;
  riskLevel: number;
  level: 'beginner' | 'intermediate' | 'advanced';
  lastActive: Timestamp;
  answeredQuestions: {
    scenarioId: string;
    selectedOptionId: string;
    isCorrect: boolean;
    timestamp: Timestamp;
  }[];
  certificates: {
    id: string;
    name: string;
    issueDate: Timestamp;
    score: number;
  }[];
}

// Kullanıcı ilerlemesi al
export const getUserProgress = async (userId: string): Promise<UserProgress | null> => {
  try {
    const userDocRef = doc(db, 'userProgress', userId);
    const userDocSnap = await getDoc(userDocRef);

    if (userDocSnap.exists()) {
      return userDocSnap.data() as UserProgress;
    }

    return null;
  } catch (error) {
    console.error('Kullanıcı ilerlemesi alınırken hata:', error);
    return null;
  }
};

// Kullanıcı ilerlemesini güncelle
export const updateUserProgress = async (userId: string, progress: Partial<UserProgress>): Promise<boolean> => {
  try {
    const userDocRef = doc(db, 'userProgress', userId);
    const userDocSnap = await getDoc(userDocRef);

    if (userDocSnap.exists()) {
      // Mevcut belgeyi güncelle
      await updateDoc(userDocRef, {
        ...progress,
        lastActive: serverTimestamp()
      });
    } else {
      // Yeni belge oluştur
      await setDoc(userDocRef, {
        userId,
        username: progress.username || '',
        displayName: progress.displayName || '',
        completedScenarios: progress.completedScenarios || [],
        score: progress.score || 0,
        riskLevel: progress.riskLevel || 0,
        level: progress.level || 'beginner',
        lastActive: serverTimestamp(),
        answeredQuestions: progress.answeredQuestions || [],
        certificates: progress.certificates || []
      });
    }

    return true;
  } catch (error) {
    console.error('Kullanıcı ilerlemesi güncellenirken hata:', error);
    return false;
  }
};

// Senaryo cevabını kaydet
export const saveScenarioAnswer = async (
  userId: string,
  scenarioId: string,
  selectedOptionId: string,
  isCorrect: boolean
): Promise<boolean> => {
  try {
    const userDocRef = doc(db, 'userProgress', userId);
    const userDocSnap = await getDoc(userDocRef);

    const answerData = {
      scenarioId,
      selectedOptionId,
      isCorrect,
      timestamp: serverTimestamp()
    };

    if (userDocSnap.exists()) {
      const userData = userDocSnap.data() as UserProgress;
      const answeredQuestions = userData.answeredQuestions || [];

      // Eğer bu senaryoya daha önce cevap verilmişse, onu güncelle
      const existingAnswerIndex = answeredQuestions.findIndex(a => a.scenarioId === scenarioId);

      if (existingAnswerIndex >= 0) {
        answeredQuestions[existingAnswerIndex] = answerData;
      } else {
        answeredQuestions.push(answerData);
      }

      // Tamamlanan senaryoları güncelle
      const completedScenarios = userData.completedScenarios || [];
      if (!completedScenarios.includes(scenarioId)) {
        completedScenarios.push(scenarioId);
      }

      // Skoru güncelle
      const score = answeredQuestions.filter(a => a.isCorrect).length;

      await updateDoc(userDocRef, {
        answeredQuestions,
        completedScenarios,
        score,
        lastActive: serverTimestamp()
      });
    } else {
      // Yeni belge oluştur
      await setDoc(userDocRef, {
        userId,
        username: '',
        displayName: '',
        completedScenarios: [scenarioId],
        score: isCorrect ? 1 : 0,
        riskLevel: 0,
        level: 'beginner',
        lastActive: serverTimestamp(),
        answeredQuestions: [answerData],
        certificates: []
      });
    }

    return true;
  } catch (error) {
    console.error('Senaryo cevabı kaydedilirken hata:', error);
    return false;
  }
};

// Sertifika ekle
export const addCertificate = async (
  userId: string,
  certificateName: string,
  score: number
): Promise<boolean> => {
  try {
    const userDocRef = doc(db, 'userProgress', userId);
    const userDocSnap = await getDoc(userDocRef);

    const certificateData = {
      id: `cert-${Date.now()}`,
      name: certificateName,
      issueDate: serverTimestamp(),
      score
    };

    if (userDocSnap.exists()) {
      const userData = userDocSnap.data() as UserProgress;
      const certificates = userData.certificates || [];
      certificates.push(certificateData);

      await updateDoc(userDocRef, {
        certificates,
        lastActive: serverTimestamp()
      });
    } else {
      // Kullanıcı ilerlemesi bulunamadı
      return false;
    }

    return true;
  } catch (error) {
    console.error('Sertifika eklenirken hata:', error);
    return false;
  }
};

// Kullanıcı seviyesini güncelle
export const updateUserLevel = async (
  userId: string,
  level: 'beginner' | 'intermediate' | 'advanced'
): Promise<boolean> => {
  try {
    const userDocRef = doc(db, 'userProgress', userId);
    const userDocSnap = await getDoc(userDocRef);

    if (userDocSnap.exists()) {
      await updateDoc(userDocRef, {
        level,
        lastActive: serverTimestamp()
      });
      return true;
    }
    return false;
  } catch (error) {
    console.error('Kullanıcı seviyesi güncellenirken hata:', error);
    return false;
  }
};

// En iyi skor tablosunu getir
export const getLeaderboard = async (limit = 10): Promise<DocumentData[]> => {
  try {
    const q = query(
      collection(db, 'userProgress'),
      orderBy('score', 'desc'),
      limit(limit)
    );

    const querySnapshot = await getDocs(q);
    const leaderboard = querySnapshot.docs.map(doc => doc.data());

    return leaderboard;
  } catch (error) {
    console.error('Skor tablosu alınırken hata:', error);
    return [];
  }
};

// Belirli türdeki senaryoları getir
export const getScenariosByType = async (type: ScenarioType): Promise<DocumentData[]> => {
  try {
    const q = query(
      collection(db, 'scenarios'),
      where('type', '==', type)
    );

    const querySnapshot = await getDocs(q);
    const scenarios = querySnapshot.docs.map(doc => doc.data());

    return scenarios;
  } catch (error) {
    console.error('Senaryolar alınırken hata:', error);
    return [];
  }
};

// Yeni senaryo ekle (admin için)
export const addScenario = async (scenario: Omit<Scenario, 'completed' | 'selectedOption'>): Promise<boolean> => {
  try {
    const scenarioDocRef = doc(db, 'scenarios', scenario.id);
    await setDoc(scenarioDocRef, {
      ...scenario,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    return true;
  } catch (error) {
    console.error('Senaryo eklenirken hata:', error);
    return false;
  }
};

// Senaryoyu güncelle (admin için)
export const updateScenario = async (
  scenarioId: string,
  updates: Partial<Scenario>
): Promise<boolean> => {
  try {
    const scenarioDocRef = doc(db, 'scenarios', scenarioId);
    await updateDoc(scenarioDocRef, {
      ...updates,
      updatedAt: serverTimestamp()
    });

    return true;
  } catch (error) {
    console.error('Senaryo güncellenirken hata:', error);
    return false;
  }
};

// Kullanıcı geri bildirimlerini kaydet
export const saveFeedback = async (
  userId: string,
  scenarioId: string,
  rating: number,
  comment?: string
): Promise<boolean> => {
  try {
    const feedbackDocRef = doc(db, 'feedback', `${userId}_${scenarioId}`);
    await setDoc(feedbackDocRef, {
      userId,
      scenarioId,
      rating,
      comment: comment || '',
      timestamp: serverTimestamp()
    });

    return true;
  } catch (error) {
    console.error('Geri bildirim kaydedilirken hata:', error);
    return false;
  }
};
