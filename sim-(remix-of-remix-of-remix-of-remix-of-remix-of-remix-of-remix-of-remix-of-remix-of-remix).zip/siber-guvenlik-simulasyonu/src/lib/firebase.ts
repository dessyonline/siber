// Firebase yapılandırması ve kimlik doğrulama işlevleri
import { initializeApp, getApps, getApp, type FirebaseApp } from 'firebase/app';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
  type User,
  type Auth,
  type FirebaseError,
} from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';

// API anahtarı sorunu nedeniyle mock servis kullanacağız
const USE_MOCK_SERVICE = true;

// Firebase config - Geliştirme ortamı için kullanılacak yapılandırma
const firebaseConfig = {
  apiKey: "AIzaSyB_segona2ZbTl81N4k-9e7kRxzqRQw",
  authDomain: "demo-project.firebaseapp.com",
  projectId: "demo-project",
  storageBucket: "demo-project.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890"
};

// Mock kullanıcı veri saklama
type MockUser = {
  uid: string;
  email: string;
  displayName: string;
  password: string;
};

// Mock servis için kullanıcı depolama
const mockUsers: MockUser[] = [
  // Varsayılan test kullanıcısı
  {
    uid: 'test-user-1',
    email: 'test@example.com',
    password: 'password123',
    displayName: 'Test Kullanıcı'
  }
];
let currentMockUser: MockUser | null = null;

// Geliştirme sırasında log mesajlarını gösterme yardımcı fonksiyonu
const logDev = (message: string, data?: Record<string, unknown>) => {
  if (process.env.NODE_ENV !== 'production') {
    // eslint-disable-next-line no-console
    console.log(`[Mock Firebase] ${message}`, data || '');
  }
};

// Mock auth için basit bir User uyarlaması
const createMockAuthUser = (mockUser: MockUser): User => {
  return {
    uid: mockUser.uid,
    email: mockUser.email,
    displayName: mockUser.displayName,
    emailVerified: false,
    isAnonymous: false,
    metadata: {
      creationTime: new Date().toISOString(),
      lastSignInTime: new Date().toISOString(),
    },
    providerData: [],
    refreshToken: '',
    tenantId: null,
    delete: async () => { return Promise.resolve() },
    getIdToken: async () => { return Promise.resolve('mock-token') },
    getIdTokenResult: async () => { return Promise.resolve({ token: 'mock-token', claims: {}, expirationTime: '', authTime: '', issuedAtTime: '', signInProvider: null, signInSecondFactor: null }) },
    reload: async () => { return Promise.resolve() },
    toJSON: () => { return {} },
    phoneNumber: null,
    photoURL: null,
    providerId: 'firebase',
  } as User;
};

// Mock auth servisi
const mockAuthService = {
  // Kullanıcı oluşturma
  createUserWithEmailAndPassword: async (email: string, password: string): Promise<{user: User}> => {
    // Kullanıcı var mı kontrol et
    const existingUser = mockUsers.find(u => u.email === email);
    if (existingUser) {
      const error = { code: 'auth/email-already-in-use' } as { code: string };
      throw error;
    }

    // Şifre kontrolü
    if (password.length < 6) {
      const error = { code: 'auth/weak-password' } as { code: string };
      throw error;
    }

    // Yeni kullanıcı oluştur
    const newUser: MockUser = {
      uid: `mock-uid-${Date.now()}`,
      email,
      password,
      displayName: ''
    };

    mockUsers.push(newUser);
    currentMockUser = newUser;

    logDev('Kullanıcı oluşturuldu', { email });
    return { user: createMockAuthUser(newUser) };
  },

  // Kullanıcı girişi
  signInWithEmailAndPassword: async (email: string, password: string): Promise<{user: User}> => {
    const user = mockUsers.find(u => u.email === email && u.password === password);

    if (!user) {
      const error = { code: 'auth/user-not-found' } as { code: string };
      throw error;
    }

    currentMockUser = user;
    logDev('Kullanıcı girişi yapıldı', { email });
    return { user: createMockAuthUser(user) };
  },

  // Kullanıcı çıkışı
  signOut: async (): Promise<void> => {
    logDev('Kullanıcı çıkışı yapıldı', { email: currentMockUser?.email });
    currentMockUser = null;
    return Promise.resolve();
  },

  // Profil güncelleme
  updateProfile: async (user: User, profile: {displayName?: string, photoURL?: string}): Promise<void> => {
    if (currentMockUser && profile.displayName) {
      currentMockUser.displayName = profile.displayName;
      logDev('Kullanıcı profili güncellendi', {
        email: currentMockUser.email,
        displayName: profile.displayName
      });
    }
    return Promise.resolve();
  },

  // Şifre sıfırlama
  sendPasswordResetEmail: async (email: string): Promise<void> => {
    const user = mockUsers.find(u => u.email === email);

    if (!user) {
      const error = { code: 'auth/user-not-found' } as { code: string };
      throw error;
    }

    logDev('Şifre sıfırlama e-postası gönderildi', { email });
    return Promise.resolve();
  },

  // Auth state değişikliklerini dinlemek
  onAuthStateChanged: (callback: (user: User | null) => void) => {
    // Kullanıcı değişikliklerini hemen yansıt
    if (currentMockUser) {
      setTimeout(() => callback(createMockAuthUser(currentMockUser)), 0);
    } else {
      setTimeout(() => callback(null), 0);
    }

    // Temizleme fonksiyonu döndür
    return () => {};
  }
};

// Firebase'i başlat ve nesneleri dışa aktar
function initializeFirebase(): { auth: Auth | null, db: Firestore | null } {
  // Mock servis kullanıyorsak
  if (USE_MOCK_SERVICE && typeof window !== 'undefined') {
    console.log('Mock Firebase servisi kullanılıyor');
    return { auth: {} as Auth, db: {} as Firestore };
  }

  // Gerçek Firebase kullanımı
  let firebaseApp: FirebaseApp | undefined = undefined;
  let auth: Auth | null = null;
  let db: Firestore | null = null;

  // Tarayıcı tarafında mıyız?
  if (typeof window !== 'undefined') {
    try {
      firebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
      auth = getAuth(firebaseApp);
      db = getFirestore(firebaseApp);

      return { auth, db };
    } catch (error) {
      console.error("Firebase başlatma hatası:", error);
      return { auth: null, db: null };
    }
  }

  // Server tarafında null döndür
  return { auth: null, db: null };
}

// Firebase servislerini başlat
const { auth, db } = initializeFirebase();

// Dışa aktar
export { auth, db };

// Hata işleme yardımcı fonksiyonu
const handleFirebaseError = (error: unknown): string => {
  if (process.env.NODE_ENV !== 'production') {
    console.error("Firebase hatası:", error);
  }

  if (error && typeof error === 'object' && 'code' in error) {
    const fbError = error as { code: string };

    switch (fbError.code) {
      case 'auth/api-key-not-valid':
        return 'Firebase API anahtarı geçersiz. Lütfen sistem yöneticisiyle iletişime geçin.';
      case 'auth/email-already-in-use':
        return 'Bu e-posta adresi zaten kullanımda';
      case 'auth/weak-password':
        return 'Şifre en az 6 karakter olmalıdır';
      case 'auth/invalid-email':
        return 'Geçersiz e-posta adresi';
      case 'auth/operation-not-allowed':
        return 'E-posta/şifre girişi etkin değil';
      case 'auth/user-not-found':
        return 'Bu e-posta adresiyle bir hesap bulunamadı';
      case 'auth/wrong-password':
        return 'E-posta veya şifre hatalı';
      case 'auth/too-many-requests':
        return 'Çok fazla hatalı giriş denemesi. Lütfen daha sonra tekrar deneyin';
      case 'auth/user-disabled':
        return 'Bu kullanıcı hesabı devre dışı bırakılmış';
      default:
        return `İşlem sırasında bir hata oluştu: ${fbError.code}`;
    }
  }

  return 'İşlem sırasında beklenmeyen bir hata oluştu';
};

// Kimlik doğrulama işlevleri
export const registerUser = async (
  email: string,
  password: string,
  displayName: string
): Promise<{user: User | null, error: string | null}> => {
  try {
    if (!email || !password) {
      return { user: null, error: "E-posta ve şifre zorunludur" };
    }

    // Mock servis kullanımı
    if (USE_MOCK_SERVICE) {
      try {
        const { user } = await mockAuthService.createUserWithEmailAndPassword(email, password);
        await mockAuthService.updateProfile(user, { displayName });
        return { user, error: null };
      } catch (error) {
        return { user: null, error: handleFirebaseError(error) };
      }
    }

    // Auth başlatılmamışsa
    if (!auth) {
      return { user: null, error: "Kimlik doğrulama servisine erişilemiyor" };
    }

    // Gerçek Firebase kullanımı
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    if (userCredential?.user) {
      await updateProfile(userCredential.user, { displayName });
      return { user: userCredential.user, error: null };
    }
    return { user: null, error: "Kullanıcı oluşturulamadı" };
  } catch (error) {
    return { user: null, error: handleFirebaseError(error) };
  }
};

export const loginUser = async (
  email: string,
  password: string
): Promise<{user: User | null, error: string | null}> => {
  try {
    if (!email || !password) {
      return { user: null, error: "E-posta ve şifre zorunludur" };
    }

    // Mock servis kullanımı
    if (USE_MOCK_SERVICE) {
      try {
        const { user } = await mockAuthService.signInWithEmailAndPassword(email, password);
        return { user, error: null };
      } catch (error) {
        return { user: null, error: handleFirebaseError(error) };
      }
    }

    // Auth başlatılmamışsa
    if (!auth) {
      return { user: null, error: "Kimlik doğrulama servisine erişilemiyor" };
    }

    // Gerçek Firebase kullanımı
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return { user: userCredential.user, error: null };
  } catch (error) {
    return { user: null, error: handleFirebaseError(error) };
  }
};

export const signOut = async (): Promise<{success: boolean, error: string | null}> => {
  try {
    // Mock servis kullanımı
    if (USE_MOCK_SERVICE) {
      await mockAuthService.signOut();
      return { success: true, error: null };
    }

    // Auth başlatılmamışsa
    if (!auth) {
      return { success: false, error: "Kimlik doğrulama servisine erişilemiyor" };
    }

    // Gerçek Firebase kullanımı
    await firebaseSignOut(auth);
    return { success: true, error: null };
  } catch (error) {
    return { success: false, error: handleFirebaseError(error) };
  }
};

export const resetPassword = async (email: string): Promise<{success: boolean, error: string | null}> => {
  try {
    if (!email) {
      return { success: false, error: "E-posta adresi zorunludur" };
    }

    // Mock servis kullanımı
    if (USE_MOCK_SERVICE) {
      try {
        await mockAuthService.sendPasswordResetEmail(email);
        return { success: true, error: null };
      } catch (error) {
        return { success: false, error: handleFirebaseError(error) };
      }
    }

    // Auth başlatılmamışsa
    if (!auth) {
      return { success: false, error: "Kimlik doğrulama servisine erişilemiyor" };
    }

    // Gerçek Firebase kullanımı
    await sendPasswordResetEmail(auth, email);
    return { success: true, error: null };
  } catch (error) {
    return { success: false, error: handleFirebaseError(error) };
  }
};

// Auth state değişimini izlemek için hook
export const subscribeToAuthChanges = (callback: (user: User | null) => void) => {
  // Mock servis kullanımı
  if (USE_MOCK_SERVICE) {
    return mockAuthService.onAuthStateChanged(callback);
  }

  // Auth başlatılmamışsa boş fonksiyon döndür
  if (!auth) {
    console.warn("Auth servisi başlatılmadı, auth state değişimi izlenemeyecek");
    return () => {};
  }

  // Gerçek Firebase kullanımı
  return onAuthStateChanged(auth, callback);
};
