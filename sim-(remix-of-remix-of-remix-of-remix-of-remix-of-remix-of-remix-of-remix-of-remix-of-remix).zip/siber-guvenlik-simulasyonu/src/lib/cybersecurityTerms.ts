// Siber güvenlik terimleri sözlüğü

// Terim kategorileri
export type TermCategory =
  | 'Saldırı Türleri'
  | 'Güvenlik Önlemleri'
  | 'Ağ Güvenliği'
  | 'Şifreleme'
  | 'Sosyal Mühendislik'
  | 'Mobil Güvenlik'
  | 'IoT Güvenliği'
  | 'Genel';

// Terim arayüzü
export interface SecurityTerm {
  id: string;
  term: string;
  definition: string;
  category: TermCategory;
  shortDescription?: string;
  relatedTerms?: string[];
  example?: string;
  imageUrl?: string;
}

// Siber güvenlik terimleri
export const securityTerms: SecurityTerm[] = [
  // Saldırı Türleri
  {
    id: "phishing",
    term: "Oltalama (Phishing)",
    definition: "Sahte e-postalar, mesajlar veya web siteleri kullanarak kişisel bilgileri, kullanıcı adları, şifreler veya banka hesap bilgileri gibi hassas bilgileri çalmayı amaçlayan bir sosyal mühendislik tekniğidir.",
    shortDescription: "Sahte iletişim kanalları ile kişisel bilgileri çalma girişimi",
    category: "Saldırı Türleri",
    relatedTerms: ["spear-phishing", "social-engineering", "spoofing"],
    example: "Bankanızdan gelmiş gibi görünen, hesabınızın güvenliği için hemen tıklamanız gereken bir bağlantı içeren bir e-posta alırsınız.",
    imageUrl: ""
  },
  {
    id: "ransomware",
    term: "Fidye Yazılımı (Ransomware)",
    definition: "Kurbanın dosyalarını şifreleyen ve şifre çözme anahtarı için fidye talep eden kötü amaçlı yazılım türüdür. Genellikle kriptopara (Bitcoin gibi) cinsinden ödeme talep edilir.",
    shortDescription: "Dosyaları şifreleyip fidye talep eden kötücül yazılım",
    category: "Saldırı Türleri",
    relatedTerms: ["malware", "encryption", "decryption-key"],
    example: "Bilgisayarınızdaki tüm dosyalar şifrelenir ve ekranda 48 saat içinde bitcoin ödeme yapmanız gerektiğini belirten bir mesaj görünür.",
  },
  {
    id: "malware",
    term: "Kötücül Yazılım (Malware)",
    definition: "Bir bilgisayar sistemine zarar vermek, verileri çalmak veya sisteme yetkisiz erişim sağlamak için tasarlanmış yazılımlardır. Virüsler, solucanlar, truva atları, fidye yazılımları, casus yazılımlar ve reklam yazılımları gibi türleri vardır.",
    shortDescription: "Bilgisayar sistemlerine zarar veren kötü amaçlı yazılımlar",
    category: "Saldırı Türleri",
    relatedTerms: ["virus", "trojan", "spyware", "ransomware"],
    example: "İndirdiğiniz bir uygulama, arka planda çalışarak klavye hareketlerinizi kaydeder ve hassas bilgilerinizi çalar.",
    imageUrl: ""
  },
  {
    id: "ddos",
    term: "Dağıtılmış Hizmet Engelleme Saldırısı (DDoS)",
    definition: "Bir web sitesini, servisi veya ağı, çok sayıda kaynaktan gelen yoğun trafik ile bunaltarak kullanıcıların erişimini engellemeyi amaçlayan saldırı türüdür.",
    shortDescription: "Sistemlere çoklu kaynaklardan trafik göndererek hizmet dışı bırakmak",
    category: "Saldırı Türleri",
    relatedTerms: ["dos", "botnet", "traffic-flooding"],
    example: "Bir şirketin web sitesi, koordineli binlerce bilgisayardan gelen isteklerle aşırı yüklenir ve çöker."
  },
  {
    id: "mitm",
    term: "Ortadaki Adam Saldırısı (Man-in-the-Middle)",
    definition: "Saldırganın iki taraf arasındaki iletişimi gizlice dinlediği veya değiştirdiği bir saldırı türüdür. Saldırgan, iletişim kurduğunuz kişi veya servis gibi davranır.",
    shortDescription: "İki taraf arasındaki iletişimi gizlice dinleme ve değiştirme",
    category: "Saldırı Türleri",
    relatedTerms: ["eavesdropping", "session-hijacking", "network-security"],
    example: "Güvensiz bir Wi-Fi ağında, saldırgan banka web sitenizle kurduğunuz bağlantıyı ele geçirip işlemlerinizi izleyebilir."
  },
  {
    id: "sql-injection",
    term: "SQL Enjeksiyonu (SQL Injection)",
    definition: "Saldırganın zararlı SQL kodunu bir uygulamanın veri giriş alanlarına enjekte ederek veritabanını manipüle etmeye çalıştığı bir saldırı türüdür.",
    shortDescription: "Zararlı SQL komutlarını uygulama girişlerine enjekte etme",
    category: "Saldırı Türleri",
    relatedTerms: ["injection-attacks", "database-security", "input-validation"],
    example: "Bir web sitesinin giriş formuna normal kullanıcı adı yerine \"admin' OR 1=1 --\" gibi bir sorgu enjekte edilerek tüm kullanıcıların bilgilerine erişim sağlanabilir."
  },

  // Güvenlik Önlemleri
  {
    id: "2fa",
    term: "İki Faktörlü Kimlik Doğrulama (2FA)",
    definition: "Kullanıcıların iki farklı faktör kullanarak kimliklerini doğruladığı bir güvenlik yöntemidir: Bildiğiniz bir şey (şifre), sahip olduğunuz bir şey (telefon) veya olduğunuz bir şey (parmak izi).",
    shortDescription: "İki farklı doğrulama yöntemi kullanarak güvenliği artırma",
    category: "Güvenlik Önlemleri",
    relatedTerms: ["mfa", "authentication", "security-token"],
    example: "Hesabınıza giriş yaparken şifrenizi girdikten sonra telefonunuza gelen doğrulama kodunu da girmeniz istenir.",
    imageUrl: ""
  },
  {
    id: "firewall",
    term: "Güvenlik Duvarı (Firewall)",
    definition: "Ağ güvenliğini sağlamak için gelen ve giden ağ trafiğini izleyen ve belirlenen güvenlik kurallarına göre trafiğe izin veren veya engelleyen donanım veya yazılım sistemidir.",
    shortDescription: "Ağ trafiğini izleyip filtreleme yapan güvenlik sistemi",
    category: "Güvenlik Önlemleri",
    relatedTerms: ["network-security", "packet-filtering", "proxy"],
    example: "Şirket ağının güvenlik duvarı, bilinmeyen IP adreslerinden gelen tüm bağlantıları otomatik olarak engeller."
  },
  {
    id: "encryption",
    term: "Şifreleme (Encryption)",
    definition: "Veriyi, özel bir anahtar olmadan okunamayacak şekilde dönüştürme işlemidir. Sadece yetkili alıcılar, şifreyi çözme anahtarına sahip olarak orijinal veriye erişebilir.",
    shortDescription: "Verileri yetkisiz erişime karşı korumak için şifreli hale getirme",
    category: "Şifreleme",
    relatedTerms: ["cryptography", "decryption", "key-management"],
    example: "WhatsApp, mesajlarınızı uçtan uca şifreleme ile korur, böylece sadece siz ve konuştuğunuz kişi mesajları okuyabilir."
  },
  {
    id: "password-manager",
    term: "Şifre Yöneticisi (Password Manager)",
    definition: "Kullanıcıların çeşitli çevrimiçi hesaplar için karmaşık ve benzersiz şifreleri güvenli bir şekilde depolamasına, oluşturmasına ve yönetmesine yardımcı olan bir uygulamadır.",
    shortDescription: "Şifreleri güvenli bir şekilde saklayan ve yöneten uygulama",
    category: "Güvenlik Önlemleri",
    relatedTerms: ["password-security", "authentication", "encryption"],
    example: "LastPass veya Bitwarden gibi şifre yöneticileri, tüm hesaplarınız için farklı ve karmaşık şifreler kullanmanızı sağlar."
  },

  // Ağ Güvenliği
  {
    id: "vpn",
    term: "Sanal Özel Ağ (VPN)",
    definition: "İnternet üzerinden güvenli, şifrelenmiş bir bağlantı oluşturan bir hizmettir. Kullanıcıların gizliliğini korur, IP adreslerini gizler ve veri trafiğini şifreler.",
    shortDescription: "İnternet bağlantınızı şifreleyen ve gizleyen güvenli tünel",
    category: "Ağ Güvenliği",
    relatedTerms: ["encryption", "privacy", "proxy"],
    example: "Halka açık Wi-Fi ağında çalışırken, VPN kullanarak bağlantınızı şifreleyebilir ve veri ihlallerini önleyebilirsiniz."
  },
  {
    id: "ssl-tls",
    term: "SSL/TLS",
    definition: "İnternet üzerinden iletilen verileri şifrelemek için kullanılan güvenlik protokolleridir. Web sitelerinde HTTPS bağlantılarını sağlar ve kullanıcı ile web sitesi arasındaki iletişimi korur.",
    shortDescription: "Web sitesi ile kullanıcı arasındaki iletişimi şifrelemek için kullanılan protokoller",
    category: "Ağ Güvenliği",
    relatedTerms: ["https", "certificates", "encryption"],
    example: "Tarayıcınızda gördüğünüz kilit simgesi, web sitesinin SSL/TLS sertifikası kullandığını ve bağlantınızın şifrelendiğini gösterir."
  },

  // Sosyal Mühendislik
  {
    id: "social-engineering",
    term: "Sosyal Mühendislik (Social Engineering)",
    definition: "İnsanları psikolojik manipülasyon yoluyla kandırarak hassas bilgileri açıklamaya veya güvenlik önlemlerini atlamaya ikna etme tekniğidir.",
    shortDescription: "İnsanları manipüle ederek bilgi elde etme veya güvenliği ihlal etme",
    category: "Sosyal Mühendislik",
    relatedTerms: ["phishing", "pretexting", "baiting"],
    example: "Bir saldırgan şirket personeli gibi davranarak, acil bir durum olduğunu ve hemen şifrenizi paylaşmanız gerektiğini söyleyebilir."
  },

  // Mobil Güvenlik
  {
    id: "app-permissions",
    term: "Uygulama İzinleri (App Permissions)",
    definition: "Mobil uygulamaların cihazınızdaki belirli özelliklere, verilere veya bileşenlere erişmesi için kullanıcı tarafından verilen yetkilendirilme sistemidir.",
    shortDescription: "Uygulamalara cihazınızın özelliklerine erişme yetkisi verme",
    category: "Mobil Güvenlik",
    relatedTerms: ["privacy", "data-access", "mobile-security"],
    example: "Bir fotoğraf düzenleme uygulaması, galerinize erişmek için izin isteyebilir, ancak konum veya kişilerinize erişim için izin istemesi şüpheli olabilir."
  },

  // IoT Güvenliği
  {
    id: "iot-security",
    term: "IoT Güvenliği (IoT Security)",
    definition: "Nesnelerin İnterneti (IoT) cihazlarını siber saldırılara karşı korumak için alınan önlemler ve uygulanan güvenlik pratikleridir.",
    shortDescription: "Akıllı cihazları ve sensörleri siber saldırılardan koruma",
    category: "IoT Güvenliği",
    relatedTerms: ["smart-devices", "network-security", "encryption"],
    example: "Akıllı ev cihazlarınız varsayılan şifrelerle kullanılırsa, saldırganlar kolayca erişip kontrol edebilir."
  },

  // Genel Terimler
  {
    id: "zero-day",
    term: "Sıfır Gün Açığı (Zero-Day Vulnerability)",
    definition: "Yazılım geliştiricileri tarafından henüz keşfedilmemiş veya düzeltilmemiş yazılım güvenlik açığıdır. Saldırganlar bunu güvenlik yamalarından önce istismar edebilir.",
    shortDescription: "Henüz düzeltilmemiş ve saldırganlar tarafından kullanılabilen güvenlik açığı",
    category: "Genel",
    relatedTerms: ["vulnerability", "exploit", "patch"],
    example: "Microsoft Windows'ta keşfedilen ve düzeltilmeden önce saldırganlar tarafından kullanılan bir güvenlik açığı."
  },
  {
    id: "biometrics",
    term: "Biyometrik Kimlik Doğrulama (Biometric Authentication)",
    definition: "Parmak izi, yüz tanıma, retina taraması veya ses tanıma gibi benzersiz fiziksel veya davranışsal özellikleri kullanarak kimlik doğrulama yöntemidir.",
    shortDescription: "Fiziksel özellikler kullanarak kimlik doğrulama",
    category: "Güvenlik Önlemleri",
    relatedTerms: ["authentication", "identity-verification", "2fa"],
    example: "Parmak izinizi kullanarak akıllı telefonunuzun kilidini açmak bir biyometrik kimlik doğrulama örneğidir."
  },
  {
    id: "penetration-testing",
    term: "Sızma Testi (Penetration Testing)",
    definition: "Bir organizasyonun bilgi sistemlerindeki güvenlik açıklarını belirlemek için gerçekleştirilen yetkili bir siber saldırı simülasyonudur.",
    shortDescription: "Sistemdeki güvenlik açıklarını bulmak için yapılan yetkili test",
    category: "Güvenlik Önlemleri",
    relatedTerms: ["security-assessment", "vulnerability-scanning", "ethical-hacking"],
    example: "Bir şirket, güvenlik uzmanlarına ağlarına saldırmaları için izin vererek sistemlerindeki zayıflıkları tespit eder."
  }
];

// Bir terime ID ile erişim
export function getTermById(id: string): SecurityTerm | undefined {
  return securityTerms.find(term => term.id === id);
}

// Belirli bir kategorideki terimleri getirme
export function getTermsByCategory(category: TermCategory): SecurityTerm[] {
  return securityTerms.filter(term => term.category === category);
}

// Arama sorgusuyla eşleşen terimleri getirme
export function searchTerms(query: string): SecurityTerm[] {
  const lowercaseQuery = query.toLowerCase();
  return securityTerms.filter(term =>
    term.term.toLowerCase().includes(lowercaseQuery) ||
    term.definition.toLowerCase().includes(lowercaseQuery) ||
    (term.shortDescription?.toLowerCase().includes(lowercaseQuery))
  );
}

// Tüm kategorileri getirme
export function getAllCategories(): TermCategory[] {
  const categoriesSet = new Set<TermCategory>();
  securityTerms.forEach(term => categoriesSet.add(term.category));
  return Array.from(categoriesSet);
}
