import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Senaryo türleri
export type ScenarioType = 'phishing' | 'password' | 'software' | 'social' | 'network' | 'terminal' | 'desktop' | 'mobile' | 'physical' | 'ai' | 'blockchain' | 'iot';

// Zorluk seviyeleri
export type DifficultyLevel = 'easy' | 'medium' | 'hard';

// Başarı (Achievement) tipi
export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: Date;
  condition: (state: GameState) => boolean; // Başarının kilidini açma koşulu
}

// Kullanıcı istatistikleri tipi
export interface UserStats {
  totalCorrectAnswers: number;
  totalIncorrectAnswers: number;
  fastestResponseTime: number;
  totalPlayTime: number;
  scenariosPlayed: number;
  averageScore: number;
  categoryScores: Record<ScenarioType, number>;
  completedDifficulties: {
    easy: number;
    medium: number;
    hard: number;
  };
}

// Liderlik tablosu girdi tipi
export interface LeaderboardEntry {
  username: string;
  score: number;
  level: number;
  achievements: number; // Kazanılan başarı sayısı
  date: Date;
}

// Ortalama skoru hesaplama yardımcı fonksiyonu
const calculateAverageScore = (correctAnswers: number, totalPlayed: number) => {
  if (totalPlayed === 0) return 0;
  return (correctAnswers / totalPlayed) * 100;
};

// Seçenek arayüzü
export interface Option {
  id: string;
  text: string;
  correct: boolean;
  explanation: string;
  risk: number; // Yanlış seçilirse risk puanı artışı
}

// Senaryo arayüzü
export interface Scenario {
  id: string;
  title: string;
  description: string;
  type: ScenarioType;
  image?: string;
  options: Option[];
  completed: boolean;
  selectedOption?: string;
  timeLimit?: number; // Saniye cinsinden zaman sınırı (varsa)
  simulationType?: 'quiz' | 'terminal' | 'network' | 'desktop' | 'mobile' | 'physical' | 'ai' | 'aivoice' | 'aidata' | 'phishing' | 'password' | 'software' | 'blockchain' | 'iot'; // Simülasyon tipleri
  difficultyPoints?: number; // Senaryo zorluk puanı
  responseTime?: number; // Kullanıcının cevap verme süresi (ms cinsinden)
}

// Oyun durumu arayüzü
interface GameState {
  username: string;
  setUsername: (name: string) => void;

  // Oyun durumu
  isStarted: boolean;
  isCompleted: boolean;
  currentScenarioIndex: number;
  score: number;
  riskLevel: number;

  // Yeni puanlama sistemi
  detailedScore: {
    basePoints: number; // Senaryolardan kazanılan temel puanlar
    timeBonus: number; // Hızlı cevaplardan kazanılan bonus puanlar
    difficultyBonus: number; // Zorlu senaryolardan kazanılan bonus puanlar
    consistencyBonus: number; // Tutarlılık için bonus puan
  };
  performanceCategories: Record<ScenarioType, {correct: number, total: number}>;
  fastestResponse: number; // En hızlı cevap süresi (ms)

  // Gamifikasyon sistemi
  level: number; // Kullanıcı seviyesi
  xp: number; // Deneyim puanı
  xpForNextLevel: number; // Bir sonraki seviyeye geçmek için gereken XP
  achievements: Achievement[]; // Kazanılan başarılar
  userStats: UserStats; // Kullanıcı istatistikleri
  leaderboard: LeaderboardEntry[]; // Liderlik tablosu

  // Seviye sistemi işlevleri
  getLevel: () => { level: number, progress: number }; // Mevcut seviye ve ilerleme
  addXP: (amount: number) => void; // XP ekle
  checkAchievements: () => Achievement[]; // Başarıları kontrol et
  getLeaderboard: () => LeaderboardEntry[]; // Liderlik tablosunu getir
  updateLeaderboard: () => void; // Liderlik tablosunu güncelle

  // Yeni özellikler
  difficultyLevel: DifficultyLevel;
  setDifficultyLevel: (level: DifficultyLevel) => void;
  timeRemaining: number | null; // null ise zaman sınırı yok
  startTimer: (seconds: number) => void;
  stopTimer: () => void;
  timerId: number | null;
  showCertificate: boolean;
  setShowCertificate: (show: boolean) => void;
  useImprovedCertificate: boolean; // Gelişmiş sertifika kullanımı
  setUseImprovedCertificate: (use: boolean) => void;

  // Oyun akışı
  startGame: () => void;
  completeGame: () => void;
  resetGame: () => void;

  // Senaryo yönetimi
  scenarios: Scenario[];
  getCurrentScenario: () => Scenario | undefined;
  selectOption: (scenarioId: string, optionId: string) => void;
  nextScenario: () => void;

  // Puan yönetimi
  getTotalPossibleScore: () => number;
  getScorePercentage: () => number;
  getRiskPercentage: () => number;
  getDetailedScoreAnalysis: () => any; // Detaylı puan analizi
  getCategoryPerformance: () => CategoryPerformance[]; // Kategori başarımı analizi
}

// Kategori performansı için gelişmiş tip tanımla
type CategoryPerformance = {
  category: string;
  correct: number;
  total: number;
  percentage: number;
  skillLevel: string; // Yetenek seviyesi (metin açıklaması)
  skillRating: number; // 0-100 arası yetenek derecesi
}

// Tüm senaryolar
const allScenarios: Scenario[] = [
  // Mevcut phishing senaryosu
  {
    id: 'phishing-1',
    title: 'Şüpheli E-posta',
    description: "Şirket e-postanıza \"Acil: Şifre Sıfırlama İsteği\" konulu bir e-posta geldi. Gönderici adresi \"it-support@company-verification.com\". E-postada, şirket sistemine erişiminizin sona ermek üzere olduğu ve bu bağlantıyı kullanarak şifrenizi güncellemezseniz erişiminizin kaldırılacağı belirtiliyor.",
    type: 'phishing',
    image: '/scenarios/phishing-email.png',
    options: [
      {
        id: 'p1-1',
        text: 'Bağlantıya tıklayıp şifrenizi değiştirin.',
        correct: false,
        explanation: 'Bu bir phishing e-postasıdır. Gönderici adresi resmi şirket domaini değil ve e-posta aciliyet yaratarak hızlı tepki vermenizi istiyor.',
        risk: 25,
      },
      {
        id: 'p1-2',
        text: 'E-postayı BT departmanına iletin ve doğrulanmasını bekleyin.',
        correct: true,
        explanation: 'Şüpheli e-postaları IT departmanına bildirmek ve onlardan doğrulama istemek en güvenli yaklaşımdır.',
        risk: 0,
      },
      {
        id: 'p1-3',
        text: 'E-postayı silin ve görmezden gelin.',
        correct: false,
        explanation: 'Silmek, göndericiyi engellemek gibi güvenlik önlemlerini almadığınız için kısmen doğrudur. Ancak, şirket politikasına bağlı olarak, bu tür şüpheli e-postaların raporlanması genellikle daha iyi bir uygulamadır.',
        risk: 5,
      },
    ],
    completed: false,
    timeLimit: 60, // Zor zorluk seviyesinde uygulanacak süre sınırı
    simulationType: 'quiz',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yazılım güncellemesi senaryosu
  {
    id: 'software-1',
    title: 'Yazılım Güncellemesi',
    description: "Bilgisayarınızda çalışırken bir güncelleme bildirimi alıyorsunuz: \"Windows Güvenlik Güncellemesi mevcut. Bilgisayarınızı kritik güvenlik açıklarına karşı korumak için şimdi güncellemek ister misiniz?\" Ancak yoğun bir toplantıya girmek üzeresiniz.",
    type: 'software',
    image: '/scenarios/software-update.png',
    options: [
      {
        id: 's1-1',
        text: 'Güncellemeyi hemen kurun.',
        correct: true,
        explanation: 'Güvenlik güncellemeleri, bilgisayarınızı önemli güvenlik açıklarına karşı korur. Mümkün olan en kısa sürede uygulanmaları önemlidir.',
        risk: 0,
      },
      {
        id: 's1-2',
        text: 'Güncellemeyi erteleyin ve toplantıdan sonra kurun.',
        correct: false,
        explanation: 'Güncellemeyi kısa bir süre ertelemek makul olsa da, güvenlik güncellemelerini sürekli ertelemek sisteminizi risk altında bırakır.',
        risk: 10,
      },
      {
        id: 's1-3',
        text: 'Güncellemeyi devre dışı bırakın ve bir daha hatırlatılmasın.',
        correct: false,
        explanation: 'Güvenlik güncellemelerini devre dışı bırakmak, sisteminizi bilinen güvenlik açıklarına karşı savunmasız bırakır ve siber saldırılar için kolay hedef haline getirir.',
        risk: 30,
      },
    ],
    completed: false,
    simulationType: 'quiz',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: Terminal Simülasyonu
  {
    id: 'terminal-1',
    title: 'Terminal Güvenliği',
    description: "Linux terminalinde çalışırken, sistem güvenliğini kontrol etmeniz ve potansiyel tehditleri tespit etmeniz gerekmektedir. Terminal simülasyonunu kullanarak güvenlik kontrollerini yapacaksınız.",
    type: 'terminal',
    options: [
      {
        id: 't1-1',
        text: 'Terminalden şifre dosyalarını kontrol edin ve güvensiz yapılandırmaları tespit edin.',
        correct: true,
        explanation: 'Terminal üzerinden sistem dosyalarını doğru bir şekilde kontrol etmek, güvenlik açıklarını tespit etmenin etkili bir yoludur.',
        risk: 0,
      },
      {
        id: 't1-2',
        text: 'Terminal komutlarını kullanmayı reddederek grafik arayüz kullanmaya devam edin.',
        correct: false,
        explanation: 'Terminal komutları, sistem güvenliğini denetlemek ve yönetmek için güçlü araçlardır. Bu araçları kullanmayı reddetmek, güvenlik denetimlerinin etkinliğini sınırlar.',
        risk: 15,
      }
    ],
    completed: false,
    simulationType: 'terminal',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: Masaüstü Simülasyonu
  {
    id: 'desktop-1',
    title: 'Masaüstü Güvenliği',
    description: "Sanal masaüstü ortamında çalışırken, güvenlik tehditleri ile karşılaşabilirsiniz. İşletim sistemi, uygulama ve dosya güvenliği konusunda doğru kararlar vermeniz gerekiyor.",
    type: 'desktop',
    options: [
      {
        id: 'd1-1',
        text: 'Masaüstü simülasyonunda güvenli davranışlar sergileyin ve tehditleri tespit edin.',
        correct: true,
        explanation: 'Masaüstü ortamında güvenlik tehditlerine karşı bilinçli davranmak, veri ve sistem güvenliğini korur.',
        risk: 0,
      },
      {
        id: 'd1-2',
        text: 'Tüm bildirimleri ve uyarıları görmezden gelin.',
        correct: false,
        explanation: 'Güvenlik bildirimleri ve uyarılar, potansiyel tehditlere karşı önemli uyarılardır. Bunları görmezden gelmek, sistemin güvenliğini tehlikeye atar.',
        risk: 25,
      }
    ],
    completed: false,
    simulationType: 'desktop',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: Ağ Güvenliği Simülasyonu
  {
    id: 'network-1',
    title: 'Ağ Güvenliği',
    description: "Bir şirket ağında güvenlik sorumlusu olarak çalışıyorsunuz. Ağ topolojisini inceleyerek potansiyel tehditleri tespit etmeniz ve uygun önlemleri almanız gerekiyor.",
    type: 'network',
    options: [
      {
        id: 'n1-1',
        text: 'Ağ simülasyonunda güvenlik saldırılarına karşı savunma stratejileri geliştirin.',
        correct: true,
        explanation: 'Ağ güvenliği için proaktif savunma stratejileri geliştirmek, saldırıları önlemenin ve etkisini azaltmanın en etkili yoludur.',
        risk: 0,
      },
      {
        id: 'n1-2',
        text: 'Ağ yapılandırmasını değiştirmeden varsayılan ayarları kullanmaya devam edin.',
        correct: false,
        explanation: 'Varsayılan ağ ayarları genellikle maksimum güvenlik sağlamaz. Güvenlik için özel yapılandırma ve düzenli güncelleme gereklidir.',
        risk: 20,
      }
    ],
    completed: false,
    simulationType: 'network',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Şifre güvenliği senaryosu
  {
    id: 'password-1',
    title: 'Şifre Politikası',
    description: "IT departmanı yeni bir şifre politikası uyguluyor ve tüm çalışanların şifrelerini değiştirmesi gerekiyor. Aşağıdaki şifre seçeneklerinden hangisini kullanırdınız?",
    type: 'password',
    options: [
      {
        id: 'pw1-1',
        text: 'P@ssword123',
        correct: false,
        explanation: 'Bu şifre yaygın kelime değişiklikleri içeriyor (a → @) ve tahmin edilebilir bir yapıya sahip. Karmaşık görünse de, sözlük saldırılarına karşı zayıftır.',
        risk: 15,
      },
      {
        id: 'pw1-2',
        text: 'Ilove2023!',
        correct: false,
        explanation: 'Bu şifre kişisel bir ifade ve geçerli yıl içeriyor. Bu tür şifreler tahmin edilebilir ve kaba kuvvet saldırılarına karşı savunmasızdır.',
        risk: 20,
      },
      {
        id: 'pw1-3',
        text: 'jT5%qL8#zW2&kF',
        correct: true,
        explanation: 'Bu şifre uzun, karmaşık ve rastgele karakterlerden oluşuyor. Tahmin edilmesi çok zor ve kaba kuvvet saldırılarına karşı dayanıklıdır.',
        risk: 0,
      },
      {
        id: 'pw1-4',
        text: 'CompanyName2023',
        correct: false,
        explanation: 'Şirket adı gibi tahmin edilebilir bilgiler içeren şifreler, hedefli saldırılara karşı savunmasızdır.',
        risk: 25,
      },
    ],
    completed: false,
    simulationType: 'quiz',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: Mobil Güvenlik Senaryosu
  {
    id: 'mobile-1',
    title: 'Mobil Uygulama İzinleri',
    description: "Akıllı telefonunuza yeni bir fotoğraf düzenleme uygulaması indirdiniz. Kurulum sırasında uygulama şu izinleri talep ediyor: kamera, galeri, konum, rehber, mikrofon, mesajlar ve telefon aramaları.",
    type: 'mobile',
    image: '/scenarios/new_images/mobile-permissions.png',
    options: [
      {
        id: 'm1-1',
        text: 'Tüm izinleri verin, böylece uygulama doğru çalışır.',
        correct: false,
        explanation: 'Bir fotoğraf düzenleme uygulamasının mesajlara, aramalara veya rehberinize erişmesi için meşru bir nedeni yoktur. Bu, kişisel verilerinize erişmek için izin isteyen olası bir kötü amaçlı uygulamadır.',
        risk: 30,
      },
      {
        id: 'm1-2',
        text: 'Sadece kamera ve galeri izinlerini verin, diğerlerini reddedin.',
        correct: true,
        explanation: 'Bir fotoğraf düzenleme uygulaması için yalnızca kamera ve galeri izinleri mantıklıdır. Diğer izinleri kısıtlamak, gizliliğinizi korur.',
        risk: 0,
      },
      {
        id: 'm1-3',
        text: 'Uygulamayı kaldırın ve başka bir fotoğraf düzenleme uygulaması arayın.',
        correct: false,
        explanation: 'Bu da makul bir yaklaşımdır, ancak birçok uygulama izin reddedildiğinde de çalışabilir. Önce izinleri sınırlamayı denemek genellikle en iyi yaklaşımdır.',
        risk: 5,
      }
    ],
    completed: false,
    simulationType: 'mobile',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: İkinci Mobil Güvenlik Senaryosu
  {
    id: 'mobile-2',
    title: 'Sahte Uygulama Mağazası',
    description: "Popüler bir oyunun yeni versiyonunu indirmek istiyorsunuz. Resmi uygulama mağazasında bu oyun ücretli, ancak bir arkadaşınız size ücretsiz indirebileceğiniz alternatif bir uygulama mağazası bağlantısı gönderdi. Bağlantıya tıkladığınızda, neredeyse resmi mağazaya benzeyen bir site açılıyor ve oyunu ücretsiz indirmenize olanak tanıyor.",
    type: 'mobile',
    image: '/scenarios/new_images/fake-app-store.png',
    options: [
      {
        id: 'm2-1',
        text: 'Ücretsiz versiyonu indirin. Ücretli bir uygulamayı bedava elde etmek iyi bir fırsat.',
        correct: false,
        explanation: 'Bu, klasik bir kötü amaçlı yazılım dağıtma yöntemidir. Resmi olmayan kaynaklardan veya üçüncü taraf mağazalardan uygulama indirmek, cihazınıza kötü amaçlı yazılım bulaştırma riski taşır. Bu tür uygulamalar genellikle fidye yazılımı, casus yazılım veya reklam yazılımı içerir.',
        risk: 40,
      },
      {
        id: 'm2-2',
        text: 'Bağlantıyı kapatın ve resmi uygulama mağazasından satın alın.',
        correct: true,
        explanation: 'Mükemmel! Resmi uygulama mağazaları (Google Play Store, Apple App Store gibi) uygulamaları güvenlik açısından kontrol eder. Ücretsiz olarak sunulan ücretli uygulamalar genellikle korsandır ve güvenlik riski taşır. Uygulamaları her zaman resmi kaynaklardan indirmek en güvenli yaklaşımdır.',
        risk: 0,
      },
      {
        id: 'm2-3',
        text: 'Arkadaşınıza bu bağlantıdan daha önce indirip indirmediğini ve güvenli olup olmadığını sorun.',
        correct: false,
        explanation: 'Bir arkadaşınızın uygulamayı sorunsuz indirmiş olması, güvenli olduğu anlamına gelmez. Kötü amaçlı yazılımlar bazen uzun süre tespit edilmeden cihazda kalabilir ve arka planda çalışabilir. Ayrıca, bu tür sitelerin güvenliği zaman içinde değişebilir.',
        risk: 15,
      }
    ],
    completed: false,
    timeLimit: 60,
    simulationType: 'mobile',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: Fiziksel Güvenlik Senaryosu
  {
    id: 'physical-1',
    title: 'Fiziksel Güvenlik İhlali',
    description: "Ofiste çalışırken bir kişi tesis bakım ekibinden olduğunu söyleyerek yanınıza yaklaşıyor. Size kimliğini gösteriyor, ancak çok hızlı bir şekilde. Bilgisayar odasına girmesi gerektiğini ve kapı kartını unuttuğunu söyleyerek sizden kapıyı açmanızı istiyor.",
    type: 'physical',
    image: '/scenarios/new_images/physical-security.png',
    options: [
      {
        id: 'ph1-1',
        text: 'Kimliğine hızlıca göz attığınız için kapıyı açın ve yardım edin.',
        correct: false,
        explanation: 'Kimliği düzgün bir şekilde kontrol etmeden ve yetkisini doğrulamadan güvenli alanlara erişim sağlamak, ciddi bir güvenlik ihlalidir. Bu, fiziksel bir sosyal mühendislik saldırısı olabilir.',
        risk: 35,
      },
      {
        id: 'ph1-2',
        text: 'Kibarca güvenlik veya tesis yönetimiyle iletişime geçeceğinizi söyleyin ve onların yönlendirmesini bekleyin.',
        correct: true,
        explanation: 'Yetkili personel ile doğrulama yapmak, fiziksel güvenlik ihlallerini önlemenin en iyi yoludur. Tesis yönetimi veya güvenlik, kişinin iddiasını doğrulayabilir.',
        risk: 0,
      },
      {
        id: 'ph1-3',
        text: 'Şirket politikasını gerekçe göstererek kendi kart olmadan kapıyı açamayacağınızı söyleyin ve yardım etmeyi reddedin.',
        correct: false,
        explanation: 'Politikaları takip etmek iyidir, ancak durumu bildirmemek potansiyel bir güvenlik tehdidini görmezden gelmek anlamına gelir. Kişi başka birinden yardım isteyebilir.',
        risk: 10,
      }
    ],
    completed: false,
    simulationType: 'physical',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: AI Destekli Tehditler Senaryosu
  {
    id: 'ai-threats-1',
    title: 'Yapay Zeka Destekli Oltalama',
    description: "Bir iş arkadaşınızdan ses kaydı içeren bir e-posta aldınız. Ses kaydında, arkadaşınızın sesi ile acil bir projede yardım isteniyor ve bir bağlantıya tıklamanız gerektiği söyleniyor. Ancak e-posta adresi biraz farklı ve mesajda bazı imla hataları var.",
    type: 'ai',
    image: '/media/cybersecurity-overview.png',
    options: [
      {
        id: 'ai1-1',
        text: 'Ses tanıdık geldiği için bağlantıya tıklayın.',
        correct: false,
        explanation: 'Bu modern bir oltalama saldırısıdır. Yapay zeka teknolojileri, tanıdığınız kişilerin seslerini taklit edebilir. İçerikte ya da e-posta adresindeki tutarsızlıklar, bu tür bir saldırının işaretleridir.',
        risk: 40,
      },
      {
        id: 'ai1-2',
        text: 'Farklı bir iletişim kanalı üzerinden (telefon, mesaj) gerçekten arkadaşınızdan gelip gelmediğini doğrulayın.',
        correct: true,
        explanation: 'Mükemmel! Şüpheli iletişimleri her zaman alternatif kanallar üzerinden doğrulamak, yapay zeka destekli oltalama saldırılarına karşı en iyi savunmadır.',
        risk: 0,
      },
      {
        id: 'ai1-3',
        text: 'Ses kaydını tekrar dinleyin ve daha sonra karar verin.',
        correct: false,
        explanation: 'Yapay zeka tarafından oluşturulan sesler giderek daha gerçekçi hale geliyor ve sadece dinleyerek ayırt etmek çok zor olabilir. Bu, karar vermeyi geciktirirken hala risk altında kalmanıza neden olabilir.',
        risk: 20,
      },
    ],
    completed: false,
    timeLimit: 60,
    simulationType: 'aivoice',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: AI Güvenlik Etik Senaryosu
  {
    id: 'ai-ethics-1',
    title: 'AI Güvenlik Etiği',
    description: "Şirketiniz müşteri desteği için yeni bir AI asistanı kullanmaya başladı. Bu asistan müşteri verilerine erişim sağlıyor. Veri güvenliği sorumlusu olarak, sistemde potansiyel bir güvenlik açığı tespit ettiniz - asistanın bazen gereksiz müşteri bilgilerini kaydettiğini fark ettiniz.",
    type: 'ai',
    image: '/media/desktop-security.png',
    options: [
      {
        id: 'ai2-1',
        text: 'Sorunu rapor ederek AI asistanının derhal devre dışı bırakılmasını isteyin.',
        correct: false,
        explanation: 'Bu yaklaşım çok agresiftir. İş operasyonlarını kesintiye uğratır ve şirketin AI teknolojilerine olan güvenini azaltabilir. İlk adım olarak, sorunu değerlendirmek ve hemen uygulanabilecek güvenlik önlemleri aramak daha iyidir.',
        risk: 15,
      },
      {
        id: 'ai2-2',
        text: 'Güvenlik açığını ve veri erişimini kısıtlamak için AI sisteminin yeniden yapılandırılmasını önerin.',
        correct: true,
        explanation: 'Mükemmel! Bu yaklaşım hem sorunu çözer hem de iş operasyonlarının devam etmesini sağlar. AI sistemlerinin düzenli olarak denetlenmesi ve en düşük yetki prensibine göre yapılandırılması önemlidir.',
        risk: 0,
      },
      {
        id: 'ai2-3',
        text: 'Problemi görmezden gelin, AI sistemleri zaten hatalar içerir.',
        correct: false,
        explanation: 'Bu yaklaşım etik değildir ve veri koruma yasalarını ihlal edebilir. AI sistemleri insan yapımıdır ve hataları düzeltmek üzere düzenli olarak denetlenmelidir, özellikle kişisel veriler söz konusu olduğunda.',
        risk: 35,
      },
    ],
    completed: false,
    simulationType: 'aidata',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: Fiziksel Güvenlik Senaryosu 2: Sunucu Odası Güvenliği
  {
    id: 'physical-2',
    title: 'Sunucu Odası Güvenliği',
    description: "Şirketinizin sunucu odasına giriş yetkisine sahipsiniz. Bir toplantıdan dönerken, tanımadığınız birinin sunucu odasının kapısında bir şeyler kurcaladığını görüyorsunuz. Üzerinde şirket kimliği var gibi görünüyor, ancak o departmandan kimseyi tanımıyorsunuz.",
    type: 'physical',
    image: '/scenarios/new_images/server-room.png',
    options: [
      {
        id: 'ph2-1',
        text: 'Kişiye yaklaşıp doğrudan ne yaptığını ve kim olduğunu sorun.',
        correct: true,
        explanation: 'Doğrudan yaklaşarak kişinin kimliğini ve amacını sorgulamak, normal ve yetkili bir çalışan için sorun olmayacaktır. Eğer kişi yetkisiz ise, varlığınız caydırıcı olacaktır.',
        risk: 5,
      },
      {
        id: 'ph2-2',
        text: 'Hiçbir şey söylemeden uzaklaşın ve güvenliği arayın.',
        correct: false,
        explanation: 'Uzaklaşmak ve güvenliği aramak, şüpheli kişiye potansiyel bir zarar verme fırsatı tanır. Daha iyi bir yaklaşım, güvenli bir mesafeden kişiyi gözlemleyerek aynı anda güvenliği aramak olacaktır.',
        risk: 15,
      },
      {
        id: 'ph2-3',
        text: 'Mesafeyi koruyarak kişiyi gözlemleyin ve aynı anda güvenliği arayın.',
        correct: true,
        explanation: 'Bu, en dengeli yaklaşımdır. Şüpheli kişiyi gözlemlemeye devam ederek potansiyel zararlı faaliyetleri caydırırken, aynı zamanda profesyonel yardım çağırıyorsunuz.',
        risk: 0,
      }
    ],
    completed: false,
    simulationType: 'physical',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: Yapay Zeka Güvenliği Senaryosu 2: AI Model Manipülasyonu
  {
    id: 'ai-security-2',
    title: 'AI Model Manipülasyonu',
    description: "Şirketiniz müşteri sorularını otomatik cevaplamak için bir yapay zeka chatbot kullanıyor. Ekibiniz, chatbot'un bazı tuhaf ve bazen uygunsuz cevaplar vermeye başladığına dair raporlar aldı. İnceleme sonucunda, birinin sisteme kötü amaçlı veri enjekte ederek chatbot'un cevaplarını manipüle etmeye çalıştığını keşfettiniz.",
    type: 'ai',
    image: '/scenarios/new_images/ai-security.png',
    options: [
      {
        id: 'ai2-1',
        text: 'Chatbot\'u acilen kapatın ve olay çözülene kadar devre dışı bırakın.',
        correct: false,
        explanation: 'Sistemi tamamen kapatmak, müşteri hizmetlerini kesintiye uğratabilir. Bu, veri hasarı veya veri sızıntısı olmadıkça genellikle son çare olmalıdır.',
        risk: 10,
      },
      {
        id: 'ai2-2',
        text: 'Chatbot\'u kontamine olmamış versiyon ile yedekten geri yükleyin ve girdi doğrulama önlemlerini artırın.',
        correct: true,
        explanation: 'Bu, pratik bir çözümdür. Temiz bir yedekten geri yükleme, saldırının etkilerini giderir ve ek güvenlik önlemleri gelecekteki saldırıları önlemeye yardımcı olur.',
        risk: 0,
      },
      {
        id: 'ai2-3',
        text: 'Problemi araştırmak için bekleyin ve şimdilik görmezden gelin.',
        correct: false,
        explanation: 'Bir güvenlik sorununun görmezden gelinmesi, saldırganın daha fazla zarar vermesine izin verebilir ve şirket için itibar riski oluşturabilir. Hızlı aksiyon almak önemlidir.',
        risk: 35,
      }
    ],
    completed: false,
    simulationType: 'aidata',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: IoT Güvenliği Senaryosu
  {
    id: 'iot-security-1',
    title: 'IoT Cihaz Güvenliği',
    description: "Akıllı ev sisteminiz çeşitli IoT cihazlarıyla donatılmış durumda. Bu cihazlarda varsayılan güvenlik ayarları kullanılıyor ve bazılarının firmware güncellemeleri yapılmamış. Ağda şüpheli aktivite tespit edildi.",
    type: 'iot',
    image: '/scenarios/new_images/iot-security.png',
    options: [
      {
        id: 'iot1-1',
        text: 'Tüm cihazların varsayılan şifrelerini değiştir ve güncellemeleri yap',
        correct: true,
        explanation: 'IoT cihazlarındaki temel güvenlik sorunlarından biri varsayılan şifrelerin kullanılması ve zamanında yapılmayan güncellemelerdir. Bu adım, ağınızı güvenceye almak için doğru yaklaşımdır.',
        risk: 0,
      },
      {
        id: 'iot1-2',
        text: 'Şüpheli aktiviteyi görmezden gel, IoT cihazları genellikle düşük risk taşır',
        correct: false,
        explanation: 'IoT cihazları, tüm ağınıza erişim sağlayan giriş noktaları olabilir. Güvenlik açıklarını görmezden gelmek, tüm sistemin güvenliğini tehlikeye atar.',
        risk: 30,
      },
      {
        id: 'iot1-3',
        text: 'Cihazları geçici olarak kapat ve güvenlik uzmanına danış',
        correct: false,
        explanation: 'Bu, aşırı bir tepkidir ve günlük kullanımı kesintiye uğratır. Çoğu IoT güvenlik sorunu, doğru yapılandırma ve güncelleme ile çözülebilir.',
        risk: 10,
      }
    ],
    completed: false,
    simulationType: 'iot',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },

  // Yeni: Blockchain Güvenliği Senaryosu
  {
    id: 'blockchain-security-1',
    title: 'Kripto Para Cüzdanı Güvenliği',
    description: "E-postanıza, kripto para cüzdanınızın tehlikede olduğunu ve özel anahtarınızı doğrulamanız gerektiğini belirten bir mesaj geldi. Mesajda cüzdan adresi doğru görünüyor ve acil işlem yapmanızı istiyor.",
    type: 'blockchain',
    image: '/scenarios/new_images/blockchain-security.png',
    options: [
      {
        id: 'bc1-1',
        text: 'E-postadaki bağlantıya tıklayıp özel anahtarınızı girin',
        correct: false,
        explanation: 'Bu bir oltalama saldırısıdır. Kripto para dünyasında özel anahtarınızı asla kimseyle paylaşmamalısınız. Meşru hizmetler asla özel anahtarınızı e-posta üzerinden istemez.',
        risk: 40,
      },
      {
        id: 'bc1-2',
        text: 'E-postayı görmezden gelin ve resmi cüzdan uygulamanız üzerinden güvenlik kontrolü yapın',
        correct: true,
        explanation: 'Doğru yaklaşım budur. Kripto cüzdanınızla ilgili işlemleri her zaman resmi kanallar üzerinden yapmalısınız ve anahtarlarınızı asla paylaşmamalısınız.',
        risk: 0,
      },
      {
        id: 'bc1-3',
        text: 'E-posta göndericisine cevap yazarak daha fazla bilgi isteyin',
        correct: false,
        explanation: 'Şüpheli e-posta göndericileriyle iletişime geçmek bile risk taşır. Bu, kimliğinizi doğrulamak veya sosyal mühendislik teknikleriyle daha fazla bilgi almak için kullanılabilir.',
        risk: 20,
      }
    ],
    completed: false,
    simulationType: 'blockchain',
    difficultyPoints: 10, // Kolay senaryo temel puanı
  },
];

// Başlangıç başarılarını tanımlama
export const defaultAchievements: Achievement[] = [
  {
    id: 'first-game',
    title: 'İlk Adım',
    description: 'İlk simülasyonu tamamla',
    icon: '🏁',
    unlocked: false,
    condition: (state) => state.userStats.scenariosPlayed >= 1
  },
  {
    id: 'perfectionist',
    title: 'Mükemmeliyetçi',
    description: 'Tüm senaryoları doğru yanıtla',
    icon: '🏆',
    unlocked: false,
    condition: (state) => state.score === state.scenarios.length && state.scenarios.length > 0
  },
  {
    id: 'speed-demon',
    title: 'Hız Şampiyonu',
    description: '3 senaryoyu çok hızlı yanıtla',
    icon: '⚡',
    unlocked: false,
    condition: (state) => state.detailedScore.timeBonus >= 9
  },
  {
    id: 'level-5',
    title: 'Yükselen Yıldız',
    description: '5. seviyeye ulaş',
    icon: '🌟',
    unlocked: false,
    condition: (state) => state.level >= 5
  },
  {
    id: 'low-risk',
    title: 'Risk Uzmanı',
    description: 'Risk seviyesini %15\'in altında tut',
    icon: '🛡️',
    unlocked: false,
    condition: (state) => state.getRiskPercentage() < 15 && state.scenarios.filter(s => s.completed).length >= 5
  },
  {
    id: 'category-master',
    title: 'Kategori Uzmanı',
    description: 'Bir kategoride tüm senaryoları başarıyla tamamla',
    icon: '🔍',
    unlocked: false,
    condition: (state) => {
      const categories = Object.entries(state.performanceCategories);
      return categories.some(([_, data]) => data.total >= 3 && data.correct === data.total);
    }
  },
  {
    id: 'all-categories',
    title: 'Çeşitlilik',
    description: 'En az 5 farklı kategoride senaryo tamamla',
    icon: '🧩',
    unlocked: false,
    condition: (state) => {
      const categories = Object.entries(state.performanceCategories);
      const completedCategories = categories.filter(([_, data]) => data.total > 0);
      return completedCategories.length >= 5;
    }
  }
];

// Oyun store'u oluşturma
export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      // Kullanıcı bilgileri
      username: '',
      setUsername: (name) => set({ username: name }),

      // Oyun durumu
      isStarted: false,
      isCompleted: false,
      currentScenarioIndex: 0,
      score: 0,
      riskLevel: 0,

      // Yeni puanlama sistemi
      detailedScore: {
        basePoints: 0,
        timeBonus: 0,
        difficultyBonus: 0,
        consistencyBonus: 0
      },
      performanceCategories: {
        phishing: {correct: 0, total: 0},
        password: {correct: 0, total: 0},
        software: {correct: 0, total: 0},
        social: {correct: 0, total: 0},
        network: {correct: 0, total: 0},
        terminal: {correct: 0, total: 0},
        desktop: {correct: 0, total: 0},
        mobile: {correct: 0, total: 0},
        physical: {correct: 0, total: 0},
        ai: {correct: 0, total: 0},
        blockchain: {correct: 0, total: 0},
        iot: {correct: 0, total: 0}
      },
      fastestResponse: Number.POSITIVE_INFINITY,

      // Gamifikasyon sistemi
      level: 1, // Kullanıcı seviyesi
      xp: 0, // Deneyim puanı
      xpForNextLevel: 100, // Bir sonraki seviyeye geçmek için gereken XP
      achievements: defaultAchievements, // Kazanılan başarılar
      userStats: {
        totalCorrectAnswers: 0,
        totalIncorrectAnswers: 0,
        fastestResponseTime: Number.POSITIVE_INFINITY,
        totalPlayTime: 0,
        scenariosPlayed: 0,
        averageScore: 0,
        categoryScores: {
          phishing: 0,
          password: 0,
          software: 0,
          social: 0,
          network: 0,
          terminal: 0,
          desktop: 0,
          mobile: 0,
          physical: 0,
          ai: 0,
          blockchain: 0,
          iot: 0
        },
        completedDifficulties: {
          easy: 0,
          medium: 0,
          hard: 0
        }
      }, // Kullanıcı istatistikleri
      leaderboard: [], // Liderlik tablosu

      // Seviye sistemi işlevleri
      getLevel: () => {
        const { level, xp, xpForNextLevel } = get();
        const progress = (xp / xpForNextLevel) * 100;
        return { level, progress };
      }, // Mevcut seviye ve ilerleme
      addXP: (amount) => {
        const { xp, xpForNextLevel, level } = get();
        let newXP = xp + amount; // const yerine let kullan
        let newLevel = level;
        let newXPForNextLevel = xpForNextLevel;

        // Seviye atlama kontrolü
        while (newXP >= newXPForNextLevel) {
          newXP -= newXPForNextLevel;
          newLevel++;
          newXPForNextLevel += 100; // Her seviye atladıkça gereken XP artıyor
        }

        set({ xp: newXP, level: newLevel, xpForNextLevel: newXPForNextLevel });
      }, // XP ekle
      checkAchievements: () => {
        const state = get();

        // Tüm başarıları kontrol et
        const updatedAchievements = state.achievements.map(achievement => {
          // Eğer başarı zaten açılmışsa, değiştirme
          if (achievement.unlocked) {
            return achievement;
          }

          // Başarının koşulunu kontrol et
          const isUnlocked = achievement.condition(state);

          // Eğer başarı yeni açıldıysa, XP ver
          if (isUnlocked && !achievement.unlocked) {
            state.addXP(50); // Her başarı için 50 XP

            // Başarıyı bildirimle göstermek için burada işaretleyebiliriz
            // (bildirim sistemi eklenmedi)
          }

          return {
            ...achievement,
            unlocked: isUnlocked,
            unlockedAt: isUnlocked && !achievement.unlocked ? new Date() : achievement.unlockedAt
          };
        });

        set({ achievements: updatedAchievements });

        // Yeni açılmış başarıları geri döndür
        return updatedAchievements.filter(a => a.unlocked && !state.achievements.find(old => old.id === a.id)?.unlocked);
      }, // Başarıları kontrol et
      getLeaderboard: () => {
        return get().leaderboard;
      }, // Liderlik tablosunu getir
      updateLeaderboard: () => {
        const { username, getDetailedScoreAnalysis, level, achievements } = get();

        if (!username) return;

        const newEntry: LeaderboardEntry = {
          username,
          score: getDetailedScoreAnalysis().finalScore,
          level,
          achievements: achievements.filter(a => a.unlocked).length,
          date: new Date()
        };

        // Mevcut liderlik tablosunu al
        let currentLeaderboard = get().leaderboard;

        // Kullanıcının mevcut kayıtlarını kontrol et
        const existingEntryIndex = currentLeaderboard.findIndex(entry => entry.username === username);

        if (existingEntryIndex >= 0) {
          // Kullanıcının kaydı varsa ve yeni skor daha iyiyse güncelle
          if (currentLeaderboard[existingEntryIndex].score < newEntry.score) {
            currentLeaderboard[existingEntryIndex] = newEntry;
          }
        } else {
          // Kullanıcının kaydı yoksa ekle
          currentLeaderboard.push(newEntry);
        }

        // Skorlara göre sırala (en yüksekten en düşüğe)
        currentLeaderboard = currentLeaderboard.sort((a, b) => b.score - a.score);

        // Maksimum 50 kayıt tut
        if (currentLeaderboard.length > 50) {
          currentLeaderboard = currentLeaderboard.slice(0, 50);
        }

        set({ leaderboard: currentLeaderboard });
      },

      // Timer yönetimi
      difficultyLevel: 'medium',
      setDifficultyLevel: (level) => set({ difficultyLevel: level }),
      timeRemaining: null,
      timerId: null,
      showCertificate: false,
      setShowCertificate: (show) => set({ showCertificate: show }),
      useImprovedCertificate: true, // Varsayılan olarak gelişmiş sertifika kullanımı
      setUseImprovedCertificate: (use) => set({ useImprovedCertificate: use }),

      startTimer: (seconds) => {
        const { timerId } = get();
        if (timerId) clearInterval(timerId);

        set({ timeRemaining: seconds });
        const id = window.setInterval(() => {
          const { timeRemaining } = get();
          if (timeRemaining !== null && timeRemaining > 0) {
            set({ timeRemaining: timeRemaining - 1 });
          } else {
            const { stopTimer, getCurrentScenario, selectOption } = get();
            // Süre dolduğunda otomatik olarak yanlış bir cevabı seç
            const currentScenario = getCurrentScenario();
            if (currentScenario && !currentScenario.completed) {
              // İlk yanlış seçeneği bul
              const wrongOption = currentScenario.options.find(opt => !opt.correct);
              if (wrongOption) {
                selectOption(currentScenario.id, wrongOption.id);
              }
            }
            stopTimer();
          }
        }, 1000) as unknown as number;

        set({ timerId: id });
      },

      stopTimer: () => {
        const { timerId } = get();
        if (timerId) clearInterval(timerId);
        set({ timerId: null, timeRemaining: null });
      },

      // Senaryolar
      scenarios: allScenarios,

      // Oyun akışı fonksiyonları
      startGame: () => {
        const { difficultyLevel } = get();
        set({
          isStarted: true,
          // Zorluk seviyesine göre risk faktörünü ayarla
          scenarios: allScenarios.map(scenario => ({
            ...scenario,
            completed: false,
            selectedOption: undefined,
            responseTime: undefined,
            // Zor modda zaman sınırı ekle
            timeLimit: difficultyLevel === 'hard' ? scenario.timeLimit : undefined
          })),
          detailedScore: {
            basePoints: 0,
            timeBonus: 0,
            difficultyBonus: 0,
            consistencyBonus: 0
          },
          performanceCategories: {
            phishing: {correct: 0, total: 0},
            password: {correct: 0, total: 0},
            software: {correct: 0, total: 0},
            social: {correct: 0, total: 0},
            network: {correct: 0, total: 0},
            terminal: {correct: 0, total: 0},
            desktop: {correct: 0, total: 0},
            mobile: {correct: 0, total: 0},
            physical: {correct: 0, total: 0},
            ai: {correct: 0, total: 0},
            blockchain: {correct: 0, total: 0},
            iot: {correct: 0, total: 0}
          },
          fastestResponse: Number.POSITIVE_INFINITY,
          score: 0,
          riskLevel: 0
        });
      },

      completeGame: () => {
        // Tutarlılık bonusu hesaplama
        const { performanceCategories, scenarios } = get();
        let consistencyBonus = 0;

        // Her kategori için tutarlılık hesaplama
        let categoryCount = 0;
        let highPerformanceCategories = 0;

        Object.entries(performanceCategories).forEach(([key, data]) => {
          if (data.total > 0) {
            categoryCount++;
            // %80+ başarı gösteren kategoriler için bonus
            if ((data.correct / data.total) >= 0.8) {
              highPerformanceCategories++;
            }
          }
        });

        // En az 3 kategori tamamlanmışsa ve bunların çoğunda başarılıysa tutarlılık bonusu
        if (categoryCount >= 3 && (highPerformanceCategories / categoryCount) >= 0.7) {
          consistencyBonus = 10; // Tutarlı yüksek performans için bonus
        }

        set(state => ({
          isCompleted: true,
          showCertificate: true,
          detailedScore: {
            ...state.detailedScore,
            consistencyBonus
          }
        }));
      },

      resetGame: () => {
        const { stopTimer } = get();
        stopTimer();
        set({
          isStarted: false,
          isCompleted: false,
          currentScenarioIndex: 0,
          score: 0,
          riskLevel: 0,
          showCertificate: false,
          detailedScore: {
            basePoints: 0,
            timeBonus: 0,
            difficultyBonus: 0,
            consistencyBonus: 0
          },
          performanceCategories: {
            phishing: {correct: 0, total: 0},
            password: {correct: 0, total: 0},
            software: {correct: 0, total: 0},
            social: {correct: 0, total: 0},
            network: {correct: 0, total: 0},
            terminal: {correct: 0, total: 0},
            desktop: {correct: 0, total: 0},
            mobile: {correct: 0, total: 0},
            physical: {correct: 0, total: 0},
            ai: {correct: 0, total: 0},
            blockchain: {correct: 0, total: 0},
            iot: {correct: 0, total: 0}
          },
          fastestResponse: Number.POSITIVE_INFINITY,
          scenarios: allScenarios.map(scenario => ({
            ...scenario,
            completed: false,
            selectedOption: undefined,
            responseTime: undefined
          }))
        });
      },

      // Senaryo yönetimi
      getCurrentScenario: () => {
        const { scenarios, currentScenarioIndex } = get();
        return scenarios[currentScenarioIndex];
      },

      selectOption: (scenarioId, optionId) => {
        const { scenarios, stopTimer, timeRemaining } = get();
        const startTime = new Date().getTime();

        const updatedScenarios = scenarios.map(scenario => {
          if (scenario.id === scenarioId) {
            const selectedOption = scenario.options.find(opt => opt.id === optionId);

            // Yanıt süresi hesaplama (zaman sınırı varsa)
            let responseTime = undefined;
            if (scenario.timeLimit) {
              const elapsedTime = scenario.timeLimit - (timeRemaining || 0);
              responseTime = elapsedTime * 1000; // ms cinsine çevirme
            }

            // Puan ve risk hesaplama
            if (selectedOption) {
              const isCorrect = selectedOption.correct;

              // Temel puanları ve risk seviyesini güncelle
              set(state => {
                // İlgili kategorideki performansı güncelle
                const categoryPerformance = state.performanceCategories[scenario.type];
                const updatedCategoryPerformance = {
                  ...categoryPerformance,
                  total: categoryPerformance.total + 1,
                  correct: isCorrect ? categoryPerformance.correct + 1 : categoryPerformance.correct
                };

                // Doğru cevap için puanlar
                const basePoints = isCorrect ? (state.detailedScore.basePoints + (scenario.difficultyPoints || 10)) : state.detailedScore.basePoints;

                // Zorluk seviyesi bonusu
                const difficultyBonus = isCorrect && (scenario.difficultyPoints || 10) >= 15
                  ? state.detailedScore.difficultyBonus + 5
                  : state.detailedScore.difficultyBonus;

                // Zaman bonusu - Hızlı cevaplar için
                let timeBonus = state.detailedScore.timeBonus;
                if (isCorrect && responseTime && scenario.timeLimit) {
                  // Süre limitinin yarısından hızlı cevap verirse bonus
                  if (responseTime < (scenario.timeLimit * 1000 / 2)) {
                    timeBonus += 3;
                  }

                  // En hızlı yanıt süresini güncelle
                  if (responseTime < state.fastestResponse) {
                    state.fastestResponse = responseTime;
                  }
                }

                // XP puanları ekle
                let xpGain = isCorrect ? 10 : 2; // Doğru yanıtlar için 10 XP, yanlış yanıtlar için 2 XP

                // Hızlı cevap için bonus XP
                if (isCorrect && responseTime && responseTime < (scenario.timeLimit || 60) * 1000 / 2) {
                  xpGain += 5;
                }

                // Zorluk için bonus XP
                if (isCorrect && (scenario.difficultyPoints || 10) >= 15) {
                  xpGain += 5;
                }

                // Kullanıcı istatistiklerini güncelle
                const newUserStats = {
                  ...state.userStats,
                  totalCorrectAnswers: isCorrect ? state.userStats.totalCorrectAnswers + 1 : state.userStats.totalCorrectAnswers,
                  totalIncorrectAnswers: !isCorrect ? state.userStats.totalIncorrectAnswers + 1 : state.userStats.totalIncorrectAnswers,
                  scenariosPlayed: state.userStats.scenariosPlayed + 1,
                  fastestResponseTime: responseTime ? Math.min(state.userStats.fastestResponseTime, responseTime) : state.userStats.fastestResponseTime,
                  categoryScores: {
                    ...state.userStats.categoryScores,
                    [scenario.type]: isCorrect
                      ? state.userStats.categoryScores[scenario.type] + 1
                      : state.userStats.categoryScores[scenario.type]
                  },
                  averageScore: calculateAverageScore(
                    state.userStats.totalCorrectAnswers + (isCorrect ? 1 : 0),
                    state.userStats.scenariosPlayed + 1
                  )
                };

                // XP ekle
                state.addXP(xpGain);

                return {
                  score: isCorrect ? state.score + 1 : state.score,
                  riskLevel: state.riskLevel + (isCorrect ? 0 : selectedOption.risk),
                  detailedScore: {
                    basePoints,
                    timeBonus,
                    difficultyBonus,
                    consistencyBonus: state.detailedScore.consistencyBonus
                  },
                  performanceCategories: {
                    ...state.performanceCategories,
                    [scenario.type]: updatedCategoryPerformance
                  },
                  userStats: newUserStats
                };
              });
            }

            return {
              ...scenario,
              completed: true,
              selectedOption: optionId,
              responseTime
            };
          }
          return scenario;
        });

        set({ scenarios: updatedScenarios });
        stopTimer();
      },

      nextScenario: () => {
        const { currentScenarioIndex, scenarios, stopTimer } = get();

        stopTimer();

        if (currentScenarioIndex < scenarios.length - 1) {
          const nextIndex = currentScenarioIndex + 1;
          set({ currentScenarioIndex: nextIndex });

          // Eğer bir sonraki senaryonun zaman sınırı varsa, sayacı başlat
          const nextScenario = scenarios[nextIndex];
          if (nextScenario.timeLimit) {
            const { startTimer } = get();
            startTimer(nextScenario.timeLimit);
          }
        } else {
          set({ isCompleted: true, showCertificate: true });
        }
      },

      // Puan yönetimi
      getTotalPossibleScore: () => {
        return get().scenarios.length;
      },

      getScorePercentage: () => {
        const { score } = get();
        const totalPossible = get().getTotalPossibleScore();
        return totalPossible > 0 ? (score / totalPossible) * 100 : 0;
      },

      getRiskPercentage: () => {
        const { riskLevel } = get();
        // Maksimum risk puanı (her senaryoda yanlış seçim yapılsaydı)
        const maxRisk = 200; // Örnek bir değer, senaryolara göre ayarlanabilir
        return Math.min((riskLevel / maxRisk) * 100, 100);
      },

      // Yeni: Detaylı puan analizi
      getDetailedScoreAnalysis: () => {
        const { detailedScore, score } = get();
        const totalPossible = get().getTotalPossibleScore();

        // Temel başarı puanı (doğru yanıt sayısına bağlı)
        const basePercentage = totalPossible > 0 ? (score / totalPossible) * 100 : 0;

        // Toplam bonusları hesapla
        const totalBonusPoints = detailedScore.timeBonus + detailedScore.difficultyBonus + detailedScore.consistencyBonus;

        // Bonus puanlar eklenmiş toplam puan
        const totalPointsWithBonus = basePercentage + totalBonusPoints;

        // 100'den fazla olmamasını sağla
        const finalScore = Math.min(totalPointsWithBonus, 100);

        return {
          basePercentage,
          finalScore,
          bonusPoints: {
            timeBonus: detailedScore.timeBonus,
            difficultyBonus: detailedScore.difficultyBonus,
            consistencyBonus: detailedScore.consistencyBonus
          },
          totalBonusPoints
        };
      },

      // Yeni: Kategori performans analizi
      getCategoryPerformance: () => {
        const { performanceCategories } = get();

        const results: CategoryPerformance[] = [];

        // Her kategori için performans bilgilerini hesapla
        Object.entries(performanceCategories).forEach(([key, data]) => {
          if (data.total > 0) {
            const percentage = (data.correct / data.total) * 100;

            // Yetenek seviyesini ve derecesini hesapla
            let skillLevel = '';
            let skillRating = 0;

            if (percentage >= 90) {
              skillLevel = 'Uzman';
              skillRating = 95;
            } else if (percentage >= 75) {
              skillLevel = 'İleri Seviye';
              skillRating = 85;
            } else if (percentage >= 60) {
              skillLevel = 'Orta Seviye';
              skillRating = 70;
            } else if (percentage >= 40) {
              skillLevel = 'Temel Seviye';
              skillRating = 50;
            } else {
              skillLevel = 'Acemi';
              skillRating = 30;
            }

            results.push({
              category: key,
              correct: data.correct,
              total: data.total,
              percentage,
              skillLevel,
              skillRating
            });
          }
        });

        return results.sort((a, b) => b.percentage - a.percentage);
      }
    }),
    {
      name: 'cyber-security-game', // Local storage anahtarı
    }
  )
);
