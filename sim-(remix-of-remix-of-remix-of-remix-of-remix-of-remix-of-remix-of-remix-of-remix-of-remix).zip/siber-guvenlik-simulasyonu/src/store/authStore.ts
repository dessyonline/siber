import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  loginUser,
  registerUser,
  signOut,
  resetPassword,
  subscribeToAuthChanges,
  auth
} from '@/lib/firebase';
import type { User } from 'firebase/auth';

interface AuthState {
  // Kullanıcı bilgileri
  user: User | null;
  loading: boolean;
  error: string | null;

  // Authentication işlevleri
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, displayName: string) => Promise<boolean>;
  logout: () => Promise<boolean>;
  resetPassword: (email: string) => Promise<boolean>;
  setUser: (user: User | null) => void;
  clearError: () => void;

  // Kullanıcı seviyeleri
  userLevel: 'beginner' | 'intermediate' | 'advanced';
  setUserLevel: (level: 'beginner' | 'intermediate' | 'advanced') => void;

  // Profil bilgileri
  profileComplete: boolean;
  setProfileComplete: (value: boolean) => void;

  // Kullanıcının aktivite bilgileri
  lastActive: Date | null;
  updateLastActive: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      // Varsayılan durumlar
      user: null,
      loading: false,
      error: null,
      userLevel: 'beginner',
      profileComplete: false,
      lastActive: null,

      // Kimlik doğrulama işlevleri
      login: async (email: string, password: string) => {
        set({ loading: true, error: null });

        try {
          const result = await loginUser(email, password);
          if (result.error) {
            set({ error: result.error, loading: false });
            return false;
          }

          // User zaten auth state'de otomatik güncellenecek
          set({ loading: false });
          return true;
        } catch (error) {
          set({ error: 'Giriş sırasında beklenmeyen bir hata oluştu', loading: false });
          return false;
        }
      },

      register: async (email: string, password: string, displayName: string) => {
        set({ loading: true, error: null });

        try {
          const result = await registerUser(email, password, displayName);
          if (result.error) {
            set({ error: result.error, loading: false });
            return false;
          }

          // User zaten auth state'de otomatik güncellenecek
          set({ loading: false });
          return true;
        } catch (error) {
          set({ error: 'Kayıt sırasında beklenmeyen bir hata oluştu', loading: false });
          return false;
        }
      },

      logout: async () => {
        set({ loading: true, error: null });

        try {
          const result = await signOut();
          if (result.error) {
            set({ error: result.error, loading: false });
            return false;
          }

          // Çıkış yapıldığında kullanıcı bilgilerini sıfırla
          set({ user: null, loading: false });
          return true;
        } catch (error) {
          set({ error: 'Çıkış sırasında beklenmeyen bir hata oluştu', loading: false });
          return false;
        }
      },

      resetPassword: async (email: string) => {
        set({ loading: true, error: null });

        try {
          const result = await resetPassword(email);
          set({ loading: false });

          if (result.error) {
            set({ error: result.error });
            return false;
          }

          return true;
        } catch (error) {
          set({ error: 'Şifre sıfırlama sırasında beklenmeyen bir hata oluştu', loading: false });
          return false;
        }
      },

      // State güncellemeleri için yardımcı işlevler
      setUser: (user: User | null) => set({ user }),
      clearError: () => set({ error: null }),

      // Kullanıcı seviyesi yönetimi
      setUserLevel: (level) => set({ userLevel: level }),

      // Profil tamamlanma durumu
      setProfileComplete: (value) => set({ profileComplete: value }),

      // Son aktif tarih
      updateLastActive: () => set({ lastActive: new Date() }),
    }),
    {
      name: 'auth-store',
      partialize: (state) => ({
        // Hassas olmayan bilgileri localStorage'da sakla
        userLevel: state.userLevel,
        profileComplete: state.profileComplete,
        lastActive: state.lastActive
      }),
    }
  )
);

// Firebase auth değişikliklerini izle ve store'u güncelle
if (typeof window !== 'undefined') {
  subscribeToAuthChanges((user) => {
    useAuthStore.getState().setUser(user);
    if (user) {
      useAuthStore.getState().updateLastActive();
    }
  });
}
